!
function(e) {
    var t = e.babelHelpers = {};
    t.classCallCheck = function(e, t) {
        if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
    },
    t.createClass = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var r = t[n];
                r.enumerable = r.enumerable || !1,
                r.configurable = !0,
                "value" in r && (r.writable = !0),
                Object.defineProperty(e, r.key, r)
            }
        }
        return function(t, n, r) {
            return n && e(t.prototype, n),
            r && e(t, r),
            t
        }
    } (),
    t.slicedToArray = function() {
        function e(e, t) {
            var n = [],
            r = !0,
            i = !1,
            a = void 0;
            try {
                for (var o, s = e[Symbol.iterator](); ! (r = (o = s.next()).done) && (n.push(o.value), !t || n.length !== t); r = !0);
            } catch(e) {
                i = !0,
                a = e
            } finally {
                try { ! r && s.
                    return && s.
                    return ()
                } finally {
                    if (i) throw a
                }
            }
            return n
        }
        return function(t, n) {
            if (Array.isArray(t)) return t;
            if (Symbol.iterator in Object(t)) return e(t, n);
            throw new TypeError("Invalid attempt to destructure non-iterable instance")
        }
    } (),
    t.toConsumableArray = function(e) {
        if (Array.isArray(e)) {
            for (var t = 0,
            n = Array(e.length); t < e.length; t++) n[t] = e[t];
            return n
        }
        return Array.from(e)
    }
} ("undefined" == typeof global ? self: global),
function(e, t) {
    "use strict";
    window.__axtr = e.identity,
    e.module("WVS", ["ng", "ngAnimate", "ngAria", "ngMessages", "ngSanitize", "ajoslin.promise-tracker", "gettext", "LocalStorageModule", "ngclipboard", "nvd3", "toastr", "treeControl", "ui.router", "ui.bootstrap", "ui.bootstrap-slider", "ui.grid", "ui.grid.autoResize", "ui.grid.resizeColumns", "ui.grid.infiniteScroll", "ui.grid.saveState", "ui.grid.selection", "ui.grid.treeView", "ui.select"]),
    Array.prototype.find || (Array.prototype.find = function(e) {
        if (null === this) throw new TypeError("Array.prototype.find called on null or undefined");
        if ("function" != typeof e) throw new TypeError("predicate must be a function");
        for (var t = Object(this), n = t.length >>> 0, r = arguments[1], i = void 0, a = 0; a < n; a++) if (i = t[a], e.call(r, i, a, t)) return i
    }),
    Array.prototype.findIndex || Object.defineProperty(Array.prototype, "findIndex", {
        value: function() {
            function e(e) {
                if (null == this) throw new TypeError('"this" is null or not defined');
                var t = Object(this),
                n = t.length >>> 0;
                if ("function" != typeof e) throw new TypeError("predicate must be a function");
                for (var r = arguments[1], i = 0; i < n;) {
                    var a = t[i];
                    if (e.call(r, a, i, t)) return i;
                    i++
                }
                return - 1
            }
            return e
        } ()
    });
    var n = /(DTSTART=[0-9]{8}T[0-9]{6}Z)/,
    r = /(DTSTART):([0-9]{8}T[0-9]{6}Z)/;
    t.axConversions = {
        rfc3339ToPy: function() {
            function e(e) {
                if (e) {
                    var t = n.exec(e);
                    if (t) return t[1].replace("=", ":") + "\n" + e.replace(n, "").replace(/;+/gm, ";").replace(/^;|;$/gm, "")
                }
                return ""
            }
            return e
        } (),
        pyToRfc3339: function() {
            function n(n) {
                try {
                    if (n) {
                        var i = n.replace(r, "$1=$2").replace(/[\n]/gm, ";"),
                        a = t.fromString(i).toText();
                        return e.uppercase(a[0]) + a.substr(1)
                    }
                    return ""
                } catch(e) {}
                return n
            }
            return n
        } (),
        pyToRRULE: function() {
            function e(e) {
                try {
                    if (e) {
                        var n = e.replace(r, "$1=$2").replace(/[\n]/gm, ";");
                        return t.fromString(n)
                    }
                    return null
                } catch(e) {}
                return null
            }
            return e
        } ()
    }
} (angular, RRule),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c) {
        function u(r) {
            if (n.authConfig.enabled && t.get(n, "uiForms.authForm.$invalid", !1)) return ! 1;
            if (n.certificateSection.enabled && t.get(n, "uiForms.certForm.$invalid", !1)) return ! 1;
            if (n.proxySettings.enabled && t.get(n, "uiForms.proxyForm.$invalid", !1)) return ! 1;
            if ("auth" === t.defaultTo(r, "auth")) {
                var i = t.curryRight(t.pick, 2)(["enabled", "username", "password"]);
                if (n.authConfig.enabled && c.config.authentication.enabled && !e.equals(i(n.authConfig), i(c.config.authentication))) return ! 0;
                if (n.authConfig.enabled !== c.config.authentication.enabled) return ! 0
            }
            if ("cert" === t.defaultTo(r, "cert")) {
                var a = function(e) {
                    return t.pick(t.defaultTo(e, {}), ["uploadId", "name", "totalBytes", "uploadedBytes", "status"])
                };
                if (!e.equals(n.certificateSection.enabled, !!c.clientCertificate)) return ! 0;
                if (n.certificateSection.enabled) {
                    if (!e.equals(a(n.certConfig.certificate), a(c.clientCertificate))) return ! 0;
                    if (n.certConfig.password !== c.config.clientCertificatePassword) return ! 0
                }
            }
            if ("proxy" === t.defaultTo(r, "proxy")) {
                var o = function(e) {
                    var n = t.pick(e, ["protocol", "address", "username", "password", "port"]);
                    return n.authRequired = !!t.defaultTo(e.authRequired, n.username),
                    n
                };
                if (n.proxySettings.enabled && t.get(c, "config.proxy.enabled", !1) && !e.equals(o(c.config.proxy), o(n.proxySettings))) return ! 0;
                if (n.proxySettings.enabled !== t.get(c, "config.proxy.enabled", !1)) return ! 0
            }
            return ! 1
        }
        function l() {
            var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
            t = n.loadingTracker.createPromise();
            return i.when().then(function() {
                return u("auth") ? p() : void 0
            }).then(function() {
                return u("cert") ? f() : void 0
            }).then(function() {
                return u("proxy") ? h() : void 0
            }).then(function() {
                return n.notifyTargetUpdated()
            }).then(function() {
                return e ? n.reloadSection() : void 0
            }).
            finally(t.resolve)
        }
        function d(e, t) {
            u() && (t.cancel = !0, n.askSaveChanges().
            catch(function(e) {
                return "no" === e && n.changeSection(t.next),
                i.reject()
            }).then(function() {
                return l(!1)
            }).then(function() {
                n.changeSection(t.next)
            }))
        }
        function p() {
            var e = n.authConfig,
            t = e.enabled,
            r = e.username,
            i = e.password,
            a = {
                authentication: {
                    enabled: t,
                    username: r,
                    password: i
                }
            };
            return s.configureTarget(c.target.targetId, a, {
                tracker: n.loadingTracker,
                onRetry: function() {
                    function e() {
                        return l()
                    }
                    return e
                } ()
            })
        }
        function f() {
            return i.when().then(function() {
                if (n.certConfig.password !== c.config.clientCertificatePassword || !n.certificateSection.enabled && c.clientCertificate) {
                    var e = {
                        clientCertificatePassword: n.certificateSection.enabled ? n.certConfig.password: ""
                    };
                    return s.configureTarget(c.target.targetId, e, {
                        tracker: n.loadingTracker,
                        onRetry: function() {
                            function e() {
                                return l()
                            }
                            return e
                        } ()
                    })
                }
            }).then(function() {
                if (!n.certificateSection.enabled && c.clientCertificate || n.certificateSection.enabled && null === n.certConfig.certificate) return s.deleteClientCertificate(c.target.targetId, {
                    tracker: n.loadingTracker,
                    onRetry: function() {
                        function e() {
                            return l()
                        }
                        return e
                    } ()
                })
            }).then(function() {
                if (n.certConfig.certificate && n.certConfig.certificate.nativeFileUpload) return i.when().then(function() {
                    if (!n.certConfig.certificate.uploadURL) {
                        var e = {
                            name: n.certConfig.certificate.name,
                            size: n.certConfig.certificate.totalBytes
                        };
                        return s.setClientCertificate(c.target.targetId, e.name, e.size, {
                            tracker: n.loadingTracker,
                            onRetry: function() {
                                function e() {
                                    return l()
                                }
                                return e
                            } ()
                        }).then(function(e) {
                            n.certConfig.certificate.uploadURL = e
                        })
                    }
                }).
                catch(function(e) {
                    return n.certConfig.certificate.uploadURL = null,
                    i.reject(e)
                }).then(function() {
                    return g(n.certConfig.certificate.uploadURL, n.certConfig.certificate.nativeFileUpload)
                }).then(function() {
                    n.certConfig.certificate.nativeFileUpload = null,
                    n.certConfig.certificate.uploadURL = null
                })
            })
        }
        function g(e, t) {
            return i.when().then(function() {
                n.certificateSection.uploadingCertificate = !0
            }).then(function() {
                return o.upload(e, t, n.certConfig.certificate.uploadedBytes)
            }).then(null, null,
            function(e) {
                n.certConfig.certificate.uploadedBytes = e.uploadedBytes,
                n.certConfig.certificate.totalBytes = e.totalBytes
            }).then(function() {
                if (n.certConfig.certificate.status = n.certConfig.certificate.uploadedBytes === n.certConfig.certificate.totalBytes, !n.certConfig.certificate.status) {
                    var e = {
                        errorMessage: a("Client certificate has not been completely uploaded."),
                        onRetry: function() {
                            function e() {
                                return l()
                            }
                            return e
                        } ()
                    };
                    return r.$emit("axError", e),
                    i.reject(e)
                }
            }).
            catch(function() {
                n.certConfig.certificate.status = !1;
                var e = {
                    errorMessage: a("Client certificate has not been completely uploaded."),
                    onRetry: function() {
                        function e() {
                            return l()
                        }
                        return e
                    } ()
                };
                return r.$emit("axError", e),
                i.reject(e)
            }).
            finally(function() {
                n.certificateSection.uploadingCertificate = !1
            })
        }
        function h() {
            var e = n.proxySettings,
            t = null;
            return e.enabled && "none" !== e.protocol && (t = {
                protocol: e.protocol,
                enabled: !0,
                address: e.address,
                port: parseInt(e.port, 10)
            },
            e.authRequired && (t.username = e.username, t.password = e.password)),
            s.configureTarget(c.target.targetId, {
                proxy: t
            },
            {
                tracker: n.loadingTracker,
                onRetry: function() {
                    function e() {
                        return l()
                    }
                    return e
                } ()
            })
        }
        n.certificateSection = {
            enabled: !!c.clientCertificate,
            uploadingCertificate: !1,
            onEnabledChanged: function() {
                function e() {
                    var e = n.uiForms.certForm;
                    if (e) if (n.certificateSection.enabled) {
                        var t = n.certConfig,
                        r = t.password,
                        i = t.retypePassword; (r || i) && (e.password.$setTouched(), e.retypePassword.$setTouched())
                    } else e.$setUntouched(),
                    e.password.$setUntouched(),
                    e.retypePassword.$setUntouched()
                }
                return e
            } (),
            onCertificateSelected: function() {
                function e(e) {
                    n.certConfig.certificate = e
                }
                return e
            } (),
            onCertificateRemoved: function() {
                function e() {
                    n.certConfig.certificate = null
                }
                return e
            } ()
        },
        n.httpSection = {
            onEnabledChanged: function() {
                function e() {
                    var e = n.uiForms.authForm;
                    if (e) if (n.authConfig.enabled) {
                        var t = n.authConfig,
                        r = t.username,
                        i = t.password,
                        a = t.retypePassword; (r || i || a) && (e.username.$setTouched(), e.password.$setTouched(), e.retypePassword.$setTouched())
                    } else e.$setUntouched(),
                    e.username.$setUntouched(),
                    e.password.$setUntouched(),
                    e.retypePassword.$setUntouched()
                }
                return e
            } ()
        },
        n.proxySection = {
            enabled: !1,
            protocolOptions: [{
                value: "http",
                text: a("HTTP")
            }],
            onEnableChanged: function() {
                function e() {
                    var e = n.uiForms.proxyForm;
                    if (e) if (n.proxySettings.enabled) {
                        var t = n.proxySettings,
                        r = t.address,
                        i = t.port,
                        a = t.username,
                        o = t.password,
                        s = t.retypePassword; (r || i || a || o || s) && (e.address.$setTouched(), e.port.$setTouched(), e.username.$setTouched(), e.password.$setTouched(), e.retypePassword.$setTouched())
                    } else e.$setUntouched(),
                    e.address.$setUntouched(),
                    e.port.$setUntouched(),
                    e.username.$setUntouched(),
                    e.password.$setUntouched(),
                    e.retypePassword.$setUntouched()
                }
                return e
            } ()
        },
        e.extend(n, {
            hasChanges: u,
            update: l
        }),
        n.$on("axSectionChanging", d),
        function() {
            n.authConfig = e.extend({
                enabled: !1,
                username: "",
                password: ""
            },
            c.config.authentication),
            n.authConfig.retypePassword = n.authConfig.password,
            n.certConfig = {
                certificate: e.copy(t.defaultTo(c.clientCertificate, {})),
                password: c.config.clientCertificatePassword,
                retypePassword: c.config.clientCertificatePassword
            },
            n.proxySettings = {
                enabled: !1,
                protocol: "http",
                address: "",
                port: "",
                username: "",
                password: "",
                retypePassword: ""
            },
            e.extend(n.proxySettings, c.config.proxy || {}),
            n.proxySettings.password && (n.proxySettings.retypePassword = n.proxySettings.password),
            n.proxySettings.authRequired = !!n.proxySettings.username
        } ()
    }
    n.$inject = ["$scope", "$rootScope", "$q", "gettext", "axFileUploadService", "TargetsApi", "targetInfo"],
    e.module("WVS").controller("axTargetHttpConfigCtrl", n)
} (angular, _),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u, l) {
        function d(r) {
            if (t.get(n, "uiForms.generalForm.$invalid", !1)) return ! 1;
            if (n.siteLoginSection.enabled && "automatic" === n.siteLogin.kind && t.get(n, "uiForms.authForm.$invalid", !1)) return ! 1;
            if ("general" === t.defaultTo(r, "general")) {
                var i = t.curryRight(t.pick, 2)(["address", "description", "criticality", "continuousMode"]);
                if (!e.equals(i(n.target), i(l.target))) return ! 0
            }
            if ("siteLogin" === t.defaultTo(r, "siteLogin")) {
                if (l.config.login.kind !== n.siteLogin.kind) return ! 0;
                if ("automatic" === l.config.login.kind) {
                    var a = t.curryRight(t.pick, 2)(["enabled", "username", "password"]);
                    if (!e.equals(a(n.siteLogin.credentials), a(l.config.login.credentials))) return ! 0
                } else if ("sequence" === l.config.login.kind) {
                    var s = function(e) {
                        return t.pick(t.defaultTo(e, {}), ["uploadId", "name", "totalBytes", "uploadedBytes", "status"])
                    };
                    if (!e.equals(s(n.siteLogin.sequence), s(l.loginSequence))) return ! 0
                }
            }
            if ("acuSensor" === t.defaultTo(r, "acuSensor") && n.acuSensor.enabled !== l.config.sensor) return ! 0;
            if ("scanSpeed" === t.defaultTo(r, "scanSpeed")) {
                var c = t.get(o.SCAN_SPEED.find(function(e) {
                    return e.numericValue === n.config.scanSpeed
                }), "value", "fast");
                if (!e.equals(c, l.config.scanSpeed)) return ! 0
            }
            return ! 1
        }
        function p() {
            var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
            t = n.loadingTracker.createPromise();
            return i.when().then(function() {
                return d("general") ? h() : void 0
            }).then(function() {
                return d("siteLogin") ? v() : void 0
            }).then(function() {
                return d("acuSensor") ? b() : void 0
            }).then(function() {
                return d("scanSpeed") ? T() : void 0
            }).then(function() {
                return n.notifyTargetUpdated()
            }).then(function() {
                return e ? n.reloadSection() : void 0
            }).
            finally(t.resolve)
        }
        function f(t) {
            e.element("#download-helper").attr("src", "/api/v1/targets/sensors/" + String(t) + "/" + String(l.config.sensorSecret))
        }
        function g(e, t) {
            d() && (t.cancel = !0, n.askSaveChanges().
            catch(function(e) {
                return "no" === e && n.changeSection(t.next),
                i.reject()
            }).then(function() {
                return p(!1)
            }).then(function() {
                n.changeSection(t.next)
            }))
        }
        function h() {
            return u.updateTarget(n.target.targetId, n.target, {
                onRetry: function() {
                    function e() {
                        return p()
                    }
                    return e
                } ()
            }).then(function() {
                c.hasFeature("continuous_scans") === !0 && n.target.continuousMode !== l.target.continuousMode && m()
            })
        }
        function m() {
            return u.setContinuousScanStatus(n.target.targetId, n.target.continuousMode, {
                onRetry: function() {
                    function e() {
                        return p()
                    }
                    return e
                } ()
            }).then(function(e) {
                n.target.continuousMode = e
            })
        }
        function v() {
            var e = function(e, t) {
                return u.configureTarget(n.target.targetId, {
                    login: {
                        kind: e,
                        credentials: t
                    }
                },
                {
                    tracker: n.loadingTracker,
                    onRetry: function() {
                        function e() {
                            return p()
                        }
                        return e
                    } ()
                })
            };
            return i.when().then(function() {
                if ("sequence" !== n.siteLogin.kind && l.loginSequence || null === n.siteLogin.sequence && l.loginSequence) return y().then(function() {
                    return e("none")
                })
            }).then(function() {
                return "sequence" === n.siteLogin.kind ? i.when().then(function() {
                    if (n.siteLogin.sequence && n.siteLogin.sequence.nativeFileUpload) return i.when().then(function() {
                        if (!n.siteLogin.sequence.uploadURL) {
                            var e = {
                                name: n.siteLogin.sequence.name,
                                size: n.siteLogin.sequence.totalBytes
                            };
                            return u.setLoginSequence(n.target.targetId, e.name, e.size, {
                                tracker: n.loadingTracker,
                                onRetry: function() {
                                    function e() {
                                        return p()
                                    }
                                    return e
                                } ()
                            }).then(function(e) {
                                n.siteLogin.sequence.uploadURL = e
                            })
                        }
                    }).
                    catch(function(e) {
                        return n.siteLogin.sequence.uploadURL = null,
                        i.reject(e)
                    }).then(function() {
                        return S(n.siteLogin.sequence.uploadURL, n.siteLogin.sequence.nativeFileUpload)
                    }).then(function() {
                        n.siteLogin.sequence.nativeFileUpload = null,
                        n.siteLogin.sequence.uploadURL = null
                    })
                }).then(function() {
                    return e(n.siteLogin.sequence ? "sequence": "none")
                }) : "automatic" === n.siteLogin.kind ? e("automatic", n.siteLogin.credentials) : "none" === n.siteLogin.kind ? e("none") : void 0
            })
        }
        function y() {
            return u.deleteLoginSequence(n.target.targetId, {
                tracker: n.loadingTracker,
                onRetry: function() {
                    function e() {
                        return p()
                    }
                    return e
                } ()
            })
        }
        function S(e, t) {
            return i.when().then(function() {
                n.siteLoginSection.uploadingLoginSequence = !0
            }).then(function() {
                return s.upload(e, t, n.siteLogin.sequence.uploadedBytes)
            }).then(null, null,
            function(e) {
                n.siteLogin.sequence.uploadedBytes = e.uploadedBytes,
                n.siteLogin.sequence.totalBytes = e.totalBytes
            }).then(function() {
                if (n.siteLogin.sequence.status = n.siteLogin.sequence.uploadedBytes === n.siteLogin.sequence.totalBytes, !n.siteLogin.sequence.status) {
                    var e = {
                        errorMessage: a("Login sequence has not been completely uploaded."),
                        onRetry: function() {
                            function e() {
                                return p()
                            }
                            return e
                        } ()
                    };
                    return r.$emit("axError", e),
                    i.reject(e)
                }
            }).
            catch(function(e) {
                return n.siteLogin.sequence.status = !1,
                e.errorMessage || (e = {
                    errorMessage: a("Login sequence has not been completely uploaded."),
                    onRetry: function() {
                        function e() {
                            return p()
                        }
                        return e
                    } ()
                },
                r.$emit("axError", e)),
                i.reject(e)
            }).
            finally(function() {
                n.siteLoginSection.uploadingLoginSequence = !1
            })
        }
        function b() {
            return u.configureTarget(n.target.targetId, {
                sensor: n.acuSensor.enabled
            },
            {
                tracker: n.loadingTracker,
                onRetry: function() {
                    function e() {
                        return p()
                    }
                    return e
                } ()
            })
        }
        function T() {
            var e = t.get(o.SCAN_SPEED.find(function(e) {
                return e.numericValue === n.config.scanSpeed
            }), "value", "fast");
            return u.configureTarget(n.target.targetId, {
                scanSpeed: e
            },
            {
                tracker: n.loadingTracker,
                onRetry: function() {
                    function e() {
                        return p()
                    }
                    return e
                } ()
            })
        }
        n.criticalityOptions = o.BUSINESS_CRITICALITY.map(function(e) {
            return {
                text: e.text,
                value: parseInt(e.value, 10)
            }
        }),
        n.scanSpeedOptions = {
            ticks: o.SCAN_SPEED.map(function(e) {
                return e.numericValue
            }),
            ticksLabels: o.SCAN_SPEED.map(function(e) {
                return e.text
            })
        },
        n.siteLoginSection = {
            enabled: "none" !== l.config.login.kind,
            uploadingLoginSequence: !1,
            lsrLink: null,
            onEnabledChanged: function() {
                function e() {
                    var e = n.uiForms,
                    t = e.authForm,
                    r = e.sequenceForm;
                    if (n.siteLoginSection.enabled) {
                        if (n.siteLogin.kind = "none" !== l.config.login.kind ? l.config.login.kind: "automatic", t && "automatic" === n.siteLogin.kind) {
                            var i = n.siteLogin.credentials,
                            a = i.username,
                            o = i.password,
                            s = i.retypePassword; (a || o || s) && (t.username.$setTouched(), t.password.$setTouched(), t.retypePassword.$setTouched())
                        }
                    } else t && t.$setUntouched(),
                    r && r.$setUntouched(),
                    n.siteLogin.kind = "none"
                }
                return e
            } (),
            onSequenceSelected: function() {
                function e(e) {
                    n.siteLogin.sequence = e
                }
                return e
            } (),
            onSequenceRemoved: function() {
                function e() {
                    n.siteLogin.sequence = null
                }
                return e
            } ()
        },
        e.extend(n, {
            hasChanges: d,
            update: p,
            downloadSensor: f
        }),
        n.$on("axSectionChanging", g),
        function() {
            n.target = t.pick(l.target, ["targetId", "address", "description", "criticality", "continuousMode", "scansRequireMI"]),
            n.config = {
                scanSpeed: t.get(o.SCAN_SPEED.find(function(e) {
                    return e.value === l.config.scanSpeed
                }), "numericValue", 4)
            },
            l.testWebsite && (n.testWebsite = l.testWebsite);
            var r = l.target.address,
            i = /^(https?:\/\/)/;
            if (i.test(r) || (r = "http://" + String(r)), t.get(l, "config.authentication.enabled", !1)) {
                var a = l.config.authentication;
                r = r.replace(i, "$1" + encodeURIComponent(a.username) + ":" + encodeURIComponent(a.password) + "@")
            }
            if (l.config.proxy && l.config.proxy.enabled) {
                var s = void 0,
                c = l.config.proxy,
                u = c.address,
                d = c.protocol,
                p = c.port,
                f = c.username,
                g = c.password;
                s = f ? String(d) + "://" + String(encodeURIComponent(f)) + ":" + String(encodeURIComponent(g)) + "@" + String(u) + ":" + String(p) : String(d) + "://" + String(u) + ":" + String(p),
                n.siteLoginSection.lsrLink = "awvs://loginsequence/record?url=" + String(encodeURIComponent(r)) + "&proxy=" + String(encodeURIComponent(s))
            } else n.siteLoginSection.lsrLink = "awvs://loginsequence/record?url=" + String(encodeURIComponent(r));
            switch (n.siteLogin = {
                kind: l.config.login.kind,
                credentials: {
                    enabled: !0,
                    username: "",
                    password: "",
                    retypePassword: ""
                },
                sequence: null
            },
            n.siteLogin.kind) {
            case "automatic":
                e.extend(n.siteLogin.credentials, t.pick(t.defaultTo(l.config.login.credentials, {}), ["enabled", "username", "password"])),
                n.siteLogin.credentials.retypePassword = n.siteLogin.credentials.password;
                break;
            case "sequence":
                n.siteLogin.sequence = e.copy(l.loginSequence)
            }
            n.acuSensor = {
                enabled: l.config.sensor
            },
            n.$watch(function() {
                return n.siteLogin.kind
            },
            function(e) {
                n.siteLoginSection.enabled = "none" !== e
            })
        } ()
    }
    n.$inject = ["$scope", "$rootScope", "$q", "gettext", "axConstant", "axFileUploadService", "CurrentUser", "TargetsApi", "targetInfo"],
    e.module("WVS").controller("axTargetGeneralConfigCtrl", n)
} (angular, _),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u) {
        function l(r) {
            if ("navigation" === t.defaultTo(r, "navigation")) {
                var i = t.curryRight(t.pick, 2)(["caseSensitive", "excludedPaths", "limitCrawlerScope", "userAgent"]);
                if (!e.equals(i(n.navigation), i(u.config))) return ! 0
            }
            return ! ("imports" !== t.defaultTo(r, "imports") || !n.imports.files.find(function(e) {
                return e.$$add || e.$$delete
            }))
        }
        function d() {
            var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
            t = n.loadingTracker.createPromise();
            return i.when().then(function() {
                return l("navigation") ? h() : void 0
            }).then(function() {
                return l("imports") ? v() : void 0
            }).then(function() {
                return n.notifyTargetUpdated()
            }).then(function() {
                return e ? n.reloadSection() : void 0
            }).
            finally(t.resolve)
        }
        function p(e) {
            var t = n.navigation.excludedPaths.indexOf(e);
            t > -1 && n.navigation.excludedPaths.splice(t, 1)
        }
        function f(e) {
            var t = n.navigationSection.excludedPattern;
            if (e && 27 === e.keyCode) return void(n.navigationSection.excludedPattern = "");
            t.length > 0 && (null === e ? (m(t), n.navigationSection.excludedPattern = "") : 13 == e.keyCode && t && (m(t), n.navigationSection.excludedPattern = ""))
        }
        function g(e, t) {
            l() && (t.cancel = !0, n.askSaveChanges().
            catch(function(e) {
                return "no" === e && n.changeSection(t.next),
                i.reject()
            }).then(function() {
                return d(!1)
            }).then(function() {
                n.changeSection(t.next)
            }))
        }
        function h() {
            var e = t.pick(n.navigation, ["limitCrawlerScope", "caseSensitive", "userAgent", "excludedPaths"]);
            return s.configureTarget(u.target.targetId, e, {
                tracker: n.loadingTracker,
                onRetry: function() {
                    function e() {
                        return d()
                    }
                    return e
                } ()
            })
        }
        function m(e) {
            var t = n.navigation.excludedPaths;
            t.indexOf(e) < 0 && t.unshift(e)
        }
        function v() {
            return i.when().then(function() {
                n.importsSection.pending = !0
            }).then(function() {
                return n.imports.files.filter(function(e) {
                    return e.$$delete
                }).reduce(function(e, t) {
                    return e.then(function() {
                        return s.deleteImportedFile(u.target.targetId, t.uploadId)
                    }).then(function() {
                        return n.imports.files.splice(n.imports.files.indexOf(t), 1)
                    })
                },
                i.when())
            }).then(function() {
                return n.imports.files.filter(function(e) {
                    return e.$$add
                }).reduce(function(e, t) {
                    return e.then(function() {
                        t.$$uploading = !0
                    }).then(function() {
                        if (!t.uploadURL) return s.importFile(u.target.targetId, t.name, t.totalBytes).then(function(e) {
                            t.uploadURL = e
                        })
                    }).then(function() {
                        return y(t.uploadURL, t.nativeFileUpload, t)
                    }).then(function() {
                        delete t.$$add
                    }).
                    catch(function(e) {
                        return i.reject(e)
                    }).
                    finally(function() {
                        t.$$uploading = !1
                    })
                },
                i.when())
            }).
            finally(function() {
                n.importsSection.pending = !1
            })
        }
        function y(e, n, a) {
            return i.when().then(function() {
                return a.$$uploading = !0,
                c.upload(e, n, a.uploadedBytes, t.clamp(a.totalBytes / 1024, 30, 3600))
            }).then(null, null,
            function(e) {
                a.uploadedBytes = e.uploadedBytes,
                a.totalBytes = e.totalBytes
            }).then(function() {
                if (a.status = a.uploadedBytes === a.totalBytes, !a.status) {
                    var e = {
                        errorMessage: o.getString("Import file {{name}} has not been completely uploaded", {
                            name: a.name
                        }),
                        onRetry: function() {
                            function e() {
                                return d()
                            }
                            return e
                        } ()
                    };
                    return r.$emit("axError", e),
                    i.reject(e)
                }
            }).
            catch(function(e) {
                if (a.status = !1, !e.errorMessage) return e = {
                    errorMessage: o.getString("Import file {{name}} has not been completely uploaded", {
                        name: a.name
                    }),
                    onRetry: function() {
                        function e() {
                            return d()
                        }
                        return e
                    } ()
                },
                r.$emit("axError", e),
                i.reject(e)
            }).
            finally(function() {
                n.$$uploading = !1
            })
        }
        n.navigationSection = {
            caseSensitivePathOptions: [{
                value: "auto",
                text: a("Auto")
            },
            {
                value: "yes",
                text: a("Yes")
            },
            {
                value: "no",
                text: a("No")
            }],
            userAgents: [{
                text: "Google Chrome",
                value: "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.21 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.21"
            },
            {
                text: "Internet Explorer 11",
                value: "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko"
            },
            {
                text: "Firefox",
                value: "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:31.0) Gecko/20100101 Firefox/31.0"
            },
            {
                text: "Opera",
                value: "Opera/9.80 (Windows NT 6.0; U; en) Presto/2.8.99 Version/11.10"
            },
            {
                text: "Safari",
                value: "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/537.21 (KHTML, like Gecko) Version/5.0.4 Safari/537.21"
            },
            {
                text: "iPhone with iOS 6",
                value: "Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25"
            },
            {
                text: "Webkit on Android 4.0.3",
                value: "Mozilla/5.0 (Linux; U; Android 4.0.3; en-us; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30"
            }],
            onSelectUserAgent: function() {
                function e(e) {
                    n.navigation.userAgent = e
                }
                return e
            } (),
            excludedPattern: ""
        },
        n.importsSection = {
            pending: !1,
            nextUploadId: -1,
            onFileSelected: function() {
                function i(i, o) {
                    if (i) {
                        i.uploadId = o;
                        var s = n.imports.files.find(function(e) {
                            return e.uploadId === o
                        }),
                        c = t.countBy(n.imports.files.concat([i]),
                        function(e) {
                            return ! e.$$delete && t.endsWith(e.name, ".html") ? "selenium": "$_"
                        }),
                        u = c.selenium,
                        l = e.extend({},
                        s, i, {
                            $$add: !0,
                            isNew: !0
                        });
                        n.imports.files.splice(n.imports.files.indexOf(s), 0, l),
                        n.imports.files.splice(n.imports.files.indexOf(s), 1),
                        i.$$add = s.$$add = !0,
                        i.isNew = s.isNew = !0,
                        0 === i.totalBytes ? (r.$emit("axError", {
                            errorMessage: a("The selected file is empty")
                        }), t.remove(n.imports.files, s)) : u > 1 && (r.$emit("axError", {
                            errorMessage: a("You can only use one Selenium script per target")
                        }), t.remove(n.imports.files, s)),
                        n.imports.files.push({
                            uploadId: n.importsSection.nextUploadId--,
                            isNew: !0
                        })
                    }
                }
                return i
            } (),
            onFileRemoved: function() {
                function e(e) {
                    if (e) if (e.$$add || e.isNew) {
                        var t = n.imports.files.find(function(t) {
                            return t.uploadId === e.uploadId
                        });
                        t && (n.imports.files.splice(n.imports.files.indexOf(t), 1), n.imports.files.find(function(e) {
                            return e.isNew
                        }) || n.imports.files.push({
                            uploadId: n.importsSection.nextUploadId--,
                            isNew: !0
                        }))
                    } else e.$$delete = !0
                }
                return e
            } ()
        },
        e.extend(n, {
            hasChanges: l,
            update: d,
            onRemoveExcludedPath: p,
            onAddExcludedPathPattern: f
        }),
        n.$on("axSectionChanging", g),
        function() {
            n.navigation = {
                caseSensitive: u.config.caseSensitive,
                excludedPaths: e.copy(u.config.excludedPaths),
                limitCrawlerScope: u.config.limitCrawlerScope,
                userAgent: u.config.userAgent
            },
            n.imports = {
                files: u.importedFiles.concat([{
                    uploadId: n.importsSection.nextUploadId--,
                    isNew: !0
                }])
            }
        } ()
    }
    n.$inject = ["$scope", "$rootScope", "$q", "gettext", "gettextCatalog", "TargetsApi", "axFileUploadService", "targetInfo"],
    e.module("WVS").controller("axTargetCrawlConfigCtrl", n)
} (angular, _),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u, l, d, p) {
        function f() {
            var t = n.techSection.enabled ? n.advConfig.selectedTechnologies: [],
            r = n.cookiesSection.enabled ? n.advConfig.customCookies: [],
            i = n.headersSection.enabled ? n.advConfig.customHeaders: [],
            a = n.issueTrackerSection.enabled ? n.advConfig.issueTrackerId: "";
            return ! ((n.advConfig.excludedHoursId ? n.advConfig.excludedHoursId: "") == p.config.excludedHoursId && a === p.config.issueTrackerId && e.equals(t, p.config.technologies) && e.equals(i, p.config.customHeaders) && e.equals(r, p.config.customCookies) && n.advConfig.debug === p.config.debug && (!(Array.isArray(n.allowedHostsSection.hosts) && n.allowedHostsSection.hosts.length > 0) || n.allowedHostsSection.enabled) && (!e.isFunction(n.allowedHostsSection.hasChanges) || !n.allowedHostsSection.hasChanges()))
        }
        function g() {
            var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
            t = n.loadingTracker.createPromise();
            return r.when().then(function() {
                return v()
            }).then(function() {
                return y()
            }).then(function() {
                return n.notifyTargetUpdated()
            }).then(function() {
                return e ? n.reloadSection() : void 0
            }).
            finally(t.resolve)
        }
        function h() {
            return c.resetSensorSecret().then(function(e) {
                return d.resetSensorSecret(p.target.targetId, e.sensorSecret, {
                    tracker: n.loadingTracker,
                    onRetry: function() {
                        function e() {
                            return h()
                        }
                        return e
                    } ()
                }).then(function() {
                    return d.getTargetConfiguration(p.target.targetId, {
                        tracker: n.loadingTracker
                    })
                }).then(function(e) {
                    var t = e.sensorSecret;
                    p.config.sensorSecret = t
                }).then(function() {
                    return n.notifyTargetUpdated()
                })
            })
        }
        function m(e, t) {
            f() && (t.cancel = !0, n.askSaveChanges().
            catch(function(e) {
                return "no" === e && n.changeSection(t.next),
                r.reject()
            }).then(function() {
                return g(!1)
            }).then(function() {
                n.changeSection(t.next)
            }))
        }
        function v() {
            var e = {
                technologies: n.techSection.enabled ? n.advConfig.selectedTechnologies: [],
                customHeaders: n.headersSection.enabled ? n.advConfig.customHeaders: [],
                customCookies: n.cookiesSection.enabled ? n.advConfig.customCookies: [],
                issueTrackerId: n.issueTrackerSection.enabled && n.advConfig.issueTrackerId ? n.advConfig.issueTrackerId: "",
                excludedHoursId: n.excludedHoursSection.enabled ? t.defaultTo(n.advConfig.excludedHoursId, "") : "",
                debug: n.advConfig.debug
            };
            return u.hasFeature("bug_tracking_integration") !== !0 && delete e.issueTrackerId,
            r.when().then(function() {
                return d.configureTarget(p.target.targetId, e, {
                    onRetry: function() {
                        function e() {
                            return g()
                        }
                        return e
                    } ()
                })
            })
        }
        function y() {
            if (e.isFunction(n.allowedHostsSection.hasChanges) && (n.allowedHostsSection.hasChanges() || n.allowedHostsSection.hosts.length > 0 && !n.allowedHostsSection.enabled)) {
                if (!n.allowedHostsSection.enabled) for (; n.allowedHostsSection.hosts.length > 0;) n.allowedHostsSection.removeHost(n.allowedHostsSection.hosts[0]);
                return n.allowedHostsSection.update()
            }
        }
        n.techSection = {
            enabled: !1,
            toggleTechnology: function() {
                function e(e) {
                    var t = n.advConfig.selectedTechnologies,
                    r = t.indexOf(e);
                    r > -1 ? t.splice(r, 1) : t.push(e)
                }
                return e
            } ()
        },
        n.headersSection = {
            header: "",
            enabled: !1,
            onAddHeader: function() {
                function e(e) {
                    var t = n.headersSection.header;
                    if (e && 27 === e.keyCode) return void(n.headersSection.header = "");
                    t.length > 0 && (null === e ? (n.headersSection._addCustomHeader(t), n.headersSection.header = "") : 13 == e.keyCode && t && (n.headersSection._addCustomHeader(t), n.headersSection.header = ""))
                }
                return e
            } (),
            onRemoveHeader: function() {
                function e(e) {
                    n.advConfig.customHeaders.splice(n.advConfig.customHeaders.indexOf(e), 1)
                }
                return e
            } (),
            _addCustomHeader: function() {
                function e(e) {
                    n.advConfig.customHeaders.indexOf(e) < 0 && n.advConfig.customHeaders.push(e)
                }
                return e
            } ()
        },
        n.cookiesSection = {
            enabled: !1,
            cookiePath: "",
            cookieValue: "",
            onAddCookie: function() {
                function e(e) {
                    try {
                        var t = n.cookiesSection,
                        r = t.cookiePath,
                        i = t.cookieValue;
                        if (e && 27 === e.keyCode) return n.cookiesSection.cookiePath = "",
                        void(n.cookiesSection.cookieValue = "");
                        r && i && (null === e ? (n.cookiesSection._addCustomCookie(r, i), n.cookiesSection.cookiePath = "", n.cookiesSection.cookieValue = "") : 13 == e.keyCode && r && i && (n.cookiesSection._addCustomCookie(r, i), n.cookiesSection.cookiePath = "", n.cookiesSection.cookieValue = ""))
                    } finally {
                        n.uiForms.addCustomCookieForm.cookieUrl.$setUntouched()
                    }
                }
                return e
            } (),
            onRemoveCookie: function() {
                function e(e, t) {
                    var r = n.advConfig.customCookies.find(function(n) {
                        return n.url === e && n.cookie === t
                    });
                    r && n.advConfig.customCookies.splice(n.advConfig.customCookies.indexOf(r), 1)
                }
                return e
            } (),
            _addCustomCookie: function() {
                function e(e, t) {
                    n.advConfig.customCookies.find(function(n) {
                        return n.url === e && n.cookie === t
                    }) || n.advConfig.customCookies.push({
                        url: e,
                        cookie: t
                    })
                }
                return e
            } ()
        },
        n.allowedHostsSection = {
            enabled: !0
        },
        n.issueTrackerSection = {
            enabled: !1,
            issueTrackers: e.copy(p.issueTrackers),
            onConfigureIssueTracker: function() {
                function e() {
                    s.configureIssueTracker(null, {
                        tracker: n.loadingTracker
                    }).then(function() {
                        function e(t) {
                            return l.createIssueTrackerEntry(t.name, t, {
                                onRetry: function() {
                                    function n() {
                                        return e(t)
                                    }
                                    return n
                                } ()
                            }).then(function(e) {
                                n.issueTrackerSection.issueTrackers.push(e),
                                n.advConfig.issueTrackerId = e.issueTrackerId,
                                o.success(a.getString("Issue Tracker created"))
                            })
                        }
                        return e
                    } ())
                }
                return e
            } ()
        },
        n.excludedHoursSection = {
            enabled: !0,
            profiles: [{
                name: i("Use default excluded hours profile"),
                excludedHoursId: ""
            }].concat(p.excludedHours.profiles)
        },
        e.extend(n, {
            hasChanges: f,
            update: g,
            onResetAcuSensorPassword: h
        }),
        n.$on("axSectionChanging", m),
        function() {
            n.techSection.enabled = p.config.technologies.length > 0,
            n.headersSection.enabled = p.config.customHeaders.length > 0,
            n.cookiesSection.enabled = p.config.customCookies.length > 0,
            n.issueTrackerSection.enabled = !!p.config.issueTrackerId,
            p.isTestWebsite && (n.isTestWebsite = !0),
            n.advConfig = {
                technologyList: ["ASP", "ASP.NET", "PHP", "Perl", "Java/J2EE", "ColdFusion/Jrun", "Python", "Rails", "FrontPage", "Node.js"],
                selectedTechnologies: e.copy(p.config.technologies),
                customHeaders: e.copy(p.config.customHeaders),
                customCookies: e.copy(p.config.customCookies),
                issueTrackerId: p.config.issueTrackerId,
                debug: p.config.debug,
                excludedHoursId: p.config.excludedHoursId
            },
            n.$watch(function() {
                return n.allowedHostsSection.hosts ? n.allowedHostsSection.hosts.length: 0
            },
            function(e) {
                n.allowedHostsSection.enabled = e > 0
            })
        } ()
    }
    n.$inject = ["$scope", "$q", "gettext", "gettextCatalog", "toastr", "axConfigureIssueTrackerModal", "axSensorSecretModal", "CurrentUser", "IssueTrackersApi", "TargetsApi", "targetInfo"],
    e.module("WVS").controller("axTargetAdvancedConfigCtrl", n)
} (angular, _),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u, l, d, p) {
        function f() {
            return n.userList.items.splice(0),
            n.userList.nextCursor = void 0,
            g()
        }
        function g(i) {
            return r.when().then(function() {
                var e = t.get(i, "limit", c.LIST_PAGE_SIZE);
                return p.getUsers(n.userList.nextCursor, e, {
                    tracker: n.loadingTracker,
                    onRetry: function() {
                        function t() {
                            return g({
                                limit: e
                            })
                        }
                        return t
                    } ()
                })
            }).then(function(t) {
                var r = t.users,
                i = t.pagination;
                r.forEach(function(e) {
                    n.userList.items.find(function(t) {
                        return t.userId === e.userId
                    }) || n.userList.items.push(e)
                }),
                n.userList.nextCursor = i.nextCursor,
                n.noUsersCreated = 0 === n.userList.items.length,
                n.userList.gridApi.infiniteScroll.dataLoaded(!1, e.isDefined(i.nextCursor))
            }).
            catch(function(e) {
                return n.userList.gridApi.infiniteScroll.dataLoaded(!1, !1),
                r.reject(e)
            })
        }
        function h() {
            return t.get(T, "add", []).length > 0 || t.get(T, "remove", []).length > 0 || t.get(T, "update", []).length > 0
        }
        function m() {
            var e = d.get("license.limits.maxUsers") && d.hasFeature("multi_user") && 1 + n.userList.items.length === d.get("license.limits.maxUsers");
            return l.addUser(e).then(function(e) {
                n.userList.items.unshift(e),
                n.noUsersCreated = !1,
                e.accessAllGroups || i.go("app.edit_user", {
                    userId: e.userId,
                    returnUrl: n.currentUrl()
                },
                {
                    inherit: !1
                })
            })
        }
        function v(t) {
            var i = e.extend(n.$new(), {
                message: a(b() > 1 ? t ? "您确定要启用所选用户吗？": "您确定要禁用所选用户吗？": t ? "您确定要启用所选用户吗？": "您确定要禁用所选用户吗？")
            });
            return u.confirm({
                scope: i
            }).then(function() {
                var i = n.loadingTracker.createPromise(),
                a = i.resolve;
                S().reduce(function(n, r) {
                    return n.then(function() {
                        return p.updateUser({
                            userId: r.userId,
                            enabled: t
                        })
                    }).then(function(t) {
                        e.merge(r, t)
                    })
                },
                r.when()).
                finally(a)
            }).
            finally(function() {
                return i.$destroy()
            })
        }
        function y() {
            var i = e.extend(n.$new(), {
                message: a(b() > 1 ? "您确定要删除所选用户吗？": "您确定要删除所选用户吗？")
            });
            return u.confirm({
                scope: i
            }).then(function() {
                var e = 0,
                i = n.loadingTracker.createPromise(),
                a = i.resolve;
                S().reduce(function(r, i) {
                    return r.then(function() {
                        return p.removeUser(i.userId)
                    }).then(function() {
                        n.userList.gridApi.selection.unSelectRow(i),
                        t.remove(n.userList.items, i),
                        e++
                    })
                },
                r.when()).then(function() {
                    if (e > 0 && void 0 !== n.userList.nextCursor) return g({
                        limit: e
                    });
                    n.noUsersCreated = 0 === n.userList.items.length
                }).
                finally(a)
            }).
            finally(function() {
                return i.$destroy()
            })
        }
        function S() {
            var e = n.userList.gridApi && n.userList.gridApi.selection;
            return e ? e.getSelectedRows() : []
        }
        function b() {
            var e = n.userList.gridApi && n.userList.gridApi.selection;
            return e ? e.getSelectedCount() : 0
        }
        var T = {};
        n.noUsersCreated = !1,
        n.userList = {
            items: [],
            nextCursor: void 0
        },
        n.userList.gridOptions = {
            data: n.userList.items,
            appScopeProvider: n,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            enableHorizontalScrollbar: s.scrollbars.ALWAYS,
            enableVerticalScrollbar: s.scrollbars.ALWAYS,
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                cellTemplate: __axtr("/templates/settings/system-config/sections/users/cols/name.html"),
                displayName: o.getString("名称"),
                name: "name",
                width: 260
            },
            {
                displayName: o.getString("Email"),
                field: "email",
                width: 340
            },
            {
                cellFilter: "axUserRoleName",
                displayName: o.getString("角色"),
                field: "role",
                width: 150
            },
            {
                cellTemplate: __axtr("/templates/settings/system-config/sections/users/cols/access.html"),
                displayName: o.getString("连接所有目标"),
                name: "access",
                width: 120
            },
            {
                cellTemplate: __axtr("/templates/settings/system-config/sections/users/cols/enabled.html"),
                displayName: o.getString("允许"),
                name: "enabled",
                width: 80
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.userId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.userId
                }
                return e
            } (),
            onRegisterApi: function() {
                function e(e) {
                    n.userList.gridApi = e,
                    f()
                }
                return e
            } ()
        },
        e.extend(n, {
            hasChanges: h,
            onAddUserModal: m,
            onChangeEnableStatus: v,
            onDeleteUsers: y,
            selectedItems: S,
            selectedItemsCount: b
        })
    }
    n.$inject = ["$scope", "$q", "$state", "gettext", "gettextCatalog", "uiGridConstants", "axConstant", "axGeneralModal", "axAddUserModal", "CurrentUser", "ChildUsersApi"],
    e.module("WVS").controller("axSystemConfigUsersCtrl", n)
} (angular, _),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o) {
        function s(e) {
            return null !== d && "updates" === t.defaultTo(e, "updates") && n.productUpdates.updateMode !== d
        }
        function c() {
            var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
            t = n.loadingTracker.createPromise();
            return r.when().then(function() {
                return s("updates") ? o.updateConfiguration({
                    updates: n.productUpdates.updateMode
                }) : void 0
            }).then(function() {
                return n.notifySettingsUpdated()
            }).then(function() {
                return e ? n.reloadSection() : void 0
            }).
            finally(t.resolve, t.notify)
        }
        function u() {
            var e = n.loadingTracker.createPromise(),
            t = e.resolve;
            r.when().then(function() {
                return o.getSystemInfo({
                    tracker: n.loadingTracker,
                    onRetry: function() {
                        function e() {
                            return u()
                        }
                        return e
                    } ()
                })
            }).then(function(e) {
                return a.hasPermission("systemConfig") && a.hasFeature("updates") ? o.getSystemConfig({
                    tracker: n.loadingTracker,
                    onRetry: function() {
                        function e() {
                            return u()
                        }
                        return e
                    } ()
                }).then(function(t) {
                    return {
                        sysInfo: e,
                        sysConfig: t
                    }
                }) : (n.productUpdates.updateMode = "disabled", {
                    sysInfo: e
                })
            }).then(function(e) {
                return l(e.sysInfo, e.sysConfig)
            }).
            finally(t)
        }
        function l(e, t) {
            t && (n.productUpdates.updateMode = t.updateMode, d = t.updateMode),
            n.versionInfo = {
                buildNumber: e.buildNumber,
                buildDate: e.buildDate,
                versionFull: e.versionFull
            }
        }
        var d = null;
        n.productUpdates = {
            updateMode: null,
            updateModeList: [{
                value: "auto",
                text: i("自动下载并安装更新")
            },
            {
                value: "notify",
                text: i("通知我新产品更新")
            },
            {
                value: "disabled",
                text: i("不自动检查更新[不推荐]")
            }],
            updateAvailable: !1
        },
        n.versionInfo = null,
        e.extend(n, {
            hasChanges: s,
            update: c
        }),
        u()
    }
    n.$inject = ["$scope", "$q", "gettext", "CurrentUser", "SystemConfigApi"],
    e.module("WVS").controller("axSystemConfigProductUpdatesCtrl", n)
} (angular, _),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u, l, d, p) {
        function f() {
            var e = n.groupList.gridApi && n.groupList.gridApi.selection;
            return e ? e.getSelectedRows() : []
        }
        function g() {
            var e = n.groupList.gridApi && n.groupList.gridApi.selection;
            return e ? e.getSelectedCount() : 0
        }
        function h(i) {
            return r.when().then(function() {
                var e = t.get(i, "limit", c.LIST_PAGE_SIZE);
                return p.getGroups(void 0, n.groupList.nextCursor, e, {
                    onRetry: function() {
                        function t() {
                            return h({
                                limit: e
                            })
                        }
                        return t
                    } (),
                    tracker: n.loadingTracker
                })
            }).then(function(t) {
                var r = t.groups,
                i = t.pagination;
                r.forEach(function(e) {
                    n.groupList.items.find(function(t) {
                        return t.groupId === e.groupId
                    }) || n.groupList.items.push(e)
                }),
                n.groupList.nextCursor = i.nextCursor,
                n.noGroupsCreated = 0 === n.groupList.items.length,
                n.groupList.gridApi.infiniteScroll.dataLoaded(!1, e.isDefined(i.nextCursor))
            }).
            catch(function(e) {
                return n.groupList.gridApi.infiniteScroll.dataLoaded(!1, !1),
                r.reject(e)
            })
        }
        function m() {
            return l.addGroup().then(function(e) {
                n.groupList.items.unshift(e),
                n.noGroupsCreated = 0 === n.groupList.items.length
            })
        }
        function v(t) {
            return d.editGroup(t).then(function(n) {
                e.merge(t, n),
                s.success(a.getString("Group updated"))
            })
        }
        function y() {
            var a = e.extend(n.$new(), {
                message: i(g() > 1 ? "你确定删除所选组？": "你确定删除所选组？")
            });
            return u.confirm({
                scope: a
            }).then(function() {
                var e = 0,
                i = n.loadingTracker.createPromise(),
                a = i.resolve;
                f().reduce(function(r, i) {
                    return r.then(function() {
                        return p.deleteGroup(i.groupId)
                    }).then(function() {
                        n.groupList.gridApi.selection.unSelectRow(i),
                        t.remove(n.groupList.items, i),
                        e++
                    })
                },
                r.when()).then(function() {
                    if (e > 0 && void 0 !== n.groupList.nextCursor) return h({
                        limit: e
                    });
                    n.noGroupsCreated = 0 === n.groupList.items.length
                }).
                finally(a)
            }).
            finally(function() {
                return a.$destroy()
            })
        }
        var S = r.defer();
        n.noGroupsCreated = !1,
        n.groupList = {
            items: [],
            nextCursor: void 0
        },
        n.groupList.gridOptions = {
            data: n.groupList.items,
            appScopeProvider: n,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            enableHorizontalScrollbar: o.scrollbars.ALWAYS,
            enableVerticalScrollbar: o.scrollbars.ALWAYS,
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                cellTemplate: __axtr("/templates/settings/system-config/sections/target-groups/cols/name.html"),
                displayName: a.getString("组织名称"),
                name: "name",
                width: 320
            },
            {
                displayName: a.getString("描述"),
                field: "description",
                width: 240
            },
            {
                cellTemplate: __axtr("/templates/settings/system-config/sections/target-groups/cols/count.html"),
                displayName: a.getString("组织中的目标"),
                name: "targetCount",
                width: 260
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.groupId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.groupId
                }
                return e
            } (),
            onRegisterApi: function() {
                function e(e) {
                    n.groupList.gridApi = e,
                    S.resolve()
                }
                return e
            } ()
        },
        e.extend(n, {
            addGroupModal: m,
            editGroupModal: v,
            onDeleteGroups: y,
            selectedItems: f,
            selectedItemsCount: g
        }),
        function() {
            S.promise.then(function() {
                return h()
            })
        } ()
    }
    n.$inject = ["$scope", "$q", "gettext", "gettextCatalog", "uiGridConstants", "toastr", "axConstant", "axGeneralModal", "axAddGroupModal", "axEditGroupModal", "TargetGroupsApi"],
    e.module("WVS").controller("axSystemConfigTargetGroupsCtrl", n)
} (angular, _),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u, l, d, p, f, g) {
        function h() {
            return d.currentUrlEncoded()
        }
        function m() {
            var e = I && I.selection;
            return e ? e.getSelectedRows() : []
        }
        function v() {
            var e = I && I.selection;
            return e ? e.getSelectedCount() : 0
        }
        function y() {
            var t = e.extend(n.$new(), {
                message: o(v() > 1 ? "您确定要删除所选的扫描类型吗？": "您确定要删除所选的扫描类型吗？")
            });
            return l.confirm({
                scope: t
            }).then(T).
            finally(function() {
                return t.$destroy()
            })
        }
        function S() {
            var e = n.loadingTracker.createPromise();
            w.promise.then(function() {
                return g.getScanningProfiles({
                    onRetry: function() {
                        function e() {
                            return S()
                        }
                        return e
                    } ()
                })
            }).then(function(e) {
                var t; (t = n.scanningProfiles).push.apply(t, babelHelpers.toConsumableArray(e))
            }).then(function() {
                return _()
            }).
            finally(e.resolve)
        }
        function b() {
            n.loadingTracker.cancel()
        }
        function T() {
            var e = n.loadingTracker.createPromise();
            return r.when().then(function() {
                return m().filter(function(e) {
                    return ! e.custom
                }).reduce(function(e, r) {
                    return e.then(function() {
                        return g.deleteScanningProfile(r.profileId, {
                            noPublishError: !0
                        })
                    }).then(function() {
                        I.selection.unSelectRow(r),
                        t.remove(n.scanningProfiles, r)
                    })
                },
                r.when())
            }).
            catch(function(e) {
                return 409 === t.get(e, "status", 0) && n.$root && (e = new Error(o("Some scan types could not be deleted - they are left selected.")), n.$root.$emit("axError", e)),
                r.reject(e)
            }).
            finally(e.resolve)
        }
        function x() {
            p.set("scanning-profiles", I.saveState.save())
        }
        function _() {
            var e = p.get("scanning-profiles");
            e && I.saveState.restore(n, e)
        }
        function C() {
            p.remove("scanning-profiles"),
            i.reload(i.current)
        }
        var I = void 0,
        w = r.defer();
        n.loadingTracker = c({
            activationDelay: u.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        n.scanningProfiles = [],
        n.gridOptions = {
            data: n.scanningProfiles,
            appScopeProvider: n,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            enableRowHeaderSelection: !f.get("isChildAccount"),
            enableFullRowSelection: !1,
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                cellTemplate: __axtr("/templates/settings/system-config/sections/scanning-profiles/cols/name.html"),
                displayName: s.getString("名称"),
                name: "name",
                width: 320
            },
            {
                cellTemplate: __axtr("/templates/settings/system-config/sections/scanning-profiles/cols/builtin.html"),
                displayName: s.getString("内置"),
                name: "custom",
                width: 80
            }],
            gridMenuCustomItems: [{
                title: s.getString("重置布局"),
                action: C
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.profileId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.profileId
                }
                return e
            } (),
            onRegisterApi: function() {
                function e(e) {
                    I = e,
                    w.resolve(),
                    e.colResizable.on.columnSizeChanged(n, x),
                    e.core.on.columnVisibilityChanged(n, x),
                    e.core.on.sortChanged(n, x)
                }
                return e
            } ()
        },
        n.currentUrl = h,
        n.onDeleteSelected = y,
        n.selectedItems = m,
        n.selectedItemsCount = v,
        n.$on("$destroy", b),
        S()
    }
    n.$inject = ["$scope", "$q", "$state", "$stateParams", "gettext", "gettextCatalog", "promiseTracker", "axConstant", "axGeneralModal", "axPage", "axUserPreferences", "CurrentUser", "ScannerApi"],
    e.module("WVS").controller("axSystemConfigScanningProfilesCtrl", n)
} (angular, _),
function(e, t) {
    "use strict";
    function n(n, r, i, a) {
        function o() {
            var t = n.uiForms.proxyForm;
            t && (n.proxySettings.enabled ? e.forEach(t.$error,
            function(t) {
                e.forEach(t,
                function(t) {
                    e.isDefined(t.$viewValue) && "" !== t.$viewValue && t.$setTouched()
                })
            }) : t.$setUntouched())
        }
        function s() {
            if (p.enabled != n.proxySettings.enabled) return ! 0;
            if (p.enabled && n.proxySettings.enabled) {
                var r = function(e) {
                    var n = t.pick(e, ["protocol", "address", "username", "password", "port"]);
                    return n.authRequired = !!t.defaultTo(e.authRequired, n.username),
                    n
                };
                return ! e.equals(r(p), r(n.proxySettings))
            }
            return ! 1
        }
        function c() {
            if (n.proxySettings.enabled && n.uiForms.proxyForm.$invalid) return d(),
            r.reject();
            var e = n.proxySettings,
            t = null;
            return e.enabled && "none" !== e.protocol && (t = {
                protocol: e.protocol,
                enabled: !0,
                address: e.address,
                port: parseInt(e.port, 10)
            },
            e.authRequired && (t.username = e.username, t.password = e.password)),
            a.updateConfiguration({
                proxy: t
            },
            {
                tracker: n.loadingTracker
            }).then(function() {
                n.notifySettingsUpdated(),
                n.reloadSection()
            })
        }
        function u() {
            return a.getSystemConfig({
                tracker: n.loadingTracker,
                onRetry: function() {
                    function e() {
                        return u()
                    }
                    return e
                } ()
            }).then(function(e) {
                return l(e.proxy)
            })
        }
        function l(t) {
            n.proxySettings = {
                enabled: !1,
                protocol: "none",
                authRequired: !1
            },
            t && (e.extend(n.proxySettings, t, {
                authRequired: !!t.username
            }), n.proxySettings.authRequired && (n.proxySettings.retypePassword = n.proxySettings.password)),
            p = e.copy(n.proxySettings)
        }
        function d() {
            e.forEach(n.uiForms.proxyForm.$error,
            function(t) {
                e.forEach(t,
                function(e) {
                    e.$setTouched()
                })
            })
        }
        var p = {
            enabled: !1,
            protocol: "none",
            authRequired: !1
        };
        n.protocolOptions = i.PROXY_PROTOCOL_OPTION,
        n.proxySettings = {
            enabled: !1,
            protocol: "none",
            authRequired: !1
        },
        e.extend(n, {
            hasChanges: s,
            update: c,
            onEnableChanged: o
        }),
        u()
    }
    n.$inject = ["$scope", "$q", "axConstant", "SystemConfigApi"],
    e.module("WVS").controller("axSystemConfigProxyCtrl", n)
} (angular, _),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s) {
        function c() {
            return g.enabled != n.notifySettings.enabled || !(!n.notifySettings.enabled || !g.enabled) && !e.equals(t.pick(g, ["address", "port", "security", "username", "password", "fromAddress"]), t.pick(n.notifySettings, ["address", "port", "security", "username", "password", "fromAddress"]))
        }
        function u() {
            if (n.notifySettings.enabled && n.uiForms.settingsForm.$invalid) return f(),
            r.reject();
            var e = n.notifySettings,
            o = null;
            if (e.enabled) {
                var c = e.address,
                u = e.port,
                l = e.fromAddress,
                d = e.security;
                o = {},
                o.address = c,
                o.fromAddress = l,
                o.port = parseInt(u, 10),
                o.security = d,
                e.authRequired && (o.username = e.username, o.password = e.password)
            }
            return s.updateConfiguration({
                notifications: o
            },
            {
                tracker: n.loadingTracker,
                noPublishError: !0
            }).
            catch(function(e) {
                var n = t.get(e, "data.details[0].body.problems[0]", null);
                return n && "format" === n.code && "body.notifications.address" === n.param_path ? i.$emit("axError", {
                    errorMessage: a("SMTP Server address is not valid [invalid-address-format]")
                }) : i.$emit("axError", {
                    errorMessage: e.errorMessage
                }),
                r.reject(e)
            }).then(function() {
                n.notifySettingsUpdated(),
                n.reloadSection()
            })
        }
        function l() {
            var t = n.uiForms.settingsForm;
            t && (n.notifySettings.enabled ? e.forEach(t.$error,
            function(t) {
                e.forEach(t,
                function(t) {
                    e.isDefined(t.$viewValue) && "" !== t.$viewValue && t.$setTouched()
                })
            }) : t.$setUntouched())
        }
        function d() {
            return s.getSystemConfig({
                tracker: n.loadingTracker,
                onRetry: function() {
                    function e() {
                        return d()
                    }
                    return e
                } ()
            }).then(function(e) {
                return p(e.notifications)
            })
        }
        function p(t) {
            n.notifySettings = {
                enabled: !1,
                authRequired: !1,
                security: "none"
            },
            t && t.address && (e.extend(n.notifySettings, t, {
                authRequired: !!t.username
            },
            {
                enabled: !0
            }), n.notifySettings.authRequired && (n.notifySettings.retypePassword = n.notifySettings.password)),
            g = e.copy(n.notifySettings)
        }
        function f() {
            e.forEach(n.uiForms.settingsForm.$error,
            function(t) {
                e.forEach(t,
                function(e) {
                    e.$setTouched()
                })
            })
        }
        var g = {
            enabled: !1,
            authRequired: !1,
            security: "none"
        };
        n.securityOptions = o.SMTP_SECURITY_OPTION,
        n.notifySettings = {
            enabled: !1,
            authRequired: !1,
            security: "none"
        },
        e.extend(n, {
            hasChanges: c,
            update: u,
            onEnableChanged: l
        }),
        d()
    }
    n.$inject = ["$scope", "$q", "$rootScope", "gettext", "axConstant", "SystemConfigApi"],
    e.module("WVS").controller("axSystemConfigNotificationsCtrl", n)
} (angular, _),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u, l, d, p, f) {
        function g() {
            var e = n.issueTrackers.gridApi && n.issueTrackers.gridApi.selection;
            return e ? e.getSelectedRows() : []
        }
        function h() {
            var e = n.issueTrackers.gridApi && n.issueTrackers.gridApi.selection;
            return e ? e.getSelectedCount() : 0
        }
        function m(t) {
            l.configureIssueTracker(t, {
                tracker: n.loadingTracker
            }).then(function(e) {
                return f.updateIssueTrackerEntry(e, {
                    tracker: n.loadingTracker
                })
            }).then(function(n) {
                e.extend(t, n),
                c.success(s.getString("Issue Tracker updated"))
            })
        }
        function v() {
            l.configureIssueTracker(null, {
                tracker: n.loadingTracker
            }).then(function(e) {
                return f.createIssueTrackerEntry(e.name, e, {
                    tracker: n.loadingTracker
                })
            }).then(function(e) {
                n.issueTrackers.items.push(e),
                c.success(s.getString("Issue Tracker added"))
            })
        }
        function y(e) {
            var t = n.loadingTracker.createPromise(),
            r = t.resolve;
            f.checkIssueTrackerEntry(e.issueTrackerId).then(function() {
                c.success("Connection to issue tracker was successful.")
            }).
            finally(r)
        }
        function S() {
            var i = e.extend(n.$new(), {
                message: o(h() > 1 ? "您确定要删除所选的问题跟踪器吗？": "您确定要删除所选的问题跟踪器吗？")
            });
            u.confirm({
                scope: i
            }).then(function() {
                var e = n.loadingTracker.createPromise(),
                i = e.resolve;
                g().reduce(function(e, r) {
                    return e.then(function() {
                        return f.deleteIssueTrackerEntry(r.issueTrackerId)
                    }).then(function() {
                        n.issueTrackers.gridApi.selection.unSelectRow(r),
                        t.remove(n.issueTrackers.items, r)
                    })
                },
                r.when()).
                finally(i)
            }).
            finally(function() {
                return i.$destroy()
            })
        }
        function b(e) {
            var t; (t = n.issueTrackers.items).push.apply(t, babelHelpers.toConsumableArray(e))
        }
        function T() {
            d.set(I, n.issueTrackers.gridApi.saveState.save())
        }
        function x() {
            a(function() {
                var e = d.get(I);
                e && n.issueTrackers.gridApi.saveState.restore(n, e)
            })
        }
        function _() {
            d.remove(I),
            i.go(i.current.name, null, {
                reload: i.current.name
            })
        }
        var C = r.defer(),
        I = "system-config-issue-trackers";
        n.issueTrackers = {
            items: []
        },
        n.issueTrackers.gridOptions = {
            data: n.issueTrackers.items,
            appScopeProvider: n,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            enableRowHeaderSelection: !p.get("isChildAccount"),
            enableFullRowSelection: !1,
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                cellTemplate: __axtr("/templates/settings/system-config/sections/issue-trackers/cols/name.html"),
                displayName: s.getString("Name"),
                name: "name",
                width: 200
            },
            {
                cellTemplate: __axtr("/templates/settings/system-config/sections/issue-trackers/cols/url.html"),
                displayName: s.getString("Issue Tracker"),
                name: "issueTracker",
                width: 320
            },
            {
                cellTemplate: __axtr("/templates/settings/system-config/sections/issue-trackers/cols/auth.html"),
                displayName: s.getString("Authentication"),
                name: "authentication",
                width: 120
            },
            {
                displayName: s.getString("User"),
                field: "auth.username",
                name: "user",
                width: 180
            },
            {
                displayName: s.getString("Project"),
                field: "project.projectName",
                width: 200
            },
            {
                cellTemplate: __axtr("/templates/settings/system-config/sections/issue-trackers/cols/issue-type.html"),
                displayName: s.getString("Issue Type"),
                name: "issueType",
                width: 120
            }],
            gridMenuCustomItems: [{
                title: s.getString("Reset Layout"),
                action: _
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.issueTrackerId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.issueTrackerId
                }
                return e
            } (),
            infiniteScrollRowsFromEnd: 20,
            infiniteScrollUp: !1,
            infiniteScrollDown: !0,
            onRegisterApi: function() {
                function e(e) {
                    n.issueTrackers.gridApi = e,
                    e.colResizable.on.columnSizeChanged(n, T),
                    e.core.on.columnVisibilityChanged(n, T),
                    e.core.on.sortChanged(n, T),
                    C.resolve(e)
                }
                return e
            } ()
        },
        n.currentUser = p.get(),
        e.extend(n, {
            onAddIssueTracker: v,
            onCheckIssueTracker: y,
            onConfigureIssueTracker: m,
            onDeleteIssueTracker: S,
            selectedItems: g,
            selectedItemsCount: h
        }),
        function() {
            n.currentUser.isChildAccount && t.remove(n.issueTrackers.gridOptions.columnDefs,
            function(e) {
                var t = e.name;
                return "authentication" === t || "user" === t
            });
            var e = n.loadingTracker.createPromise(),
            i = e.resolve;
            r.when().then(function() {
                return f.getIssueTrackers()
            }).then(function(e) {
                return b(e)
            }).
            finally(C.promise.then(x)).
            finally(i)
        } ()
    }
    n.$inject = ["$scope", "$q", "$state", "$timeout", "gettext", "gettextCatalog", "toastr", "axGeneralModal", "axConfigureIssueTrackerModal", "axUserPreferences", "CurrentUser", "IssueTrackersApi"],
    e.module("WVS").controller("axSystemConfigIssueTrackersCtrl", n)
} (angular, _),
function(e, t) {
    "use strict";
    function n(t, n, r, i, a, o, s, c, u, l, d) {
        function p() {
            return t.pageState.excludedHoursId !== _
        }
        function f() {
            var e = t.loadingTracker.createPromise();
            return n.when().then(function() {
                return d.updateConfiguration({
                    excludedHoursId: t.pageState.excludedHoursId
                })
            }).then(function() {
                _ = t.pageState.excludedHoursId,
                t.notifySettingsUpdated()
            }).
            finally(e.resolve)
        }
        function g() {
            var r = e.extend(t.$new(), {
                message: i("您确定要删除所选的排除时间配置文件吗？")
            });
            return c.confirm({
                scope: r
            }).then(function() {
                var e = t.loadingTracker.createPromise(),
                r = y();
                return v().reduce(function(e, n) {
                    return e.then(function() {
                        return l.removeExcludedHoursProfile(n.excludedHoursId)
                    }).then(function() {
                        var e = C.indexOf(n);
                        e > -1 && (w.selection.unSelectRow(n), C.splice(e, 1)),
                        n.excludedHoursId === t.pageState.excludedHoursId && (t.pageState.excludedHoursId = null)
                    })
                },
                n.when()).then(function() {
                    r > 1 ? t.notifySettingsUpdated(i("Excluded hours profiles deleted")) : t.notifySettingsUpdated(i("Excluded hours profile deleted"))
                }).
                finally(e.resolve)
            })
        }
        function h(n) {
            s.open(n).then(function(r) {
                e.extend(n, r),
                t.notifySettingsUpdated(i("Excluded hours profile updated"))
            })
        }
        function m() {
            s.open().then(function(e) {
                C.push(e),
                t.notifySettingsUpdated(i("Excluded hours profile created")),
                t.reloadSection()
            })
        }
        function v() {
            var e = w && w.selection;
            return e ? e.getSelectedRows().filter(function(e) {
                return !! e.excludedHoursId
            }) : []
        }
        function y() {
            return v().length
        }
        function S() {
            return n.when().then(I.promise).then(function() {
                return l.getExcludedHoursProfiles({
                    onRetry: function() {
                        function e() {
                            return S()
                        }
                        return e
                    } ()
                }).then(function(e) {
                    C.splice(0),
                    C.push({
                        excludedHoursId: null,
                        name: i("No excluded hours in use")
                    }),
                    C.push.apply(C, babelHelpers.toConsumableArray(e)),
                    T()
                })
            }).then(function() {
                return d.getSystemConfig({
                    onRetry: function() {
                        function e() {
                            return S()
                        }
                        return e
                    } ()
                }).then(function(e) {
                    var n = e.excludedHoursId;
                    _ = n || null,
                    t.pageState.excludedHoursId = _
                })
            })
        }
        function b() {
            return I.promise.then(function(e) {
                u.set("excluded-hours", e.saveState.save())
            })
        }
        function T() {
            var e = u.get("excluded-hours");
            if (e) return I.promise.then(function(n) {
                n.saveState.restore(t, e)
            })
        }
        function x() {
            u.remove("excluded-hours"),
            r.reload(r.current)
        }
        t.pageState = {
            excludedHoursId: void 0,
            exclusionHoursProfiles: []
        };
        var _ = void 0,
        C = t.pageState.exclusionHoursProfiles,
        I = n.defer(),
        w = void 0;
        t.pageState.gridOptions = {
            data: C,
            appScopeProvider: t,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                cellTemplate: __axtr("/templates/settings/system-config/sections/exclusion-hours/cols/name.html"),
                displayName: a.getString("Name"),
                name: "name",
                width: 320
            },
            {
                cellTemplate: __axtr("/templates/settings/system-config/sections/exclusion-hours/cols/selected.html"),
                displayName: a.getString("Default"),
                name: "selected",
                width: 80
            }],
            gridMenuCustomItems: [{
                title: a.getString("Reset Layout"),
                action: x
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.excludedHoursId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.excludedHoursId
                }
                return e
            } (),
            onRegisterApi: function() {
                function e(e) {
                    e.colResizable.on.columnSizeChanged(t, b),
                    e.core.on.columnVisibilityChanged(t, b),
                    e.core.on.sortChanged(t, b),
                    w = e,
                    I.resolve(e)
                }
                return e
            } ()
        },
        e.extend(t, {
            hasChanges: p,
            update: f,
            onDeleteSelectedProfiles: g,
            onEditProfile: h,
            onCreateProfile: m,
            selectedItems: v,
            selectedItemsCount: y
        }),
        function() {
            S()
        } ()
    }
    n.$inject = ["$scope", "$q", "$state", "gettext", "gettextCatalog", "CurrentUser", "axExclusionHoursProfileModal", "axGeneralModal", "axUserPreferences", "ExcludedHoursApi", "SystemConfigApi"],
    e.module("WVS").controller("axExclusionHoursCtrl", n)
} (angular, _),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u, l, d, p, f, g, h, m, v) {
        function y(t) {
            return E(function() {
                var i = e.isString(t) && t.length > 0 ? "name:*" + encodeURIComponent(t) : void 0;
                return r.when().then(function() {
                    if (h.hasFeature("target_groups") !== !0) return r.reject({
                        status: 403
                    })
                }).then(function() {
                    return v.getGroups(i, void 0, 10, {
                        cache: d,
                        noPublishError: !0
                    }).then(function(e) {
                        var t = e.groups;
                        n.searchFilters.groupList = t
                    })
                }).then(function() {
                    if (n.searchFilters.group.length > 0) return n.searchFilters.group.reduce(function(e, t) {
                        return n.searchFilters.groupList.find(function(e) {
                            return e.groupId === n.searchFilters.groupList
                        }) ? e: e.then(function() {
                            return v.getGroup(t, {
                                cache: d,
                                noPublishError: !0
                            })
                        }).then(function(e) {
                            n.searchFilters.groupList.push(e)
                        })
                    },
                    r.when())
                }).then(function() {
                    n.searchFilters.groupList = o(n.searchFilters.groupList, "name")
                }).
                catch(function(e) {
                    return 403 === e.status || e.publishResponseError && e.publishResponseError(e),
                    r.reject(e)
                }).
                finally(C)
            })
        }
        function S(t) {
            return E(function() {
                var i = e.isString(t) && t.length > 0 ? "text_search:*" + encodeURIComponent(t) : void 0;
                return r.when().then(function() {
                    if (n.filterAsideVisible) return m.getTargets(i, void 0, 10, {
                        cache: l
                    }).then(function(e) {
                        var t = e.targets;
                        n.searchFilters.targetList = t
                    })
                }).then(function() {
                    if (n.searchFilters.target) {
                        if (!n.searchFilters.targetList.find(function(e) {
                            return e.targetId === n.searchFilters.target
                        })) return m.getTarget(n.searchFilters.target, {
                            cache: l
                        }).then(function(e) {
                            n.searchFilters.targetList.push(e)
                        })
                    }
                }).then(function() {
                    n.searchFilters.targetList = o(n.searchFilters.targetList, "address")
                }).
                finally(C)
            })
        }
        function b() {
            return f.currentUrlEncoded()
        }
        function T() {
            n.filterAsideVisible = !n.filterAsideVisible
        }
        function x(e) {
            var t = n.searchFilters;
            switch (t.filterTags.splice(t.filterTags.indexOf(e), 1), e.key) {
            case "severity":
                t.severity = [];
                break;
            case "criticality":
                t.criticality = [];
                break;
            case "status":
                t.status = null;
                break;
            case "cvss":
                t.cvss = null;
                break;
            case "target":
                t.target = null;
                break;
            case "group":
                t.group = [];
                break;
            case "vuln_type":
                t.vulnType = null
            }
            I()
        }
        function _() {
            n.loadingTracker.cancel()
        }
        function C() {
            var e = n.searchFilters,
            r = [],
            i = t.curryRight(t.join, 2)(", "),
            a = function(e, n) {
                return c.getString(t.get(n, e, s("N/A")))
            };
            if (e.severity.length > 0 && r.push({
                key: "severity",
                label: s("威胁程度:"),
                value: i(e.severity.map(function(t) {
                    var n = e.severityList.find(function(e) {
                        return e.value === t
                    });
                    return a("text", n)
                }))
            }), e.criticality.length > 0 && r.push({
                label: s("临界:"),
                key: "criticality",
                value: i(e.criticality.map(function(t) {
                    var n = e.criticalityList.find(function(e) {
                        return e.value === t
                    });
                    return a("text", n)
                }))
            }), e.status) {
                var o = e.statusList.find(function(t) {
                    return t.value === e.status
                });
                r.push({
                    key: "status",
                    label: s("状态:"),
                    value: a("text", o)
                })
            }
            if (e.cvss) {
                var u = e.cvssList.find(function(t) {
                    return t.value === e.cvss
                });
                r.push({
                    key: "cvss",
                    label: "CVSS:",
                    value: a("text", u)
                })
            }
            if (e.target) {
                var l = e.targetList.find(function(t) {
                    return t.targetId === e.target
                });
                r.push({
                    key: "target",
                    label: s("目标:"),
                    value: a("address", l)
                })
            }
            e.group.length > 0 && r.push({
                label: s("组织:"),
                key: "group",
                value: i(e.group.map(function(t) {
                    var n = e.groupList.find(function(e) {
                        return e.groupId === t
                    });
                    return a("name", n)
                }))
            }),
            e.vulnType && r.push({
                key: "vuln_type",
                label: s("漏洞类型:"),
                value: e.vulnType
            }),
            n.searchFilters.filterTags = r
        }
        function I() {
            var e = n.searchFilters,
            t = {
                groupBy: a.groupBy,
                severity: e.severity.length > 0 ? e.severity.join(",") : void 0,
                criticality: e.criticality.length > 0 ? e.criticality.join(",") : null,
                status: e.status ? e.status: null,
                cvss: e.cvss ? e.cvss: void 0,
                target: e.target ? e.target: void 0,
                group: e.group.length > 0 ? e.group.join(",") : void 0,
                type: e.vulnType ? e.vulnType: void 0,
                returnUrl: b()
            };
            $ = !0,
            i.go(i.current.name, t, {
                inherit: !1
            }).
            finally(function() {
                $ = !1
            })
        }
        function w() {
            var e = [],
            r = t.curryRight(t.join, 2)(",");
            n.searchFilters.severity.length > 0 && e.push("severity:" + r(n.searchFilters.severity)),
            n.searchFilters.criticality.length > 0 && e.push("criticality:" + r(n.searchFilters.criticality)),
            n.searchFilters.status && ("rediscovered" === n.searchFilters.status ? (e.push("status:open"), e.push("rediscovered:true")) : e.push("status:" + n.searchFilters.status)),
            n.searchFilters.cvss && ("4" === n.searchFilters.cvss ? e.push("cvss_score:<=" + n.searchFilters.cvss) : "4-7" === n.searchFilters.cvss ? (e.push("cvss_score:>=4"), e.push("cvss_score:<=7")) : "7" === n.searchFilters.cvss && e.push("cvss_score:>=" + n.searchFilters.cvss)),
            n.searchFilters.target && e.push("target_id:" + n.searchFilters.target),
            n.searchFilters.group.length > 0 && e.push("group_id:" + r(n.searchFilters.group)),
            n.searchFilters.vulnType && e.push("vt_id:" + n.searchFilters.vulnType),
            n.searchFilters.searchQuery = e.join(";")
        }
        function k(e, t) {
            e === t || $ || i.reload(i.current)
        }
        function A(e, t) {
            t !== e && (w(), C(), I())
        }
        function L(e) {
            n.groupByPretty = "criticality" === e ? "Criticality": "Vulnerability Type"
        }
        function E(e) {
            var t = n.loadingTracker.createPromise();
            return r.when().then(e).
            finally(t.resolve)
        }
        var $ = !1;
        n.loadingTracker = u({
            activationDelay: p.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        n.groupBy = "criticality" === a.groupBy ? a.groupBy: "default",
        n.filterAsideVisible = !1,
        n.searchFilters = {
            searchQuery: "",
            severity: g.getStateParam("severity", !0, t.map(p.VULN_SEVERITY_LEVEL, t.property("value"))),
            severityList: p.VULN_SEVERITY_LEVEL,
            criticality: g.getStateParam("criticality", !0, t.map(p.BUSINESS_CRITICALITY, t.property("value"))),
            criticalityList: p.BUSINESS_CRITICALITY,
            status: g.getStateParam("status", !1, t.map(p.VULN_STATUS, t.property("value")).concat(["!open"])),
            statusList: p.VULN_STATUS.concat([{
                value: "!open",
                text: s("Not Open")
            }]),
            cvss: g.getStateParam("cvss", !1, t.map(p.CVSS_SCORE, t.property("value"))),
            cvssList: p.CVSS_SCORE,
            target: g.getStateParam("target"),
            targetList: [],
            group: g.getStateParam("group", !0),
            groupList: [],
            vulnType: g.getStateParam("type"),
            filterTags: []
        },
        n.returnUrl = a.returnUrl,
        n.groupByPretty = "",
        n.toggleFilter = T,
        n.searchTargets = S,
        n.searchGroups = y,
        n.currentUrl = b,
        n.removeFilterTag = x,
        n.$on("$destroy", _),
        n.$watch("searchFilters.severity", A),
        n.$watch("searchFilters.criticality", A),
        n.$watch("searchFilters.status", A),
        n.$watch("searchFilters.cvss", A),
        n.$watch("searchFilters.target", A),
        n.$watch("searchFilters.group", A),
        n.$watch("searchFilters.vulnType", A),
        n.$watch("groupBy", L),
        n.$watchCollection(function() {
            return a
        },
        k),
        function() {
            w(),
            C(),
            S(),
            y()
        } ()
    }
    n.$inject = ["$scope", "$q", "$state", "$stateParams", "orderByFilter", "gettext", "gettextCatalog", "promiseTracker", "axTargetsCache", "axGroupsCache", "axConstant", "axPage", "axStateHelpers", "CurrentUser", "TargetsApi", "TargetGroupsApi"],
    e.module("WVS").controller("axGroupedListsVulnsCtrl", n)
} (angular, _),
function(e) {
    "use strict";
    function t(t, n, r, i, a, o, s, c, u, l) {
        function d(t) {
            var n = k.loadingTracker.createPromise(),
            r = e.isString(t) && t.length > 0 ? "text_search:*" + encodeURIComponent(t) : void 0;
            return c.getTargets(r, void 0, 100, {
                cache: u
            }).then(function(t) {
                var n = t.targets;
                k.targetList = n.map(function(t) {
                    return e.extend(t, {
                        available: !0
                    })
                })
            }).then(b).
            finally(n.resolve)
        }
        function p() {
            return k.changeSet.add.length > 0 || k.changeSet.remove.length > 0
        }
        function f(e) {
            t.$applyAsync(function() {
                k.addHost(e),
                k.dummy.target = null
            })
        }
        function g(e) {
            e.available = !1,
            k.hostList.items.unshift({
                targetId: e.targetId,
                address: e.address,
                description: e.description
            });
            var t = k.changeSet.remove.indexOf(e.targetId);
            t < 0 ? k.changeSet.add.push(e.targetId) : k.changeSet.remove.splice(t, 1)
        }
        function h(e) {
            var t = k.hostList.items.indexOf(e);
            k.hostList.items.splice(t, 1);
            var n = k.targetList.find(function(t) {
                return t.targetId === e.targetId
            });
            n && (n.available = !0);
            var r = k.changeSet.add.indexOf(e.targetId);
            r < 0 ? k.changeSet.remove.push(e.targetId) : k.changeSet.add.splice(r, 1)
        }
        function m() {
            var t = k.loadingTracker.createPromise();
            return n.when().then(function() {
                if (k.changeSet.remove.length > 0) return e.copy(k.changeSet.remove).reduce(function(e, t) {
                    return e.then(function() {
                        return c.removeAllowedHost(k.targetId, t)
                    }).then(function() {
                        k.changeSet.remove.splice(k.changeSet.remove.indexOf(t), 1)
                    })
                },
                n.when())
            }).then(function() {
                k.changeSet.add.length > 0 && e.copy(k.changeSet.add).reduce(function(e, t) {
                    return e.then(function() {
                        return c.addAllowedHost(k.targetId, t)
                    }).then(function() {
                        k.changeSet.add.splice(k.changeSet.add.indexOf(t), 1)
                    })
                },
                n.when())
            }).
            finally(t.resolve)
        }
        function v() {
            A.promise.then(S).then(_)
        }
        function y() {
            k.loadingTracker.cancel()
        }
        function S() {
            var e = k.loadingTracker.createPromise();
            return c.getAllowedHosts(k.targetId, {
                onRetry: function() {
                    function e() {
                        return S()
                    }
                    return e
                } ()
            }).then(function(e) {
                e.hosts.forEach(function(e) {
                    k.hostList.items.find(function(t) {
                        return t.targetId === e.targetId
                    }) || k.hostList.items.push(e)
                })
            }).then(function() {
                if (0 === k.targetList.length) return d()
            }).
            finally(e.resolve)
        }
        function b() {
            k.targetList.forEach(function(e) {
                e.available = e.targetId !== k.targetId && !k.hostList.items.find(function(t) {
                    return t.targetId === e.targetId
                })
            })
        }
        function T() {
            k.hostList.gridApi && k.hostList.gridApi.infiniteScroll.resetScroll(!1, !1)
        }
        function x() {
            l.set("allowed-hosts", k.hostList.gridApi.saveState.save())
        }
        function _() {
            var e = l.get("allowed-hosts");
            e && k.hostList.gridApi.saveState.restore(t, e)
        }
        function C() {
            l.remove("allowed-hosts"),
            r.reload(r.current)
        }
        function I() {
            k.appScopeProvider && e.extend(k.appScopeProvider, {
                update: m,
                hasChanges: p,
                hosts: k.hostList.items,
                removeHost: h
            }),
            v()
        }
        function w() {
            y()
        }
        var k = this,
        A = n.defer();
        k.loadingTracker = a({
            activationDelay: s.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        k.targetList = [],
        k.dummy = {
            target: null
        },
        k.hostList = {
            items: []
        },
        k.hostList.gridOptions = {
            data: k.hostList.items,
            appScopeProvider: k,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                field: "address",
                displayName: o.getString("Address"),
                width: 320
            },
            {
                field: "description",
                displayName: o.getString("Description"),
                width: 240
            },
            {
                name: "actions",
                displayName: "",
                width: 160,
                cellTemplate: '<div class="ui-grid-cell-contents">\n<a ng-click="grid.appScope.removeHost(row.entity)">{{::\'Remove\'|translate}}</a></div>'
            }],
            gridMenuCustomItems: [{
                title: o.getString("Reset Layout"),
                action: C
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.targetId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.targetId
                }
                return e
            } (),
            onRegisterApi: function() {
                function e(e) {
                    k.hostList.gridApi = e,
                    e.colResizable.on.columnSizeChanged(t, x),
                    e.core.on.columnVisibilityChanged(t, x),
                    e.core.on.sortChanged(t, x),
                    A.resolve()
                }
                return e
            } ()
        },
        k.targetId = i.targetId,
        k.changeSet = {
            add: [],
            remove: []
        },
        k.returnUrl = i.returnUrl,
        k.addHost = g,
        k.update = m,
        k.removeHost = h,
        k.onTargetSelected = f,
        k.hasChanges = p,
        k.searchTargets = d,
        k.$onInit = I,
        k.$onDestroy = w,
        t.$on("axScrollTop", T)
    }
    t.$inject = ["$scope", "$q", "$state", "$stateParams", "promiseTracker", "gettextCatalog", "axConstant", "TargetsApi", "axTargetsCache", "axUserPreferences"],
    e.module("WVS").component("axTargetAllowedHosts", {
        controller: t,
        templateUrl: __axtr("/templates/targets/target-config/components/allowed-hosts.component.html"),
        bindings: {
            appScopeProvider: "<?"
        }
    })
} (angular),
function(e) {
    "use strict";
    function t() {}
    e.module("WVS").controller("axGroupedScanDetailsVulnsCtrl", t)
} (angular),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u, l, d, p, f, g, h, m, v, y, S, b, T, x) {
        function _() {
            n.selectedLocation = null
        }
        function C() {
            n.filterAsideVisible = !n.filterAsideVisible
        }
        function I(e) {
            var t = n.searchFilters;
            switch (t.filterTags.splice(t.filterTags.indexOf(e), 1), e.key) {
            case "severity":
                t.severity = [];
                break;
            case "status":
                t.status = null;
                break;
            case "cvss":
                t.cvss = null
            }
            q()
        }
        function w(e) {
            var t = n.locations.indexOf(e);
            t > -1 ? t + 1 < n.locations.length && n.locations.splice(t + 1) : n.locations.splice(0),
            n.locId = e.locId
        }
        function k(e) {
            n.locations.push(e),
            n.locId = e.locId
        }
        function A(t) {
            if (n.selectedLocation = t, !n.selectedLocation) return u.when();
            var r = n.loadingTracker.createPromise();
            return S.getLocationDetails(n.scan.resultId, n.scan.scanId, t.locId, {
                cache: v
            }).then(function(t) {
                e.extend(n.selectedLocation, t)
            }).
            finally(r.resolve)
        }
        function L(e) {
            n.selectedVulnItems = e
        }
        function E() {
            return ["aborted", "completed", "failed"].indexOf(n.scan.status) > -1 || "completed" === n.scan.originalStatus
        }
        function $() {
            return ["aborted", "completed", "failed"].indexOf(n.scan.status) > -1 || "completed" === n.scan.originalStatus
        }
        function R() {
            y.chooseReportOptions().then(function(e) {
                return z(e.templateId, {
                    listType: "scan_result",
                    idList: [n.scan.resultId]
                })
            }).then(function() {
                l.go("app.list_reports", {},
                {
                    inherit: !1
                })
            })
        }
        function P(e, t) {
            var r = [];
            switch (t) {
            case "scan_result":
                r = [n.scan.resultId]
            }
            return K(e, {
                listType: t,
                idList: r
            })
        }
        function N() {
            var t = e.extend(n.$new(), {
                message: d("您确定要停止此扫描吗？")
            });
            return m.confirm({
                scope: t
            }).then(Y).
            finally(function() {
                return t.$destroy()
            })
        }
        function D() {
            Q = !0,
            l.go(l.current.name, {
                view: "events"
            }).
            finally(function() {
                Q = !1
            })
        }
        function U() {
            n.loadingTracker.cancel()
        }
        function V(t) {
            return T.getScan(n.scan.scanId, e.extend({
                tracker: n.loadingTracker,
                onRetry: function() {
                    function e() {
                        return V()
                    }
                    return e
                } ()
            },
            t || {})).then(function(t) {
                if (null === t) s.warn("Scan " + String(n.scan.scanId) + "  no longer exists."),
                n.sections.items.forEach(function(e) {
                    return e.visible = !1
                });
                else {
                    e.extend(n.scan, t),
                    c.resultId !== n.scan.resultId && "default" !== c.resultId && (n.scan.resultId = c.resultId);
                    n.scan.schedule.recurrence && !n.sections.items.find(function(e) {
                        return "sessions" === e.view
                    }) && n.sections.items.push({
                        heading: d("Previous Sessions"),
                        view: "sessions",
                        visible: !1
                    }),
                    n.sections.items.forEach(function(e) {
                        return e.visible = t.resultId
                    }),
                    n.sections.items[0].visible = !0
                }
            }).then(function() {
                var e = n.scan,
                t = e.scanId,
                r = e.resultId;
                if (r && "stats" === n.currentSection) return S.getStatistics(t, r, {
                    noPublishError: !0
                }).then(function(e) {
                    n.scanStatus = e
                })
            }).
            finally(G).
            finally(function() {
                var e = T.getScanNextRefresh(n.scan);
                n.$$destroyed || "stats" !== n.currentSection || null !== e && a(function() {
                    return V({
                        noPublishError: !0,
                        noLoadingTracker: !0,
                        tracker: null
                    })
                },
                e)
            })
        }
        function M(e) {
            n.groupByPretty = d("type" === e ? "Vulnerability Type": "None")
        }
        function F() {
            switch (c.view) {
            case "stats":
                n.sections.currentIndex = 0,
                n.currentSection = "stats";
                break;
            case "vulns":
                n.sections.currentIndex = 1,
                n.currentSection = "vulns";
                break;
            case "crawl":
                n.sections.currentIndex = 2,
                n.currentSection = "crawl";
                break;
            case "events":
                n.sections.currentIndex = 3,
                n.currentSection = "events";
                break;
            case "sessions":
                n.sections.currentIndex = 4,
                n.currentSection = "sessions"
            }
        }
        function O() {
            var e = n.searchFilters,
            t = [];
            e.severity.length > 0 && t.push("severity:" + e.severity.join(",")),
            e.status && ("rediscovered" === e.status ? (t.push("status:open"), t.push("rediscovered:true")) : t.push("status:" + e.status)),
            e.cvss && ("4" === e.cvss ? t.push("cvss_score:<=" + e.cvss) : "4-7" === e.cvss ? (t.push("cvss_score:>=4"), t.push("cvss_score:<=7")) : "7" === e.cvss && t.push("cvss_score:>=" + e.cvss)),
            e.searchQuery = t.join(";")
        }
        function H(e, t) {
            t !== e && (O(), G(), q())
        }
        function j(e, t) {
            e === t || Q || l.reload(l.current)
        }
        function G() {
            var e = n.searchFilters,
            t = [];
            if (e.severity.length > 0 && t.push({
                key: "severity",
                label: d("严重程度:"),
                value: e.severity.map(function(t) {
                    var n = e.severityList.find(function(e) {
                        return e.value === t
                    });
                    return p.getString(n.text)
                }).join(", ")
            }), e.status) {
                var r = e.statusList.find(function(t) {
                    return t.value === e.status
                });
                t.push({
                    key: "status",
                    label: d("状态:"),
                    value: p.getString(r.text)
                })
            }
            if (e.cvss) {
                var i = e.cvssList.find(function(t) {
                    return t.value === e.cvss
                });
                t.push({
                    key: "cvss",
                    label: "CVSS:",
                    value: p.getString(i.text)
                })
            }
            e.filterTags = t
        }
        function q() {
            var e = n.searchFilters;
            Q = !0;
            var t = {
                scanId: c.scanId,
                groupBy: "type",
                view: c.view,
                resultId: c.resultId,
                returnUrl: c.returnUrl,
                severity: e.severity.length > 0 ? e.severity.join(",") : void 0,
                status: null !== e.status ? e.status: void 0,
                cvss: null !== e.cvss ? e.cvss: void 0
            };
            l.go(l.current.name, t, {
                inherit: !1
            }).
            finally(function() {
                Q = !1
            })
        }
        function B() {
            return b.getExportTypes("scan_result", {
                tracker: n.loadingTracker,
                onRetry: function() {
                    function e() {
                        return B()
                    }
                    return e
                } ()
            }).then(function(t) {
                n.exportTemplateTypeList = t.map(function(t) {
                    return e.extend({
                        sourceType: "scan_result"
                    },
                    t)
                })
            })
        }
        function K(t, r) {
            if (Z.active()) {
                var i = e.extend(n.$new(), {
                    message: d("Another download is in progress.")
                });
                return m.alert({
                    scope: i
                }).
                finally(function() {
                    return i.$destroy()
                })
            }
            var a = n.loadingTracker.createPromise();
            return b.generateNewExport(t, r, {
                tracker: n.loadingTracker,
                onRetry: function() {
                    function e() {
                        return K(t, r)
                    }
                    return e
                } ()
            }).then(function(e) {
                "failed" !== e.status && g.success(p.getString("Your download will automatically start in a few moments")),
                W(e.reportId)
            }).
            finally(a.resolve)
        }
        function W(t) {
            var a, o, s = Z.createPromise(),
            c = !1;
            return c ? u.when() : (a = i(function() {
                return c = !0,
                b.getExport(t, {
                    tracker: Z,
                    noPublishError: !0
                }).then(function(t) {
                    if (null === t) {
                        var n = {
                            errorMessage: d("Your report could not be downloaded [Report deleted]")
                        };
                        return s.reject(n),
                        u.reject(n)
                    }
                    if ("failed" === t.status) {
                        var r = {
                            errorMessage: d("Your data could not be exported [Failed]")
                        };
                        return u.reject(r)
                    } (t.downloadLinkPDF || t.downloadLinkHTML || t.downloadLinkXML) && (e.element("#download-helper").attr("src", t.downloadLinkPDF || t.downloadLinkHTML || t.downloadLinkXML), s.resolve())
                }).
                catch(function(e) {
                    throw s.reject(e),
                    r.$emit("axError", e),
                    e
                }).
                finally(function() {
                    c = !1
                })
            },
            1e3), o = n.$on("$destroy", a.cancel), s.promise.
            finally(function() {
                i.cancel(a),
                o()
            }), s.promise)
        }
        function z(e, t) {
            return b.generateNewReport(e, t, {
                tracker: n.loadingTracker,
                onRetry: function() {
                    function n() {
                        return z(e, t)
                    }
                    return n
                } ()
            }).then(function() {
                g.success(p.getString("Your report is being created"))
            })
        }
        function Y() {
            return T.abortScan(n.scan.scanId, {
                tracker: n.loadingTracker,
                onRetry: function() {
                    function e() {
                        return Y()
                    }
                    return e
                } ()
            }).then(function(t) {
                e.extend(n.scan, t),
                c.resultId !== n.scan.resultId && "default" !== c.resultId && (n.scan.resultId = c.resultId)
            })
        }
        var Z = f({
            activationDelay: h.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        Q = !1;
        n.loadingTracker = f({
            activationDelay: h.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        n.scan = {
            scanId: c.scanId,
            resultId: null,
            target: {
                targetId: null,
                address: ""
            }
        },
        n.filterAsideVisible = !1,
        n.returnUrl = c.returnUrl,
        n.searchFilters = {
            searchQuery: "",
            filterTags: [],
            status: x.getStateParam("status", !1, t.map(h.VULN_STATUS, t.property("value")).concat(["!open"])),
            statusList: h.VULN_STATUS.concat([{
                value: "!open",
                text: d("Not Open")
            }]),
            severity: x.getStateParam("severity", !0, t.map(h.VULN_SEVERITY_LEVEL, t.property("value"))),
            severityList: h.VULN_SEVERITY_LEVEL,
            cvss: x.getStateParam("cvss", !1, t.map(h.CVSS_SCORE, t.property("value"))),
            cvssList: h.CVSS_SCORE
        },
        n.groupBy = "type",
        n.groupByPretty = "",
        n.locId = 0,
        n.locations = [],
        n.selectedLocation = null,
        n.sections = {
            currentIndex: 0,
            items: [{
                heading: d("扫描状态和信息"),
                view: "stats",
                visible: !1
            },
            {
                heading: d("漏洞"),
                view: "vulns",
                visible: !1
            },
            {
                heading: d("网站结构"),
                view: "crawl",
                visible: !1
            },
            {
                heading: d("事件"),
                view: "events",
                visible: !1
            }]
        },
        n.currentSection = "stats",
        n.selectedVulnItems = [],
        n.exportTemplateTypeList = [],
        n.scanStatus = void 0,
        n.hideLocationDetails = _,
        n.toggleFilter = C,
        n.onCrawlLocationLoaded = k,
        n.onCrawLocationDetails = A,
        n.onVulnerabilitiesSelectionChanged = L,
        n.removeFilterTag = I,
        n.onGenerateReport = R,
        n.onExport = P,
        n.changeLocation = w,
        n.canGenerateReport = E,
        n.canGenerateExport = $,
        n.onStopScan = N,
        n.navigateToEvents = D,
        n.$on("$destroy", U),
        n.$watch(function() {
            return c.view
        },
        function(e, t) {
            e !== t && F()
        }),
        n.$watch("sections.currentIndex",
        function(e, t) {
            if (e !== t) {
                var r = n.sections.items[e];
                n.currentSection = r.view,
                Q = !0,
                l.go(l.current.name, {
                    view: r.view
                }).
                finally(function() {
                    Q = !1
                })
            }
        }),
        n.$watch("groupBy", M),
        n.$watch("searchFilters.severity", H),
        n.$watch("searchFilters.status", H),
        n.$watch("searchFilters.cvss", H),
        n.$watchCollection(function() {
            return c
        },
        j),
        function() {
            G(),
            O(),
            F(),
            V(),
            B()
        } ()
    }
    n.$inject = ["$scope", "$rootScope", "$interval", "$timeout", "axFormatDurationFilter", "$log", "$stateParams", "$q", "$state", "gettext", "gettextCatalog", "promiseTracker", "toastr", "axConstant", "axGeneralModal", "axLocationsCache", "axReportOptionsModal", "ResultsApi", "ReportsApi", "ScansApi", "axStateHelpers"],
    e.module("WVS").controller("axGroupedScanDetailsCtrl", n)
} (angular, _),
function(e) {
    "use strict";
    function t(e) {
        function t() {
            i.clipboardTooltipEnabled = !1
        }
        function n(t) {
            t.clearSelection(),
            i.clipboardTooltipEnabled = !0,
            i.clipboardTooltipText = e("Copied!")
        }
        function r() {
            i.clipboardTooltipEnabled = !0,
            i.clipboardTooltipText = e("Press Ctrl+C to copy!")
        }
        var i = this;
        i.clipboardTooltipEnabled = !1,
        i.clipboardTooltipText = "",
        i.sectionVisibility = {
            description: !0,
            attackDetails: !0,
            request: !1,
            responseHeaders: !1,
            impact: !0,
            recommendation: !0,
            classification: !0,
            longDescription: !1,
            references: !0
        },
        i.onClipboardSuccess = n,
        i.onClipboardError = r,
        i.disableClipboardToolTip = t
    }
    t.$inject = ["gettext"],
    e.module("WVS").component("axVulnDetails", {
        controller: t,
        templateUrl: __axtr("/templates/components/vulns/vuln-details/vuln-details.component.html"),
        bindings: {
            vuln: "<"
        }
    }).directive("axVulnDetailsCollapsibleSection", ["$parse",
    function(t) {
        return {
            restrict: "A",
            scope: !1,
            link: function() {
                function n(n, r, i) {
                    function a(e) {
                        e ? (s.removeClass("fa-angle-double-down").addClass("fa-angle-double-up"), r.next().show()) : (s.removeClass("fa-angle-double-up").addClass("fa-angle-double-down"), r.next().hide())
                    }
                    var o = t(i.axVulnDetailsCollapsibleSection),
                    s = e.element('<i class="fa fa-fw m-r-xs"></i>');
                    r.prepend(s),
                    n.$watch(function() {
                        return o(n)
                    },
                    a),
                    r.on("click",
                    function() {
                        n.$applyAsync(function() {
                            var e = !o(n);
                            o.assign(n, e),
                            a(e)
                        })
                    })
                }
                return n
            } ()
        }
    }])
} (angular),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u, l, d, p, f, g, h) {
        function m() {
            L = n.$watchCollection(function() {
                return s
            },
            function() {
                E.returnUrl = p.currentUrlEncoded()
            })
        }
        function v(n) {
            var r = E.loadingTracker.createPromise();
            return a.when().then(function() {
                E.vulnList.gridApi.infiniteScroll.saveScrollPercentage()
            }).then(function() {
                var e = t.get(n, "limit", d.LIST_PAGE_SIZE);
                return f.getVulnerabilities(E.searchQuery, E.vulnList.nextCursor, e, {
                    onRetry: function() {
                        function e() {
                            return v()
                        }
                        return e
                    } ()
                })
            }).then(function(t) {
                var n = t.vulnerabilities,
                r = t.pagination;
                n.forEach(function(e) {
                    E.vulnList.items.find(function(t) {
                        return t.vulnId === e.vulnId
                    }) || E.vulnList.items.push(e)
                }),
                E.vulnList.nextCursor = r.nextCursor,
                E.vulnList.gridApi.infiniteScroll.dataLoaded(!1, e.isDefined(r.nextCursor)),
                E.onItemsLoaded && E.onItemsLoaded({
                    items: E.vulnList.items
                })
            }).
            catch(function(e) {
                return E.vulnList.gridApi.infiniteScroll.dataLoaded(!1, !1),
                a.reject(e)
            }).
            finally(r.resolve)
        }
        function y(n) {
            var r = E.loadingTracker.createPromise();
            return a.when().then(function() {
                E.vulnTypeList.gridApi.infiniteScroll.saveScrollPercentage()
            }).then(function() {
                var e = t.get(n, "limit", d.LIST_PAGE_SIZE);
                return f.getVulnerabilityTypes(E.groupBy, E.searchQuery, E.vulnTypeList.nextCursor, e, {
                    onRetry: function() {
                        function e() {
                            return y()
                        }
                        return e
                    } ()
                })
            }).then(function(t) {
                var n = t.vulnerabilityTypes,
                r = t.pagination;
                n.forEach(function(e) {
                    E.vulnTypeList.items.find(function(t) {
                        return t.vulnTypeId === e.vulnTypeId
                    }) || E.vulnTypeList.items.push(e)
                }),
                E.vulnTypeList.nextCursor = r.nextCursor,
                E.vulnTypeList.gridApi.infiniteScroll.dataLoaded(!1, e.isDefined(r.nextCursor)),
                E.onItemsLoaded && E.onItemsLoaded({
                    items: E.vulnTypeList.items
                })
            }).
            catch(function(e) {
                return E.vulnTypeList.gridApi.infiniteScroll.dataLoaded(!1, !1),
                a.reject(e)
            }).
            finally(r.resolve)
        }
        function S(t, n) {
            var r = E.groupBy ? E.vulnTypeList: E.vulnList,
            i = r.items,
            a = i.indexOf(n);
            a > -1 && $.promise.then(function(t) {
                t.selection.unSelectRow(n),
                i.splice(a, 1),
                e.isDefined(r.nextCursor) && (E.groupBy ? y({
                    limit: 1
                }) : v({
                    limit: 1
                }))
            })
        }
        function b(e, t) {
            var n = t.vulnId;
            try {
                var r = E.vulnList.items.find(function(e) {
                    return e.vulnId === n
                });
                r && E.vulnList.gridApi.selection.unSelectRow(r)
            } catch(e) {}
        }
        function T() {
            E.vulnTypeList && E.vulnTypeList.gridApi ? E.vulnTypeList.gridApi.infiniteScroll.resetScroll(!1, e.isDefined(E.vulnTypeList.nextCursor)) : E.vulnList && E.vulnList.gridApi && E.vulnList.gridApi.infiniteScroll.resetScroll(!1, e.isDefined(E.vulnList.nextCursor))
        }
        function x() {
            var e = E.groupBy ? E.vulnTypeList: E.vulnList;
            e.gridApi && e.gridApi.selection && e.gridApi.selection.clearSelectedRows(),
            e.items.splice(0),
            e.nextCursor = void 0,
            T();
            var t = a.defer();
            return c(function() {
                $.promise.then(E.groupBy ? y: v).then(t.resolve, t.reject)
            }),
            t.promise
        }
        function _() {
            if (E.layoutSaveKey) {
                var e = E[E.groupBy ? "vulnTypeList": "vulnList"].gridApi;
                g.set(E.layoutSaveKey, e.saveState.save())
            }
        }
        function C() {
            if (E.layoutSaveKey) {
                var e = g.get(E.layoutSaveKey);
                if (e) {
                    E[E.groupBy ? "vulnTypeList": "vulnList"].gridApi.saveState.restore(n, e)
                }
            }
        }
        function I() {
            E.layoutSaveKey && (g.remove(E.layoutSaveKey), o.reload(o.current))
        }
        function w() {
            if (e.isUndefined(E.returnUrl) && m(), E.layoutSaveKey) {
                E[E.groupBy ? "vulnTypeList": "vulnList"].gridOptions.gridMenuCustomItems = [{
                    title: u.getString("Reset Layout"),
                    action: I
                }]
            }
            $.promise.then(x).then(C),
            n.$watch(function() {
                return h.get()
            },
            function(e) {
                return e ? E.currentUser = e: void 0
            })
        }
        function k(t) {
            if (e.isDefined(t.returnUrl) && !t.returnUrl.isFirstChange() && (e.isString(t.returnUrl.currentValue) && !L ? m() : e.isUndefined(t.returnUrl) && L && (L(), L = void 0)), e.isDefined(t.groupBy) && !t.groupBy.isFirstChange()) throw new Error("Dynamically changing of groupBy expression is not supported");
            e.isDefined(t.layoutSaveKey) && !t.layoutSaveKey.isFirstChange() && t.layoutSaveKey.previousValue && (g.remove(t.layoutSaveKey.previousValue), _()),
            e.isDefined(t.searchQuery) && !t.searchQuery.isFirstChange() && x()
        }
        function A() {
            E.loadingTracker.cancel()
        }
        var L, E = this,
        $ = a.defer();
        E.currentUser = h.get(),
        E.loadingTracker = l({
            activationDelay: d.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        E.groupBy ? (E.vulnTypeList = {
            items: [],
            nextCursor: void 0
        },
        E.vulnTypeList.gridOptions = {
            data: E.vulnTypeList.items,
            appScopeProvider: E,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            enableRowHeaderSelection: !1,
            multiSelect: !1,
            gridMenuTitleFilter: i("translate"),
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                cellTemplate: __axtr("/templates/components/vulns/target-vulns/cell-templates/criticality.html"),
                displayName: u.getString("业务重要性"),
                field: "criticality",
                headerTooltip: !0,
                visible: "criticality" === E.groupBy || "criticality" !== E.groupBy && r.appConfig.showBusinessCriticality,
                width: 100
            },
            {
                cellTemplate: __axtr("/templates/components/vulns/target-vulns/cell-templates/severity.html"),
                displayName: u.getString("严重程度"),
                field: "severity",
                headerTooltip: !0,
                width: 40
            },
            {
                cellTemplate: __axtr("/templates/components/vulns/target-vulns/cell-templates/grouped-name.html"),
                field: "name",
                displayName: u.getString("漏洞"),
                width: 520
            },
            {
                name: "count",
                displayName: u.getString("分值"),
                cellFilter: "number",
                width: 100
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.vulnTypeId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.vulnTypeId
                }
                return e
            } (),
            infiniteScrollRowsFromEnd: 20,
            infiniteScrollUp: !1,
            infiniteScrollDown: !0,
            onRegisterApi: function() {
                function e(e) {
                    E.vulnTypeList.gridApi = e,
                    e.infiniteScroll.on.needLoadMoreData(n, y),
                    e.colResizable.on.columnSizeChanged(n, _),
                    e.core.on.columnVisibilityChanged(n, _),
                    e.core.on.sortChanged(n, _),
                    $.resolve(e)
                }
                return e
            } ()
        }) : (E.vulnList = {
            items: [],
            nextCursor: void 0
        },
        E.vulnList.gridOptions = {
            data: E.vulnList.items,
            appScopeProvider: E,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            gridMenuTitleFilter: i("translate"),
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                cellTemplate: __axtr("/templates/components/vulns/target-vulns/cell-templates/severity.html"),
                displayName: u.getString("严重程度"),
                field: "severity",
                headerTooltip: !0,
                width: 40
            },
            {
                cellTemplate: __axtr("/templates/components/vulns/target-vulns/cell-templates/name.html"),
                displayName: u.getString("漏洞"),
                field: "name",
                width: 320
            },
            {
                cellTemplate: __axtr("/templates/components/vulns/target-vulns/cell-templates/address.html"),
                displayName: u.getString("URL"),
                field: "url",
                width: 420
            },
            {
                displayName: u.getString("目标备注"),
                field: "targetDescription",
                visible: !1,
                width: 240
            },
            {
                cellTemplate: __axtr("/templates/components/vulns/target-vulns/cell-templates/parameter.html"),
                displayName: u.getString("参数"),
                field: "parameter",
                width: 120
            },
            {
                cellFilter: "axBusinessCriticality",
                displayName: u.getString("业务重要性"),
                field: "criticality",
                visible: r.appConfig.showBusinessCriticality,
                width: 160
            },
            {
                cellFilter: "axVulnStatus",
                displayName: u.getString("状态"),
                field: "status",
                width: 100
            },
            {
                cellFilter: 'date:"medium"',
                displayName: u.getString("上次扫描"),
                field: "lastSeen",
                width: 160
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.vulnId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.vulnId
                }
                return e
            } (),
            infiniteScrollRowsFromEnd: 20,
            infiniteScrollUp: !1,
            infiniteScrollDown: !0,
            onRegisterApi: function() {
                function e(e) {
                    E.vulnList.gridApi = e,
                    e.infiniteScroll.on.needLoadMoreData(n, v),
                    e.colResizable.on.columnSizeChanged(n, _),
                    e.core.on.columnVisibilityChanged(n, _),
                    e.core.on.sortChanged(n, _);
                    var t = function() {
                        function e() {
                            E.onSelectionChanged && E.onSelectionChanged({
                                items: E.vulnList.gridApi.selection.getSelectedRows()
                            })
                        }
                        return e
                    } ();
                    e.selection.on.rowSelectionChanged(n, t),
                    $.resolve(e)
                }
                return e
            } ()
        }),
        h.hasFeature("target_business_criticality") !== !0 && t.remove(E[E.groupBy ? "vulnTypeList": "vulnList"].gridOptions.columnDefs, t.matchesProperty("field", "criticality")),
        E.$onInit = w,
        E.$onChanges = k,
        E.$onDestroy = A,
        n.$on("axScrollTop", T),
        n.$on("$destroy", r.$on("axRemoveVulnItem", S)),
        n.$on("$destroy", r.$on("axDeselectVulnerability", b))
    }
    n.$inject = ["$scope", "$rootScope", "$filter", "$q", "$state", "$stateParams", "$timeout", "gettextCatalog", "promiseTracker", "axConstant", "axPage", "VulnerabilitiesApi", "axUserPreferences", "CurrentUser"],
    e.module("WVS").component("axTargetVulns", {
        controller: n,
        templateUrl: __axtr("/templates/components/vulns/target-vulns/target-vulns.component.html"),
        bindings: {
            returnUrl: "<?",
            layoutSaveKey: "@?",
            searchQuery: "<?",
            groupBy: "<?",
            targetId: "<?",
            onSelectionChanged: "&?",
            onItemsLoaded: "&?"
        }
    })
} (angular, _),
function(e) {
    "use strict";
    function t(t, n, r, i, a, o, s, c, u, l, d, p) {
        function f() {
            C = t.$watchCollection(function() {
                return a
            },
            function() {
                I.returnUrl = l.currentUrlEncoded()
            })
        }
        function g() {
            var t = I.loadingTracker.createPromise();
            return n.when().then(function() {
                I.vulnList.gridApi.infiniteScroll.saveScrollPercentage()
            }).then(function() {
                var t = {
                    tracker: I.loadingTracker,
                    onRetry: function() {
                        function e() {
                            return g()
                        }
                        return e
                    } ()
                };
                return e.isNumber(I.locId) ? d.getLocationVulnerabilities(I.resultId, I.scanId, I.locId, I.vulnList.nextCursor, u.LIST_PAGE_SIZE, t) : d.getScanVulnerabilities(I.resultId, I.scanId, I.searchQuery, I.vulnList.nextCursor, u.LIST_PAGE_SIZE, t)
            }).then(function(t) {
                var n = t.vulnerabilities,
                r = t.pagination;
                n.forEach(function(e) {
                    I.vulnList.items.find(function(t) {
                        return t.vulnId === e.vulnId
                    }) || I.vulnList.items.push(e)
                }),
                I.vulnList.nextCursor = r.nextCursor,
                I.vulnList.gridApi.infiniteScroll.dataLoaded(!1, e.isDefined(r.nextCursor)),
                I.onItemsLoaded && I.onItemsLoaded({
                    items: I.vulnList.items
                })
            }).
            catch(function(e) {
                return I.vulnList.gridApi.infiniteScroll.dataLoaded(!1, !1),
                n.reject(e)
            }).
            finally(t.resolve)
        }
        function h() {
            var t = I.loadingTracker.createPromise();
            return n.when().then(function() {
                I.vulnTypeList.gridApi.infiniteScroll.saveScrollPercentage()
            }).then(function() {
                var t = I.resultId,
                n = I.scanId,
                r = I.searchQuery,
                i = {
                    onRetry: function() {
                        function e() {
                            return h()
                        }
                        return e
                    } ()
                };
                return d.getScanVulnerabilityTypes(t, n, r, I.vulnTypeList.nextCursor, u.LIST_PAGE_SIZE, i).then(function(t) {
                    var n = t.vulnerabilityTypes,
                    r = t.pagination;
                    n.forEach(function(e) {
                        I.vulnTypeList.items.find(function(t) {
                            return t.vulnTypeId === e.vulnTypeId
                        }) || I.vulnTypeList.items.push(e)
                    }),
                    I.vulnTypeList.nextCursor = r.nextCursor,
                    I.vulnTypeList.gridApi.infiniteScroll.dataLoaded(!1, e.isDefined(r.nextCursor)),
                    I.onItemsLoaded && I.onItemsLoaded({
                        items: I.vulnTypeList.items
                    })
                })
            }).
            catch(function(e) {
                return I.vulnTypeList.gridApi.infiniteScroll.dataLoaded(!1, !1),
                n.reject(e)
            }).
            finally(t.resolve)
        }
        function m() {
            I.vulnTypeList && I.vulnTypeList.gridApi ? I.vulnTypeList.gridApi.infiniteScroll.resetScroll(!1, void 0 !== I.vulnTypeList.nextCursor) : I.vulnList && I.vulnList.gridApi && I.vulnList.gridApi.infiniteScroll.resetScroll(!1, void 0 !== I.vulnList.nextCursor)
        }
        function v() {
            var e = I.groupBy ? I.vulnTypeList: I.vulnList;
            e.items.splice(0),
            e.nextCursor = void 0,
            m();
            var t = n.defer();
            return o(function() {
                w.promise.then(I.groupBy ? h: g).then(t.resolve, t.reject)
            }),
            t.promise
        }
        function y() {
            if (I.layoutSaveKey) {
                var e = I[I.groupBy ? "vulnTypeList": "vulnList"].gridApi;
                p.set(I.layoutSaveKey, e.saveState.save())
            }
        }
        function S() {
            if (I.layoutSaveKey) {
                var e = p.get(I.layoutSaveKey);
                if (e) {
                    I[I.groupBy ? "vulnTypeList": "vulnList"].gridApi.saveState.restore(t, e)
                }
            }
        }
        function b() {
            I.layoutSaveKey && (p.remove(I.layoutSaveKey), i.reload(i.current))
        }
        function T() {
            if (e.isUndefined(I.returnUrl) && f(), I.layoutSaveKey) {
                I[I.groupBy ? "vulnTypeList": "vulnList"].gridOptions.gridMenuCustomItems = [{
                    title: s.getString("Reset Layout"),
                    action: b
                }]
            }
            w.promise.then(v).then(S)
        }
        function x(t) {
            if (e.isDefined(t.returnUrl) && !t.returnUrl.isFirstChange() && (e.isString(t.returnUrl.currentValue) && !C ? f() : e.isUndefined(t.returnUrl) && C && (C(), C = void 0)), e.isDefined(t.groupBy) && !t.groupBy.isFirstChange()) throw new Error("Dynamically changing of groupBy expression is not supported");
            e.isDefined(t.layoutSaveKey) && !t.layoutSaveKey.isFirstChange() && t.layoutSaveKey.previousValue && (p.remove(t.layoutSaveKey.previousValue), y()),
            e.isDefined(t.searchQuery) && !t.searchQuery.isFirstChange() ? v() : e.isDefined(t.locId) && !t.locId.isFirstChange() ? v() : e.isDefined(t.resultId) && !t.resultId.isFirstChange() ? v() : e.isDefined(t.scanId) && !t.scanId.isFirstChange() && v()
        }
        function _() {
            I.loadingTracker.cancel()
        }
        var C, I = this,
        w = n.defer();
        I.loadingTracker = c({
            activationDelay: u.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        I.groupBy ? (I.vulnTypeList = {
            items: [],
            nextCursor: void 0
        },
        I.vulnTypeList.gridOptions = {
            data: I.vulnTypeList.items,
            appScopeProvider: I,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            enableRowHeaderSelection: !1,
            multiSelect: !1,
            gridMenuTitleFilter: r("translate"),
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                cellTemplate: __axtr("/templates/components/vulns/scan-vulns/cell-templates/severity.html"),
                displayName: s.getString("威胁程度"),
                field: "severity",
                headerTooltip: !0,
                width: 40
            },
            {
                cellTemplate: __axtr("/templates/components/vulns/scan-vulns/cell-templates/grouped-name.html"),
                displayName: s.getString("漏洞"),
                field: "name",
                width: 520
            },
            {
                cellFilter: "number",
                displayName: s.getString("分值"),
                field: "count",
                width: 100
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.vulnTypeId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.vulnTypeId
                }
                return e
            } (),
            infiniteScrollRowsFromEnd: 20,
            infiniteScrollUp: !1,
            infiniteScrollDown: !0,
            onRegisterApi: function() {
                function e(e) {
                    I.vulnTypeList.gridApi = e,
                    e.infiniteScroll.on.needLoadMoreData(t, h),
                    e.colResizable.on.columnSizeChanged(t, y),
                    e.core.on.columnVisibilityChanged(t, y),
                    e.core.on.sortChanged(t, y),
                    w.resolve()
                }
                return e
            } ()
        }) : (I.vulnList = {
            items: [],
            nextCursor: void 0
        },
        I.vulnList.gridOptions = {
            data: I.vulnList.items,
            appScopeProvider: I,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            enableRowHeaderSelection: !1,
            multiSelect: !1,
            gridMenuTitleFilter: r("translate"),
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                cellTemplate: __axtr("/templates/components/vulns/scan-vulns/cell-templates/severity.html"),
                displayName: s.getString("威胁程度"),
                field: "severity",
                headerTooltip: !0,
                width: 40
            },
            {
                cellTemplate: __axtr("/templates/components/vulns/scan-vulns/cell-templates/name.html"),
                displayName: s.getString("漏洞"),
                field: "name",
                width: 320
            },
            {
                displayName: s.getString("URL"),
                field: "url",
                width: 420
            },
            {
                cellTemplate: __axtr("/templates/components/vulns/scan-vulns/cell-templates/parameter.html"),
                displayName: s.getString("参数"),
                field: "parameter",
                width: 120
            },
            {
                cellFilter: "axVulnStatus",
                displayName: s.getString("状态"),
                field: "status",
                width: 160
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.vulnId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.vulnId
                }
                return e
            } (),
            infiniteScrollRowsFromEnd: 20,
            infiniteScrollUp: !1,
            infiniteScrollDown: !0,
            onRegisterApi: function() {
                function e(e) {
                    I.vulnList.gridApi = e,
                    e.infiniteScroll.on.needLoadMoreData(t, g),
                    e.colResizable.on.columnSizeChanged(t, y),
                    e.core.on.columnVisibilityChanged(t, y),
                    e.core.on.sortChanged(t, y),
                    w.resolve()
                }
                return e
            } ()
        }),
        I.$onInit = T,
        I.$onChanges = x,
        I.$onDestroy = _,
        t.$on("axScrollTop", m)
    }
    t.$inject = ["$scope", "$q", "$filter", "$state", "$stateParams", "$timeout", "gettextCatalog", "promiseTracker", "axConstant", "axPage", "ResultsApi", "axUserPreferences"],
    e.module("WVS").component("axScanVulns", {
        controller: t,
        templateUrl: __axtr("/templates/components/vulns/scan-vulns/scan-vulns.component.html"),
        bindings: {
            returnUrl: "<?",
            layoutSaveKey: "@?",
            searchQuery: "<?",
            groupBy: "@?",
            scanId: "<",
            resultId: "<",
            locId: "<?",
            onSelectionChanged: "&?",
            onItemsLoaded: "&?"
        }
    })
} (angular),
function(e) {
    "use strict";
    function t(t, n, r, i, a, o, s, c, u) {
        function l(e) {
            return h(function() {
                return u.setVulnerabilityStatus(t.vuln.vulnId, e, {
                    onRetry: function() {
                        function t() {
                            return l(e)
                        }
                        return t
                    } ()
                }).then(function() {
                    t.vuln.status = e,
                    o.success(a.getString("状态已更改"))
                })
            })
        }
        function d() {
            return u.createIssue(t.vuln.vulnId, {
                tracker: t.loadingTracker,
                onRetry: function() {
                    function e() {
                        return d()
                    }
                    return e
                } ()
            }).then(function() {
                return o.success(a.getString("创建问题追踪器")),
                g()
            })
        }
        function p() {
            var n = e.extend(t.$new(), {
                message: a.getString("您确定要重新测试所选的漏洞吗？")
            });
            return c.confirm({
                scope: n
            }).then(function() {
                return u.recheckVulnerability(t.vuln.vulnId, {
                    tracker: t.loadingTracker
                })
            }).then(function() {
                o.success(a.getString("已创建扫描以检查所选的漏洞"))
            })
        }
        function f() {
            t.loadingTracker.cancel()
        }
        function g() {
            return h(function() {
                return u.getVulnerabilityDetails(t.vuln.vulnId, {
                    onRetry: function() {
                        function e() {
                            return g()
                        }
                        return e
                    } ()
                }).then(function(e) {
                    return t.vuln = e
                })
            })
        }
        function h(e) {
            var r = t.loadingTracker.createPromise(),
            i = r.resolve;
            return n.when().then(e).
            finally(i)
        }
        t.loadingTracker = i({
            activationDelay: s.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        t.vuln = {
            vulnId: r.vulnId
        },
        t.changeVulnStatus = l,
        t.onCreateIssues = d,
        t.onRecheckVulnerability = p,
        t.$on("$destroy", f),
        function() {
            g()
        } ()
    }
    t.$inject = ["$scope", "$q", "$stateParams", "promiseTracker", "gettextCatalog", "toastr", "axConstant", "axGeneralModal", "VulnerabilitiesApi"],
    e.module("WVS").controller("axVulnDetailsCtrl", t)
} (angular),
function(e) {
    "use strict";
    function t(t, n, r, i, a, o, s, c) {
        function u() {
            var r = e.extend(t.$new(), {
                message: n.getString("您确定要重新测试所选的漏洞吗？")
            });
            return s.confirm({
                scope: r
            }).then(function() {
                return c.recheckVulnerability(t.resultId, t.scanId, t.vuln.vulnId, {
                    tracker: t.loadingTracker
                })
            }).then(function() {
                a.success(n.getString("已创建扫描以检查所选的漏洞"))
            })
        }
        function l() {
            t.loadingTracker.cancel()
        }
        function d() {
            var e = t.loadingTracker.createPromise();
            return c.getScanVulnerabilityDetails(t.resultId, t.scanId, t.vuln.vulnId, {
                onRetry: function() {
                    function e() {
                        return d()
                    }
                    return e
                } ()
            }).then(function(e) {
                t.vuln = e
            }).
            finally(e.resolve)
        }
        t.loadingTracker = r({
            activationDelay: o.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        t.scanId = i.scanId,
        t.resultId = i.resultId,
        t.vuln = {
            vulnId: i.vulnId
        },
        t.onRecheckVulnerability = u,
        t.$on("$destroy", l),
        function() {
            d()
        } ()
    }
    t.$inject = ["$scope", "gettextCatalog", "promiseTracker", "$stateParams", "toastr", "axConstant", "axGeneralModal", "ResultsApi"],
    e.module("WVS").controller("axResultDetailsCtrl", t)
} (angular),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u, l, d, p, f, g, h, m, v, y, S, b, T, x, _, C, I, w, k) {
        function A(t) {
            return Q(function() {
                var r = e.isString(t) && t.length > 0 ? "name:*" + encodeURIComponent(t) : void 0;
                return o.when().then(function() {
                    if (b.hasFeature("target_groups") !== !0) return o.reject({
                        status: 403
                    })
                }).then(function() {
                    return I.getGroups(r, void 0, 10, {
                        cache: h,
                        noPublishError: !0
                    }).then(function(e) {
                        var t = e.groups;
                        n.searchFilters.groupList = t
                    })
                }).then(function() {
                    if (n.searchFilters.group.length > 0) return n.searchFilters.group.reduce(function(e, t) {
                        return n.searchFilters.groupList.find(function(e) {
                            return e.groupId === n.searchFilters.groupList
                        }) ? e: e.then(function() {
                            return I.getGroup(t, {
                                cache: h,
                                noPublishError: !0
                            })
                        }).then(function(e) {
                            n.searchFilters.groupList.push(e)
                        })
                    },
                    o.when())
                }).then(function() {
                    n.searchFilters.groupList = a(n.searchFilters.groupList, "name")
                }).
                catch(function(e) {
                    return 403 === e.status || e.publishResponseError && e.publishResponseError(e),
                    o.reject(e)
                }).
                finally(G)
            })
        }
        function L(t) {
            return Q(function() {
                var r = e.isString(t) && t.length > 0 ? "text_search:*" + encodeURIComponent(t) : void 0;
                return o.when().then(function() {
                    if (n.filterAsideVisible) return C.getTargets(r, void 0, 10, {
                        cache: g
                    }).then(function(e) {
                        var t = e.targets;
                        n.searchFilters.targetList = t
                    })
                }).then(function() {
                    if (n.searchFilters.target) {
                        if (!n.searchFilters.targetList.find(function(e) {
                            return e.targetId === n.searchFilters.target
                        })) return C.getTarget(n.searchFilters.target, {
                            cache: g
                        }).then(function(e) {
                            n.searchFilters.targetList.push(e)
                        })
                    }
                }).then(function() {
                    n.searchFilters.targetList = a(n.searchFilters.targetList, "address")
                }).
                finally(G)
            })
        }
        function E() {
            n.filterAsideVisible = !n.filterAsideVisible
        }
        function $(t) {
            var i = e.extend(n.$new(), {
                message: u.getPlural(n.selectedItems.length, "您确定要将选定的漏洞标记为 <strong>{{status|axVulnStatus}}</strong>?", "您确定要将选定的漏洞标记为 <strong>{{status|axVulnStatus}}</strong>?", {
                    status: t
                })
            });
            return y.confirm({
                scope: i
            }).then(function() {
                var e = n.loadingTracker.createPromise();
                return n.selectedItems.reduce(function(e, i) {
                    return e.then(function() {
                        return k.setVulnerabilityStatus(i.vulnId, t).then(function() {
                            i.status = t,
                            null !== n.searchFilters.status && ("!open" === n.searchFilters.status && "open" !== i.status ? r.$emit("axRemoveVulnItem", i) : n.searchFilters.status !== i.status && r.$emit("axRemoveVulnItem", i))
                        })
                    })
                },
                o.when()).then(function() {
                    s.success(u.getString("Status changed"))
                }).
                finally(e.resolve)
            }).
            finally(function() {
                return i.$destroy()
            })
        }
        function R() {
            return x.currentUrlEncoded()
        }
        function P(e) {
            var t = n.searchFilters;
            switch (t.filterTags.splice(t.filterTags.indexOf(e), 1), e.key) {
            case "severity":
                t.severity = [];
                break;
            case "criticality":
                t.criticality = [];
                break;
            case "status":
                t.status = null;
                break;
            case "cvss":
                t.cvss = null;
                break;
            case "target":
                t.target = null;
                break;
            case "group":
                t.group = [];
                break;
            case "vuln_type":
                t.vulnType = null
            }
            q()
        }
        function N(e) {
            n.selectedItems = e
        }
        function D() {
            S.chooseReportOptions().then(function(e) {
                var t = n.selectedItems.map(function(e) {
                    return e.vulnId
                });
                return W(e.templateId, {
                    listType: "vulnerabilities",
                    idList: t
                })
            }).then(function() {
                d.go("app.list_reports")
            })
        }
        function U(e, t) {
            var r = [];
            return "all_vulnerabilities" !== t && (r = n.selectedItems.map(function(e) {
                return e.vulnId
            })),
            Y(e, {
                listType: t,
                idList: r
            })
        }
        function V() {
            var i = n.loadingTracker.createPromise(),
            a = {
                failures: []
            },
            l = n.selectedItems.length;
            return o.when().then(function() {
                return n.selectedItems.reduce(function(e, t) {
                    var n = t.vulnId;
                    return e.then(function() {
                        return k.createIssue(n, {
                            noPublishError: !0
                        })
                    }).then(function() {
                        r.$emit("axDeselectVulnerability", {
                            vulnId: n
                        })
                    }).
                    catch(function(e) {
                        return 401 === e.status ? o.reject(e) : (a.failures.push({
                            vulnId: n,
                            errorMessage: e.errorMessage
                        }), null)
                    })
                },
                o.when())
            }).then(function() {
                if (i.resolve(), a.failures.length > 0) {
                    var r = e.extend(n.$new(), {
                        message: c("有些漏洞可能不会被发送到问题跟踪器 - 他们留下选择。") + '<br/><strong class="block text-danger m-t-sm m-b-sm">错误:<br/></strong><ul>' + t.chain(a.failures).uniqBy(t.property("errorMessage")).map(function(e) {
                            var t = e.errorMessage;
                            return "<li>" + String(f(t)) + "</li>"
                        }).join("").value() + "</ul>"
                    });
                    return y.alert({
                        scope: r
                    }).
                    finally(function() {
                        return r.$destroy()
                    })
                }
            }).then(function() {
                0 === a.failures.length && s.success(u.getPlural(l, "创建问题追踪器", "创建问题追踪器"))
            }).
            finally(i.resolve)
        }
        function M() {
            var i = e.extend(n.$new(), {
                message: u.getPlural(n.selectedItems.length, "您确定要重新测试所选的漏洞吗？", "您确定要重新测试所选的漏洞吗？")
            });
            return y.confirm({
                scope: i
            }).then(function() {
                var i = n.loadingTracker.createPromise(),
                a = {
                    failures: []
                },
                l = n.selectedItems.length;
                return o.when().then(function() {
                    return n.selectedItems.reduce(function(e, t) {
                        var n = t.vulnId;
                        return e.then(function() {
                            return k.recheckVulnerability(n, {
                                noPublishError: !0
                            })
                        }).then(function() {
                            r.$emit("axDeselectVulnerability", {
                                vulnId: n
                            })
                        }).
                        catch(function(e) {
                            return 401 === e.status ? o.reject(e) : (a.failures.push({
                                vulnId: n,
                                errorMessage: e.errorMessage
                            }), null)
                        })
                    },
                    o.when())
                }).then(function() {
                    if (i.resolve(), a.failures.length > 0) {
                        var r = e.extend(n.$new(), {
                            message: c("Some vulnerabilities could not be retested - they are left selected.") + '<br/><strong class="block text-danger m-t-sm m-b-sm">Errors:<br/></strong><ul>' + t.chain(a.failures).uniqBy(t.property("errorMessage")).map(function(e) {
                                var t = e.errorMessage;
                                return "<li>" + String(f(t)) + "</li>"
                            }).join("").value() + "</ul>"
                        });
                        return y.alert({
                            scope: r
                        }).
                        finally(function() {
                            return r.$destroy()
                        })
                    }
                }).then(function() {
                    0 === a.failures.length && s.success(u.getPlural(l, "A scan has been created to check the selected vulnerability", "Several scans have been created to check the selected vulnerabilities"))
                }).
                finally(i.resolve)
            })
        }
        function F() {
            return w.addTarget().then(function(e) {
                d.go("app.target_config", {
                    returnUrl: R(),
                    targetId: e.targetId
                },
                {
                    inherit: !1
                })
            })
        }
        function O() {
            n.loadingTracker.cancel()
        }
        function H(e, t) {
            t !== e && (B(), G(), q())
        }
        function j(e, t) {
            e === t || J || d.reload(d.current)
        }
        function G() {
            var e = n.searchFilters,
            t = [];
            if (e.severity.length > 0 && t.push({
                key: "severity",
                label: c("威胁程度:"),
                value: e.severity.map(function(t) {
                    var n = e.severityList.find(function(e) {
                        return e.value === t
                    });
                    return u.getString(n.text)
                }).join(", ")
            }), e.criticality.length > 0 && t.push({
                label: c("Criticality:"),
                key: "criticality",
                value: e.criticality.map(function(t) {
                    var n = e.criticalityList.find(function(e) {
                        return e.value === t
                    });
                    return u.getString(n.text)
                }).join(", ")
            }), e.status) {
                var r = e.statusList.find(function(t) {
                    return t.value === e.status
                });
                t.push({
                    key: "status",
                    label: c("状态:"),
                    value: u.getString(r.text)
                })
            }
            if (e.cvss) {
                var i = e.cvssList.find(function(t) {
                    return t.value === e.cvss
                });
                t.push({
                    key: "cvss",
                    label: "CVSS:",
                    value: u.getString(i.text)
                })
            }
            if (e.target) {
                var a = e.targetList.find(function(t) {
                    return t.targetId === e.target
                });
                t.push({
                    key: "target",
                    label: c("目标:"),
                    value: a ? a.address: u.getString("N/A")
                })
            }
            e.group.length > 0 && t.push({
                label: c("组织:"),
                key: "group",
                value: e.group.map(function(t) {
                    var n = e.groupList.find(function(e) {
                        return e.groupId === t
                    });
                    return n ? u.getString(n.name) : u.getString("N/A")
                }).join(", ")
            }),
            e.vulnType && t.push({
                key: "vuln_type",
                label: c("漏洞类型:"),
                value: e.vulnTypeName || e.vulnType
            }),
            n.searchFilters.filterTags = t
        }
        function q() {
            var e = n.searchFilters;
            J = !0;
            var t = {
                severity: e.severity.length > 0 ? e.severity.join(",") : void 0,
                criticality: e.criticality.length > 0 ? e.criticality.join(",") : void 0,
                status: null !== e.status ? e.status: void 0,
                cvss: null !== e.cvss ? e.cvss: void 0,
                target: null !== e.target ? e.target: void 0,
                group: e.group.length > 0 ? e.group.join(",") : void 0,
                type: null !== e.vulnType ? e.vulnType: void 0,
                returnUrl: R()
            };
            d.go(d.current.name, t, {
                inherit: !1
            }).
            finally(function() {
                J = !1
            })
        }
        function B() {
            var e = n.searchFilters,
            t = [];
            e.severity.length > 0 && t.push("severity:" + e.severity.join(",")),
            e.criticality.length > 0 && t.push("criticality:" + e.criticality.join(",")),
            e.status && ("rediscovered" === e.status ? (t.push("status:open"), t.push("rediscovered:true")) : t.push("status:" + e.status)),
            e.cvss && ("4" === e.cvss ? t.push("cvss_score:<=" + e.cvss) : "4-7" === e.cvss ? (t.push("cvss_score:>=4"), t.push("cvss_score:<=7")) : "7" === e.cvss && t.push("cvss_score:>=" + e.cvss)),
            e.target && t.push("target_id:" + e.target),
            e.group.length > 0 && t.push("group_id:" + e.group.join(",")),
            e.vulnType && t.push("vt_id:" + e.vulnType),
            e.searchQuery = t.join(";")
        }
        function K() {
            return Q(function() {
                return k.getVulnerabilityType(n.searchFilters.vulnType, {
                    tracker: n.loadingTracker,
                    cache: m
                }).then(function(e) {
                    var t = e.name;
                    n.searchFilters.vulnTypeName = t
                }).
                finally(G)
            })
        }
        function W(e, t) {
            return T.generateNewReport(e, t, {
                tracker: n.loadingTracker,
                onRetry: function() {
                    function n() {
                        return W(e, t)
                    }
                    return n
                } ()
            }).then(function() {
                s.success(u.getString("Your report is being created"))
            })
        }
        function z() {
            var t = n.loadingTracker.createPromise();
            return T.getExportTypes("vulnerabilities").then(function(t) {
                n.exportTemplateTypeList = t.map(function(t) {
                    return e.extend(t, {
                        sourceType: "vulnerabilities"
                    })
                })
            }).
            finally(t.resolve)
        }
        function Y(t, r) {
            if (ee.active()) {
                var i = {
                    scope: e.extend(n.$new(), {
                        message: c("Another download is in progress.")
                    })
                };
                return y.alert(i).
                finally(i.scope.$destroy)
            }
            var a = n.loadingTracker.createPromise();
            return T.generateNewExport(t, r, {
                onRetry: function() {
                    function e() {
                        return Y(t, r)
                    }
                    return e
                } ()
            }).then(function(e) {
                "failed" !== e.status && s.success(u.getString("Your download will automatically start in a few moments")),
                Z(e.reportId)
            }).
            finally(a.resolve)
        }
        function Z(t) {
            var a, s, u = ee.createPromise(),
            l = !1;
            return l ? o.when() : (a = i(function() {
                return l = !0,
                T.getExport(t, {
                    tracker: ee,
                    noPublishError: !0
                }).then(function(t) {
                    if (null === t) {
                        var n = {
                            errorMessage: c("Your report could not be downloaded [Report deleted]")
                        };
                        return u.reject(n),
                        o.reject(n)
                    }
                    if ("failed" === t.status) {
                        var r = {
                            errorMessage: c("Your data could not be exported [Failed]")
                        };
                        return o.reject(r)
                    } (t.downloadLinkPDF || t.downloadLinkHTML || t.downloadLinkXML) && (e.element("#download-helper").attr("src", t.downloadLinkPDF || t.downloadLinkHTML || t.downloadLinkXML), u.resolve())
                }).
                catch(function(e) {
                    throw u.reject(e),
                    r.$emit("axError", e),
                    e
                }).
                finally(function() {
                    l = !1
                })
            },
            1e3), s = n.$on("$destroy", a.cancel), u.promise.
            finally(function() {
                i.cancel(a),
                s()
            }), u.promise)
        }
        function Q(e) {
            var t = n.loadingTracker.createPromise();
            return o.when().then(e).
            finally(t.resolve)
        }
        function X() {
            return k.getVulnerabilities(void 0, void 0, 1, {
                noLoadingTracker: !0
            }).then(function(e) {
                return 0 === e.vulnerabilities.length && C.getTargets(void 0, void 0, 1, {
                    noLoadingTracker: !0
                }).then(function(e) {
                    return 0 === e.targets.length
                })
            }).then(function(e) {
                n.noTargetsOrScansInSystem = e
            })
        }
        var J = !1,
        ee = l({
            activationDelay: v.PROMISE_TRACKER_ACTIVATION_DELAY
        });
        n.loadingTracker = l({
            activationDelay: v.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        n.filterAsideVisible = !1,
        n.returnUrl = p.returnUrl,
        n.searchFilters = {
            searchQuery: "",
            severity: _.getStateParam("severity", !0, t.map(v.VULN_SEVERITY_LEVEL, t.property("value"))),
            severityList: v.VULN_SEVERITY_LEVEL,
            criticality: _.getStateParam("criticality", !0, t.map(v.BUSINESS_CRITICALITY, t.property("value"))),
            criticalityList: v.BUSINESS_CRITICALITY,
            status: _.getStateParam("status", !1, t.map(v.VULN_STATUS, t.property("value")).concat(["!open"])),
            statusList: v.VULN_STATUS.concat([{
                value: "!open",
                text: c("Not Open")
            }]),
            cvss: _.getStateParam("cvss", !1, t.map(v.CVSS_SCORE, t.property("value"))),
            cvssList: v.CVSS_SCORE,
            target: _.getStateParam("target"),
            targetList: [],
            group: _.getStateParam("group", !0),
            groupList: [],
            vulnType: _.getStateParam("type"),
            vulnTypeName: null,
            filterTags: []
        },
        n.selectedItems = [],
        n.exportTemplateTypeList = [],
        n.noTargetsOrScansInSystem = !1,
        n.toggleFilter = E,
        n.changeVulnStatus = $,
        n.searchTargets = L,
        n.searchGroups = A,
        n.currentUrl = R,
        n.removeFilterTag = P,
        n.onVulnerabilitiesSelectionChanged = N,
        n.onGenerateReport = D,
        n.onExport = U,
        n.onCreateIssues = V,
        n.onRecheckVulnerability = M,
        n.addTargetModal = F,
        n.$on("$destroy", O),
        n.$watch("searchFilters.severity", H),
        n.$watch("searchFilters.criticality", H),
        n.$watch("searchFilters.status", H),
        n.$watch("searchFilters.cvss", H),
        n.$watch("searchFilters.target", H),
        n.$watch("searchFilters.group", H),
        n.$watch("searchFilters.vulnType", H),
        n.$watchCollection(function() {
            return p
        },
        j),
        function() {
            B(),
            G(),
            L(),
            A(),
            z(),
            n.searchFilters.vulnType && K(),
            X()
        } ()
    }
    n.$inject = ["$scope", "$rootScope", "$interval", "orderByFilter", "$q", "toastr", "gettext", "gettextCatalog", "promiseTracker", "$state", "$stateParams", "axEscapeHtmlFilter", "axTargetsCache", "axGroupsCache", "axVulnTypesCache", "axConstant", "axGeneralModal", "axReportOptionsModal", "CurrentUser", "ReportsApi", "axPage", "axStateHelpers", "TargetsApi", "TargetGroupsApi", "axTargetModal", "VulnerabilitiesApi"],
    e.module("WVS").controller("axListVulnsCtrl", n)
} (angular, _),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u, l, d, p, f, g) {
        function h(e, t) {
            var r = {
                current: e,
                next: t
            };
            return n.$broadcast("axSectionChanging", r),
            r.cancel !== !0
        }
        function m() {
            t.set(i, "current.data.page.subtitle", ""),
            n.loadingTracker.cancel()
        }
        var v = function(e) {
            return t.findIndex(n.sections.items, t.matchesProperty("name", e))
        };
        n.loadingTracker = p({
            activationDelay: o.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        n.currentSection = a.section,
        n.sections = {
            currentIndex: 0,
            items: [{
                name: "general",
                heading: l("总设置")
            },
            {
                name: "crawl",
                heading: l("爬行")
            },
            {
                name: "http",
                heading: l("HTTP")
            },
            {
                name: "advanced",
                heading: l("高级")
            }]
        },
        n.sections.currentIndex = v(a.section),
        n.uiForms = {},
        n.$on("$destroy", m),
        function() {
            t.set(i, "current.data.page.subtitle", g.target.address)
        } (),
        n.onChangeSection = function(e, t) {
            e !== n.currentSection && (h(n.currentSection, e) ? n.changeSection(e) : t && t.preventDefault())
        },
        n.currentUrl = function() {
            return c.currentUrlEncoded()
        },
        n.onCreateScan = function() {
            var e = !1,
            t = null,
            r = n.currentUrl(),
            a = function(n) {
                var r = n.scanId;
                "instant" === n.scanningOptions.scheduleType && (e = !0, t = r)
            },
            o = function() {
                e ? i.go("app.scan_details", {
                    view: "stats",
                    scanId: t,
                    returnUrl: r
                },
                {
                    inherit: !1
                }) : i.go("app.list_scans", {
                    returnUrl: r
                },
                {
                    inherit: !1
                })
            };
            return u.createScansWizard([g.target], n.loadingTracker).then(o, null, a)
        },
        n.notifyTargetUpdated = function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : l("Target updated");
            f.success(d.getString(e))
        },
        n.askSaveChanges = function() {
            var t = e.extend(n.$new(), {
                message: l("Save current changes?")
            }),
            i = r.defer();
            return s.confirm({
                scope: t
            }).then(i.resolve, i.reject).
            finally(function() {
                return t.$destroy()
            }),
            i.promise
        },
        n.reloadSection = function() {
            i.go(i.current.name, {
                section: n.currentSection
            },
            {
                reload: i.current.name
            })
        },
        n.changeSection = function(e) {
            v(e) !== n.sections.currentIndex && i.go(i.current.name, {
                section: e
            },
            {
                reload: i.current.name
            })
        }
    }
    n.$inject = ["$scope", "$q", "$state", "$stateParams", "axConstant", "axGeneralModal", "axPage", "axScansModal", "gettext", "gettextCatalog", "promiseTracker", "toastr", "targetInfo"],
    e.module("WVS").controller("axTargetConfigCtrl", n)
} (angular, _),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u, l, d, p, f, g, h, m, v, y, S, b, T, x, _, C, I, w, k, A) {
        function L(t) {
            return se(function() {
                var r = e.isString(t) && t.length > 0 ? "name:*" + encodeURIComponent(t) : void 0;
                return a.when().then(function() {
                    if (S.hasFeature("target_groups") !== !0) return a.reject({
                        status: 403
                    })
                }).then(function() {
                    return A.getGroups(r, void 0, 10, {
                        cache: v,
                        noPublishError: !0
                    }).then(function(e) {
                        var t = e.groups;
                        n.searchFilters.groupList = t
                    })
                }).then(function() {
                    if (n.searchFilters.group.length > 0) return n.searchFilters.group.reduce(function(e, t) {
                        return n.searchFilters.groupList.find(function(e) {
                            return e.groupId === t
                        }) ? e: e.then(function() {
                            return A.getGroup(t, {
                                cache: v,
                                noPublishError: !0
                            })
                        }).then(function(e) {
                            n.searchFilters.groupList.push(e)
                        })
                    },
                    a.when())
                }).then(function() {
                    n.searchFilters.groupList = l(n.searchFilters.groupList, "name")
                }).
                catch(function(e) {
                    return 403 === e.status || e.publishResponseError && e.publishResponseError(e),
                    a.reject(e)
                }).
                finally(Y)
            })
        }
        function E() {
            n.filterAsideVisible = !n.filterAsideVisible
        }
        function $() {
            var e = n.targetList.gridApi && n.targetList.gridApi.selection;
            return e ? e.getSelectedRows() : []
        }
        function R() {
            var e = n.targetList.gridApi && n.targetList.gridApi.selection;
            return e ? e.getSelectedCount() : 0
        }
        function P() {
            return I.addTarget().then(function(e) {
                o.go("app.target_config", {
                    returnUrl: U(),
                    targetId: e.targetId
                },
                {
                    inherit: !1
                })
            })
        }
        function N() {
            var t = e.extend(n.$new(), {
                message: d(R() > 1 ? "您确定要删除所选的目标吗？ 所选目标的扫描也将被删除。": "您确定要删除所选的目标吗？ 所选目标的扫描也将被删除。")
            });
            return m.confirm({
                scope: t
            }).then(Q).
            finally(function() {
                return t.$destroy()
            })
        }
        function D() {
            return I.configureGroups($())
        }
        function U() {
            return T.currentUrlEncoded()
        }
        function V(e) {
            var t = n.searchFilters;
            switch (t.filterTags.splice(t.filterTags.indexOf(e), 1), e.key) {
            case "threat":
                t.threatLevel = [];
                break;
            case "criticality":
                t.criticality = [];
                break;
            case "group":
                t.group = [];
                break;
            case "scanned":
                t.lastScannedType = null;
                break;
            case "free_text":
                t.freeText = null
            }
            Z()
        }
        function M() {
            return $().filter(function(e) {
                return !! e.lastScanResultId
            }).length > 0
        }
        function F() {
            x.chooseReportOptions().then(function(e) {
                var t = $().filter(function(e) {
                    return !! e.lastScanResultId
                }).map(function(e) {
                    return e.targetId
                });
                return ee(e.templateId, {
                    listType: "targets",
                    idList: t
                })
            }).then(function() {
                o.go("app.list_reports", {
                    returnUrl: U()
                },
                {
                    inherit: !1
                })
            })
        }
        function O() {
            return R() > 0 && $().filter(function(e) {
                return !! e.lastScanResultId
            }).length > 0
        }
        function H(e, t) {
            return ne(e, {
                listType: t,
                idList: $().filter(function(e) {
                    return !! e.lastScanResultId
                }).map(function(e) {
                    return e.targetId
                })
            })
        }
        function j() {
            var e = R(),
            t = !1,
            r = null,
            i = U(),
            a = function(i) {
                var a = i.target,
                o = i.scanId,
                s = i.scanningOptions;
                n.targetList.gridApi.selection.unSelectRow(a),
                1 === e && "instant" === s.scheduleType && (t = !0, r = o)
            },
            s = function() {
                t ? o.go("app.scan_details", {
                    view: "stats",
                    scanId: r,
                    returnUrl: i
                },
                {
                    inherit: !1
                }) : o.go("app.list_scans", {
                    returnUrl: i
                },
                {
                    inherit: !1
                })
            };
            return _.createScansWizard($(), n.loadingTracker).then(s, null, a)
        }
        function G() {
            n.loadingTracker.cancel()
        }
        function q(r) {
            var i = n.loadingTracker.createPromise();
            return a.when().then(function() {
                n.targetList.gridApi.infiniteScroll.saveScrollPercentage()
            }).then(function() {
                return k.getTargets(z(), n.targetList.nextCursor, t.get(r, "limit", h.LIST_PAGE_SIZE), {
                    onRetry: function() {
                        function e() {
                            return q(r)
                        }
                        return e
                    } ()
                })
            }).then(function(t) {
                var r = t.targets,
                i = t.pagination;
                r.forEach(function(e) {
                    n.targetList.items.find(function(t) {
                        return t.targetId === e.targetId
                    }) || n.targetList.items.push(e)
                }),
                n.targetList.nextCursor = i.nextCursor,
                n.targetList.gridApi.infiniteScroll.dataLoaded(!1, e.isDefined(i.nextCursor))
            }).
            catch(function(e) {
                return n.targetList.gridApi.infiniteScroll.dataLoaded(!1, !1),
                a.reject(e)
            }).
            finally(i.resolve)
        }
        function B(t) {
            n.targetList.hasFilters = e.isString(t) && t.length > 0
        }
        function K(e, t) {
            t !== e && ("before_date" !== e ? (Y(), Z(), ce()) : (n.searchFilters.lastScannedDate = null, n.searchFilters.lastScannedDateCalendarVisible = !0))
        }
        function W(e, t) {
            e === t || ue || o.reload(o.current)
        }
        function z() {
            var e = n.searchFilters,
            r = [],
            i = t.curryRight(t.join, 2)(",");
            return e.threatLevel.length > 0 && r.push("threat:" + i(e.threatLevel)),
            e.criticality.length > 0 && r.push("criticality:" + i(e.criticality)),
            e.group.length > 0 && r.push("group_id:" + i(e.group)),
            "never" === e.lastScannedType ? r.push("never_scanned") : "before_date" === e.lastScannedType && e.lastScannedDate && r.push("last_scanned:<=" + encodeURIComponent(u(e.lastScannedDate, "yyyy-MM-ddTHH:mm:ss.sssZ"))),
            e.freeText && r.push("text_search:*" + encodeURIComponent(e.freeText)),
            r.join(";")
        }
        function Y() {
            var e = n.searchFilters,
            r = [],
            i = t.curryRight(t.join, 2)(", "),
            a = function(e, n) {
                return p.getString(t.get(n, e, d("N/A")))
            };
            e.threatLevel.length > 0 && r.push({
                key: "threat",
                label: d("Threat:"),
                value: i(e.threatLevel.map(function(t) {
                    var n = e.threatLevelList.find(function(e) {
                        return e.value == t
                    });
                    return a("text", n)
                }))
            }),
            e.criticality.length > 0 && r.push({
                label: d("Criticality:"),
                key: "criticality",
                value: i(e.criticality.map(function(t) {
                    var n = e.criticalityList.find(function(e) {
                        return e.value == t
                    });
                    return a("text", n)
                }))
            }),
            e.group.length > 0 && r.push({
                label: d("Groups:"),
                key: "group",
                value: i(e.group.map(function(t) {
                    var n = e.groupList.find(function(e) {
                        return e.groupId === t
                    });
                    return a("name", n)
                }))
            }),
            "never" === e.lastScannedType && r.push({
                key: "scanned",
                label: d("Last Scanned:"),
                value: p.getString("Never")
            }),
            "before_date" === e.lastScannedType && e.lastScannedDate && r.push({
                key: "scanned",
                label: d("Last Scanned:"),
                value: "Before " + u(e.lastScannedDate, "mediumDate")
            }),
            e.freeText && r.push({
                key: "free_text",
                label: d("Free Text:"),
                value: e.freeText
            }),
            e.filterTags = r
        }
        function Z() {
            var e = n.searchFilters;
            ue = !0;
            var t = {};
            e.threatLevel.length > 0 && (t.threat = e.threatLevel.join(",")),
            e.criticality.length > 0 && (t.criticality = e.criticality.join(",")),
            e.group.length > 0 && (t.group = e.group.join(",")),
            "never" === e.lastScannedType && (t.never_scanned = !0),
            "before_date" === e.lastScannedType && e.lastScannedDate && (t.scanned_before = u(e.lastScannedDate, "yyyy-MM-ddTHH:mm:ss.sssZ")),
            e.freeText && (t.free = e.freeText),
            s.returnUrl && (t.returnUrl = s.returnUrl),
            n.launchScanView && (t.ls = s.ls),
            n.generateReportView && (t.gr = s.gr),
            o.go(o.current.name, t, {
                inherit: !1
            }).
            finally(function() {
                ue = !1
            })
        }
        function Q() {
            var e = n.loadingTracker.createPromise();
            return $().reduce(function(e, t) {
                return e.then(function() {
                    return k.removeTarget(t.targetId)
                }).then(function() {
                    n.targetList.gridApi.selection.unSelectRow(t),
                    n.targetList.items.splice(n.targetList.items.indexOf(t), 1)
                })
            },
            a.when()).then(function() {}).
            finally(e.resolve)
        }
        function X() {
            n.targetList.gridApi && n.targetList.gridApi.infiniteScroll.resetScroll(!1, void 0 !== n.targetList.nextCursor)
        }
        function J() {
            return y.addGroup().then(D)
        }
        function ee(e, t) {
            return se(function() {
                return b.generateNewReport(e, t, {
                    tracker: n.loadingTracker,
                    onRetry: function() {
                        function n() {
                            return ee(e, t)
                        }
                        return n
                    } ()
                }).then(function() {
                    g.success(p.getString("Your report is being created"))
                })
            })
        }
        function te() {
            return b.getExportTypes("targets", {
                tracker: n.loadingTracker
            }).then(function(t) {
                n.exportTemplateTypeList = t.map(function(t) {
                    return e.extend(t, {
                        sourceType: "targets"
                    })
                })
            })
        }
        function ne(t, r) {
            if (de.active()) {
                var i = e.extend(n.$new(), {
                    message: d("Another download is in progress.")
                });
                return m.alert({
                    scope: i
                }).
                finally(function() {
                    return i.$destroy()
                })
            }
            var a = n.loadingTracker.createPromise();
            return b.generateNewExport(t, r, {
                onRetry: function() {
                    function e() {
                        return ne(t, r)
                    }
                    return e
                } ()
            }).then(function(e) {
                "failed" !== e.status && g.success(p.getString("Your download will automatically start in a few moments")),
                re(e.reportId)
            }).
            finally(a.resolve)
        }
        function re(t) {
            var o = de.createPromise(),
            s = !1,
            c = void 0,
            u = void 0;
            return s ? a.when() : (c = i(function() {
                return s = !0,
                b.getExport(t, {
                    tracker: de,
                    noPublishError: !0
                }).then(function(t) {
                    if (null === t) {
                        var n = {
                            errorMessage: d("Your report could not be downloaded [Report deleted]")
                        };
                        return o.reject(n),
                        a.reject(n)
                    }
                    if ("failed" === t.status) {
                        var r = {
                            errorMessage: d("Your data could not be exported [Failed]")
                        };
                        return a.reject(r)
                    } (t.downloadLinkPDF || t.downloadLinkHTML || t.downloadLinkXML) && (e.element("#download-helper").attr("src", t.downloadLinkPDF || t.downloadLinkHTML || t.downloadLinkXML), o.resolve())
                }).
                catch(function(e) {
                    throw o.reject(e),
                    r.$emit("axError", e),
                    e
                }).
                finally(function() {
                    s = !1
                })
            },
            1e3), u = n.$on("$destroy", c.cancel), o.promise.
            finally(function() {
                i.cancel(c),
                u()
            }), o.promise)
        }
        function ie() {
            w.set("list-targets", n.targetList.gridApi.saveState.save())
        }
        function ae() {
            var e = w.get("list-targets");
            e && n.targetList.gridApi.saveState.restore(n, e)
        }
        function oe() {
            w.remove("list-targets"),
            o.reload(o.current)
        }
        function se(e) {
            var t = n.loadingTracker.createPromise();
            return a.when().then(e).
            finally(t.resolve)
        }
        function ce() {
            n.targetList.items.splice(0),
            n.targetList.nextCursor = void 0,
            n.targetList.gridApi && n.targetList.gridApi.selection && n.targetList.gridApi.selection.clearSelectedRows(),
            X();
            var e = a.defer();
            return c(function() {
                le.promise.then(function() {
                    return q()
                }).then(function() {
                    return e.resolve()
                },
                e.reject)
            }),
            e.promise
        }
        var ue = !1,
        le = a.defer(),
        de = f({
            activationDelay: h.PROMISE_TRACKER_ACTIVATION_DELAY
        });
        n.loadingTracker = f({
            activationDelay: h.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        n.targetList = {
            items: [],
            nextCursor: void 0,
            hasFilters: !1
        },
        n.targetList.gridOptions = {
            data: n.targetList.items,
            appScopeProvider: n,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                cellTemplate: __axtr("/templates/targets/list-targets/cell/address.html"),
                displayName: p.getString("地址"),
                field: "address",
                width: 320
            },
            {
                cellTooltip: !0,
                displayName: p.getString("备注"),
                field: "description",
                width: 240
            },
            {
                cellFilter: "axBusinessCriticality",
                displayName: p.getString("业务重要性"),
                field: "criticality",
                visible: r.appConfig.showBusinessCriticality,
                width: 160
            },
            {
                cellTemplate: __axtr("/templates/targets/list-targets/cell/status.html"),
                displayName: p.getString("状态"),
                field: "status",
                width: 300
            },
            {
                cellTemplate: __axtr("/templates/targets/list-targets/cell/vuln-counters.html"),
                displayName: p.getString("漏洞"),
                field: "severityCounts",
                width: 160
            }],
            gridMenuCustomItems: [{
                title: p.getString("重置布局"),
                action: oe
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.targetId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.targetId
                }
                return e
            } (),
            infiniteScrollRowsFromEnd: 20,
            infiniteScrollUp: !1,
            infiniteScrollDown: !0,
            onRegisterApi: function() {
                function e(e) {
                    n.targetList.gridApi = e,
                    e.infiniteScroll.on.needLoadMoreData(n, q),
                    e.colResizable.on.columnSizeChanged(n, ie),
                    e.core.on.columnVisibilityChanged(n, ie),
                    e.core.on.sortChanged(n, ie),
                    le.resolve(e)
                }
                return e
            } ()
        },
        S.hasFeature("target_business_criticality") !== !0 && t.remove(n.targetList.gridOptions.columnDefs, t.matchesProperty("field", "criticality")),
        n.searchFilters = {
            threatLevel: C.getStateParam("threat", !0, t.map(h.THREAT_LEVEL, t.property("value"))),
            threatLevelList: h.THREAT_LEVEL,
            criticality: C.getStateParam("criticality", !0, t.map(h.BUSINESS_CRITICALITY, t.property("value"))),
            criticalityList: h.BUSINESS_CRITICALITY,
            lastScannedType: s.never_scanned ? "never": s.scanned_before ? "before_date": null,
            lastScannedTypeList: [{
                value: null,
                text: d("All")
            },
            {
                value: "never",
                text: d("Never scanned")
            },
            {
                value: "before_date",
                text: d("Before a specific date")
            }],
            lastScannedDate: s.scanned_before ? new Date(C.getStateParam("scanned_before")) : null,
            lastScannedDateCalendarVisible: !0,
            freeText: C.getStateParam("free"),
            group: C.getStateParam("group", !0),
            groupList: [],
            filterTags: []
        },
        n.filterAsideVisible = !1,
        n.lastScannedDateDatePickerOptions = {
            showWeeks: !1
        },
        n.launchScanView = !!s.ls,
        n.generateReportView = !!s.gr,
        n.exportTemplateTypeList = [],
        n.selectedItems = $,
        n.selectedItemsCount = R,
        n.toggleFilter = E,
        n.addTargetModal = P,
        n.onDeleteSelectedTargets = N,
        n.updateGroupMembership = D,
        n.searchGroups = L,
        n.currentUrl = U,
        n.removeFilterTag = V,
        n.canGenerateReport = M,
        n.onGenerateReport = F,
        n.onScanModal = j,
        n.onExport = H,
        n.canExport = O,
        n.$on("$destroy", G),
        n.$on("axScrollTop", X),
        n.$on("axCreateGroupModal", J),
        n.$watch("searchFilters.threatLevel", K),
        n.$watch("searchFilters.criticality", K),
        n.$watch("searchFilters.group", K),
        n.$watch("searchFilters.lastScannedDate", K),
        n.$watch("searchFilters.freeText", K),
        n.$watch("searchFilters.lastScannedType", K),
        n.$watchCollection(function() {
            return s
        },
        W),
        n.$watch(z, B),
        function() {
            if (Y(), L(), te(), le.promise.then(function() {
                return q()
            }).then(ae).then(function() {
                c(function() {
                    return n.targetList.gridApi.core.handleWindowResize()
                },
                0)
            }), s.ls) {
                var e = o.current.data;
                e.page.subtitle = d("Create Scan"),
                e.page.section = "",
                n.$on("$destroy",
                function() {
                    e && e.page && (delete e.page.subtitle, e.page.section = "targets")
                })
            } else if (s.gr) {
                var t = o.current.data;
                t.page.subtitle = d("Generate Report"),
                t.page.section = "",
                n.$on("$destroy",
                function() {
                    t && t.page && (delete t.page.subtitle, t.page.section = "targets")
                })
            }
        } ()
    }
    n.$inject = ["$scope", "$rootScope", "$interval", "$q", "$state", "$stateParams", "$timeout", "dateFilter", "orderByFilter", "gettext", "gettextCatalog", "promiseTracker", "toastr", "axConstant", "axGeneralModal", "axGroupsCache", "axAddGroupModal", "CurrentUser", "ReportsApi", "axPage", "axReportOptionsModal", "axScansModal", "axStateHelpers", "axTargetModal", "axUserPreferences", "TargetsApi", "TargetGroupsApi"],
    e.module("WVS").controller("axListTargetsCtrl", n)
} (angular, _),
function(e, t) {
    "use strict";
    function n(t, n, r, i, a, o, s, c, u, l, d, p) {
        function f(e, n) {
            var r = {
                current: e,
                next: n
            };
            return t.$broadcast("axSectionChanging", r),
            r.cancel !== !0
        }
        function g() {
            t.loadingTracker.cancel()
        }
        var h = function(e) {
            return t.sections.items.find(function(t) {
                return t.name === e
            })
        },
        m = function(e) {
            var n = t.sections.items.findIndex(function(t) {
                return t.name === e
            });
            return n > -1 ? t.sections.items.splice(n, 1) : null
        };
        t.loadingTracker = s({
            activationDelay: l.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        t.uiForms = {},
        t.sections = {
            current: null,
            items: [{
                name: "updates",
                heading: a("产品更新")
            },
            {
                name: "proxy",
                heading: a("代理设置")
            },
            {
                name: "notifications",
                heading: a("通知设置")
            },
            {
                name: "users",
                heading: a("用户")
            },
            {
                name: "target-groups",
                heading: a("目标群体")
            },
            {
                name: "issue-trackers",
                heading: a("问题跟踪")
            },
            {
                name: "scanning-profiles",
                heading: a("扫描类型")
            },
            {
                name: "excluded-hours",
                heading: a("排除时间")
            }]
        },
        t.sections.current = h(r.section),
        t.showToolbar = !1,
        t.$on("$destroy", g),
        function() {
            u.hasFeature("multi_user") && u.hasPermission("childUsers") || m("users"),
            u.hasFeature("bug_tracking_integration") && u.hasPermission("viewIssueTrackers") || m("issue-trackers"),
            u.hasFeature("target_groups") || m("target-groups"),
            u.hasPermission("systemConfig") || (m("notifications"), m("proxy"), m("scanning-profiles")),
            u.hasFeature("scanning_profiles") || m("scanning-profiles"),
            t.sections.items.forEach(function(e, t) {
                return e.index = t
            }),
            t.showToolbar = u.hasPermission("systemConfig") || "excluded-hours" === r.section && u.hasPermission("manageExcludedHours") || "target-groups" === r.section && u.hasFeature("target_groups") && (u.hasPermission("addGroup") || u.hasPermission("removeGroup"))
        } (),
        t.currentUrl = function() {
            return p.currentUrlEncoded()
        },
        t.onChangeSection = function(e, n) {
            e !== t.sections.current.name && (f(t.sections.current.name, e) ? t.changeSection(e) : n && n.preventDefault())
        },
        t.reloadSection = function() {
            n.go(n.current.name, {
                section: t.sections.current.name
            },
            {
                reload: n.current.name
            })
        },
        t.changeSection = function(e) {
            var r = h(e);
            r && r.name !== t.sections.current.name && n.go(n.current.name, {
                section: e
            },
            {
                reload: n.current.name
            })
        },
        t.notifySettingsUpdated = function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : a("Settings updated");
            c.success(o.getString(e))
        },
        t.askSaveChanges = function() {
            var n = e.extend(t.$new(), {
                message: a("保存当前更改?")
            }),
            r = i.defer(),
            o = r.resolve,
            s = r.notify,
            c = r.reject,
            u = r.promise;
            return d.confirm({
                scope: n
            }).then(o, s, c).
            finally(function() {
                return n.$destroy()
            }),
            u
        }
    }
    n.$inject = ["$scope", "$state", "$stateParams", "$q", "gettext", "gettextCatalog", "promiseTracker", "toastr", "CurrentUser", "axConstant", "axGeneralModal", "axPage"],
    e.module("WVS").controller("axSystemConfigCtrl", n)
} (angular, _),
function(e, t) {
    "use strict";
    function n(e, n, r, i, a, o, s, c) {
        function u(e, n) {
            if (n);
            else {
                var r = t.find(m.expandedNodes, t.matchesProperty("key", e.key));
                r > -1 && m.expandedNodes.splice(r, 1)
            }
        }
        function l(e, n) {
            var r = e.isChecked = !e.isChecked;
            if (d(e, e.isChecked), e.checks && g(e.checks,
            function(e) {
                e.isChecked = r,
                d(e, e.isChecked)
            }), n.length > 1) for (var i = 1; i < n.length; i++) {
                var a = n[i],
                o = !(!a.checks || !t.some(a.checks,
                function(e) {
                    return e.isChecked
                }));
                o !== a.isChecked && (a.isChecked = o, d(a, a.isChecked))
            }
        }
        function d(e, t) {
            var n = m.selectedChecks.web.indexOf(e.keyPath);
            t ? n < 0 && m.selectedChecks.web.push(e.keyPath) : n > -1 && m.selectedChecks.web.splice(n, 1)
        }
        function p() {
            var e = m.loadingTracker.createPromise();
            return i.when().then(function() {
                return "create" === r.profileId ? c.createScanningProfile(m.scanningProfile) : c.updateScanningProfile(m.scanningProfile)
            }).then(function(e) {
                if ("create" === r.profileId) return o.success("Scan profile created"),
                n.go(n.current, {
                    profileId: e.profileId
                },
                {
                    inherit: !0,
                    reload: !1,
                    replace: !0
                });
                o.success("Scan profile updated"),
                m.scanningProfile = e
            }).
            finally(e.resolve)
        }
        function f() {
            m.loadingTracker.cancel()
        }
        function g(e, t) {
            for (var n = 0; n < e.length; n++) {
                t(e[n]) !== !1 && (e[n].checks && g(e[n].checks, t))
            }
        }
        function h() {
            if (m.treeModel.length > 0) return m.scanningProfile.checks = [],
            g(m.treeModel[0].checks,
            function(e) {
                if (!e.isChecked && (m.scanningProfile.checks.indexOf(e.parentKeyPath) < 0 && m.scanningProfile.checks.push(e.keyPath), e.checks)) return ! 1
            }),
            void m.scanningProfile.checks.forEach(function(e, t, n) {
                "/" === e[0] && (n[t] = "wvs" + String(e))
            })
        }
        var m = this,
        v = c.getWebScanningChecks,
        y = c.getScanningProfile;
        m.loadingTracker = a({
            activationDelay: s.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        m.scanningProfile = {
            name: "",
            checks: [],
            isCustom: !0
        },
        m.treeOptions = {
            nodeChildren: "checks",
            allowDeselect: !1,
            dirSelectable: !0,
            equality: function() {
                function e(e, t) {
                    return e == t || !(!e || !t) && e.key === t.key
                }
                return e
            } (),
            isLeaf: function() {
                function e(e) {
                    return null === e.checks
                }
                return e
            } (),
            injectClasses: {
                iLeaf: "fa fa-file-text",
                iExpanded: "fa fa-folder-open",
                iCollapsed: "fa fa-folder",
                li: "scanning-profile-tree__li",
                ul: "scanning-profile-tree__ul"
            }
        },
        m.expandedNodes = [],
        m.treeModel = [],
        m.treeOrderByExpr = "title",
        m.selectedNode = null,
        m.searchTerm = "",
        m.profileOutput = [],
        m.selectedChecks = {
            web: []
        },
        m.onNodeSelected = u,
        m.toggleCheckMark = l,
        m.onSave = p,
        e.$on("$destroy", f),
        e.$watchCollection(function() {
            return m.selectedChecks.web
        },
        h),
        function() {
            var e = m.loadingTracker.createPromise(),
            t = e.resolve;
            i.when().then(function() {
                return v({
                    noPublishError: !0
                })
            }).then(function(e) {
                m.treeModel = e.checks,
                m.selectedNode = e.checks[0],
                m.expandedNodes.push(m.selectedNode)
            }).then(function() {
                if ("create" !== r.profileId) return y(r.profileId).then(function(e) {
                    m.scanningProfile = e
                }).then(function() {
                    m.treeModel[0].isChecked = !0,
                    g(m.treeModel[0].checks,
                    function(e) {
                        if (e.isChecked = null == m.scanningProfile.checks.find(function(t) {
                            return t.substr(3) === e.keyPath
                        }), !e.isChecked && e.checks) return g(e.checks,
                        function(e) {
                            return e.isChecked = !1
                        }),
                        !1
                    }),
                    g(m.treeModel[0].checks,
                    function(e) { ! e.isChecked && e.checks && e.checks.forEach(function(e) {
                            e.isChecked = m.scanningProfile.checks.indexOf("+wvs" + String(e.keyPath)) > -1
                        })
                    }),
                    g(m.treeModel,
                    function(e) {
                        e.isChecked && m.selectedChecks.web.push(e.keyPath)
                    })
                });
                g(m.treeModel[0].checks,
                function(e) {
                    e.isChecked && m.selectedChecks.web.push(e.keyPath)
                })
            }).
            finally(t)
        } ()
    }
    n.$inject = ["$scope", "$state", "$stateParams", "$q", "promiseTracker", "toastr", "axConstant", "ScannerApi"],
    e.module("WVS").controller("axEditScanningProfileCtrl", n)
} (angular, _),
function(e) {
    "use strict";
    function t(t, n, r, i, a, o, s, c, u, l, d, p, f) {
        function g() {
            var e = t.groupList.gridApi ? t.groupList.gridApi.selection: null;
            return e ? e.getSelectedRows() : []
        }
        function h() {
            var e = t.loadingTracker.createPromise(),
            n = e.resolve,
            i = {
                accessAllGroups: t.userProfile.accessAllGroups,
                groups: g().map(function(e) {
                    return e.groupId
                })
            };
            return p.setAccess(t.userProfile.userId, i, {
                onRetry: function() {
                    function e() {
                        return h()
                    }
                    return e
                } ()
            }).then(function() {
                o.success(s.getString("Permissions updated"))
            }).then(function() {
                return t.canNavigateBack() ? t.navigateBack() : r.go("app.edit_user", {
                    userId: t.userProfile.userId
                },
                {
                    inherit: !1
                })
            }).
            finally(n)
        }
        function m() {
            return ! e.equals(S(), C)
        }
        function v() {
            d.addGroup().then(function(e) {
                t.groupList.items.push(e)
            })
        }
        function y() {
            t.loadingTracker.cancel()
        }
        function S() {
            return {
                access_all_groups: t.userProfile.accessAllGroups,
                group_id_list: g().map(function(e) {
                    return e.groupId
                })
            }
        }
        function b() {
            var n = t.loadingTracker.createPromise();
            return p.getUser(t.userProfile.userId).then(function(n) {
                return e.merge(t.userProfile, n)
            }).
            finally(n.resolve)
        }
        function T() {
            var e = t.loadingTracker.createPromise();
            return f.getGroups(void 0, t.groupList.nextCursor, l.LIST_PAGE_SIZE).then(function(e) {
                var n = e.groups,
                r = e.pagination;
                t.groupList.items.push.apply(t.groupList.items, n),
                t.groupList.nextCursor = r.nextCursor
            }).
            finally(e.resolve)
        }
        function x() {
            var e = t.loadingTracker.createPromise();
            return p.getAccess(t.userProfile.userId, {
                onRetry: function() {
                    function e() {
                        return x()
                    }
                    return e
                } ()
            }).then(function(e) {
                if (t.groupList.items.length > 0) {
                    var n = e.groups;
                    e.accessAllGroups !== t.userProfile.accessAllGroups && i.warn("User access may be in improper state", {
                        ua: e.accessAllGroups,
                        aag: t.userProfile.accessAllGroups
                    }),
                    _.promise.then(function(e) {
                        t.groupList.items.forEach(function(t) {
                            n.indexOf(t.groupId) > -1 && e.selection.selectRow(t)
                        })
                    })
                }
            }).then(function() {
                C = S()
            }).
            finally(e.resolve)
        }
        var _ = a.defer(),
        C = null;
        t.loadingTracker = c({
            activationDelay: l.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        t.userProfile = {
            userId: n.userId,
            accessAllGroups: !1,
            fullName: ""
        },
        t.groupList = {
            items: [],
            nextCursor: void 0
        },
        t.groupList.gridOptions = {
            data: t.groupList.items,
            appScopeProvider: t,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            enableHorizontalScrollbar: u.scrollbars.ALWAYS,
            enableVerticalScrollbar: u.scrollbars.ALWAYS,
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                field: "name",
                displayName: s.getString("组织名称"),
                width: 320
            },
            {
                field: "description",
                displayName: s.getString("描述"),
                width: 240
            },
            {
                field: "targetCount",
                displayName: s.getString("组织中的目标"),
                width: 150
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.groupId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.groupId
                }
                return e
            } (),
            onRegisterApi: function() {
                function e(e) {
                    t.groupList.gridApi = e,
                    _.resolve(e)
                }
                return e
            } ()
        },
        t.selectedGroups = g,
        t.update = h,
        t.hasChanges = m,
        t.onAddGroup = v,
        t.$on("destroy", y),
        function() {
            var e = t.loadingTracker.createPromise();
            _.promise.then(function() {
                return a.all([b(), T()])
            }).then(x).
            finally(e.resolve)
        } ()
    }
    t.$inject = ["$scope", "$stateParams", "$state", "$log", "$q", "toastr", "gettextCatalog", "promiseTracker", "uiGridConstants", "axConstant", "axAddGroupModal", "ChildUsersApi", "TargetGroupsApi"],
    e.module("WVS").controller("axEditUserGroupsCtrl", t)
} (angular),
function(e) {
    "use strict";
    function t(t, n, r, i, a, o, s, c, u, l, d, p, f, g, h) {
        function m() {
            var r = t.loadingTracker.createPromise(),
            i = r.resolve;
            return p.getUser(t.userProfile.userId).then(function(r) {
                r ? (t.userProfile = e.extend({},
                r, {
                    retypePassword: r.password
                }), k = e.copy(t.userProfile)) : n.$emit("axError", {
                    errorMessage: s("This user does not exist anymore")
                })
            }).
            finally(i)
        }
        function v() {
            var n = t.loadingTracker.createPromise();
            return r.when().then(function() {
                t.groupList.gridApi.infiniteScroll.saveScrollPercentage()
            }).then(function() {
                if (f.hasFeature("target_groups") !== !0) return r.reject({
                    status: 403
                })
            }).then(function() {
                return g.getGroups("user_id:" + t.userProfile.userId, t.groupList.nextCursor, l.LIST_PAGE_SIZE)
            }).then(function(n) {
                var r = n.groups,
                i = n.pagination;
                r.forEach(function(e) {
                    t.groupList.items.find(function(t) {
                        return t.groupId === e.groupId
                    }) || t.groupList.items.push(e)
                }),
                t.groupList.nextCursor = i.nextCursor,
                t.groupList.gridApi.infiniteScroll.dataLoaded(!1, e.isDefined(i.nextCursor))
            }).
            catch(function(e) {
                return t.groupList.gridApi.infiniteScroll.dataLoaded(!1, !1),
                r.reject(e)
            }).
            finally(n.resolve)
        }
        function y() {
            var e = t.loadingTracker.createPromise();
            return p.updateUser(t.userProfile, {
                onRetry: function() {
                    function e() {
                        return y()
                    }
                    return e
                } ()
            }).then(function() {
                u.success(c.getString("Profile updated"))
            }).then(function() {
                if (!t.canNavigateBack || !t.canNavigateBack()) return a.go("app.edit_settings", {},
                {
                    inherit: !1
                });
                t.navigateBack()
            }).
            finally(e.resolve)
        }
        function S() {
            return d.currentUrlEncoded()
        }
        function b() {
            return ! e.equals(k, t.userProfile)
        }
        function T() {
            return t.profileForm && t.profileForm.$invalid ? s("The form is not valid") : b() ? "": s("No pending changes to save")
        }
        function x() {
            t.loadingTracker.cancel()
        }
        function _() {
            h.set("settings-user-list-groups", t.groupList.gridApi.saveState.save())
        }
        function C() {
            var e = h.get("settings-user-list-groups");
            e && t.groupList.gridApi.saveState.restore(t, e)
        }
        function I() {
            h.remove("settings-user-list-groups"),
            a.reload(a.current)
        }
        var w = r.defer(),
        k = null;
        t.loadingTracker = o({
            activationDelay: l.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        t.userProfile = {
            userId: i.userId,
            email: "",
            firstName: "",
            lastName: "",
            password: "",
            retypePassword: "",
            role: "",
            accessAllGroups: !1,
            enabled: !1
        },
        t.groupList = {
            items: [],
            nextCursor: void 0
        },
        t.groupList.gridOptions = {
            data: t.groupList.items,
            appScopeProvider: t,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            enableRowHeaderSelection: !1,
            multiSelect: !1,
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                field: "name",
                displayName: c.getString("组织名称"),
                width: 320
            },
            {
                field: "description",
                displayName: c.getString("描述"),
                width: 240
            },
            {
                field: "targetCount",
                displayName: c.getString("组织中的目标"),
                cellFilter: "number",
                width: 180
            }],
            gridMenuCustomItems: [{
                title: c.getString("Reset Layout"),
                action: I
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.groupId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.groupId
                }
                return e
            } (),
            infiniteScrollRowsFromEnd: 20,
            infiniteScrollUp: !1,
            infiniteScrollDown: !0,
            onRegisterApi: function() {
                function e(e) {
                    t.groupList.gridApi = e,
                    e.infiniteScroll.on.needLoadMoreData(t, v),
                    e.colResizable.on.columnSizeChanged(t, _),
                    e.core.on.columnVisibilityChanged(t, _),
                    e.core.on.sortChanged(t, _),
                    w.resolve()
                }
                return e
            } ()
        },
        t.roleList = l.USER_ROLE,
        t.loadProfile = m,
        t.updateProfile = y,
        t.currentUrl = S,
        t.hasChanges = b,
        t.saveActionStatusMessage = T,
        t.$on("$destroy", x),
        function() {
            var e = t.loadingTracker.createPromise();
            r.when([m(), w.promise.then(v).then(C)]).
            finally(e.resolve)
        } ()
    }
    t.$inject = ["$scope", "$rootScope", "$q", "$stateParams", "$state", "promiseTracker", "gettext", "gettextCatalog", "toastr", "axConstant", "axPage", "ChildUsersApi", "CurrentUser", "TargetGroupsApi", "axUserPreferences"],
    e.module("WVS").controller("axEditUserCtrl", t)
} (angular),
function(e) {
    "use strict";
    function t(t, n, r, i, a, o, s, c, u, l, d, p, f, g, h) {
        function m() {
            var e = t.targetList.gridApi && t.targetList.gridApi.selection;
            return e ? e.getSelectedRows() : []
        }
        function v() {
            var e = t.targetList.gridApi && t.targetList.gridApi.selection;
            return e ? e.getSelectedCount() : 0
        }
        function y() {
            return g.changeTargets(t.group.groupId, t.changeSet, {
                tracker: t.loadingTracker,
                onRetry: function() {
                    function e() {
                        return y()
                    }
                    return e
                } ()
            }).then(function() {
                t.changeSet = {
                    add: [],
                    remove: []
                },
                u.success(s.getString("Group membership updated"))
            }).then(function() {
                if (!t.canNavigateBack || !t.canNavigateBack()) return i.go("app.edit_settings", {
                    section: "target-groups"
                },
                {
                    inherit: !1
                });
                t.navigateBack()
            })
        }
        function S() {
            return t.changeSet.add.length > 0 || t.changeSet.remove.length > 0
        }
        function b() {
            t.loadingTracker.cancel()
        }
        function T() {
            return g.getGroup(t.group.groupId, {
                tracker: t.loadingTracker,
                onRetry: function() {
                    function e() {
                        return T()
                    }
                    return e
                } ()
            }).then(function(e) {
                if (null === e) {
                    var i = o("The specified group does not exist");
                    return n.$emit("axError", {
                        message: i,
                        onRetry: function() {
                            function e() {
                                return T()
                            }
                            return e
                        } ()
                    }),
                    r.reject({
                        message: i
                    })
                }
                t.group = e
            })
        }
        function x() {
            var n = t.loadingTracker.createPromise(),
            i = !1;
            return t.targetList.gridApi.infiniteScroll.saveScrollPercentage(),
            f.getTargets(void 0, t.targetList.nextCursor, d.LIST_PAGE_SIZE, {
                onRetry: function() {
                    function e() {
                        return x()
                    }
                    return e
                } ()
            }).then(function(n) {
                var r = n.targets,
                a = n.pagination;
                r.forEach(function(e) {
                    t.targetList.items.find(function(t) {
                        return t.targetId === e.targetId
                    }) || t.targetList.items.push(e)
                }),
                t.targetList.nextCursor = a.nextCursor,
                t.targetList.gridApi.infiniteScroll.dataLoaded(!1, e.isDefined(a.nextCursor)),
                i = !0
            }).then(A).then(_).
            catch(function(e) {
                return i || t.targetList.gridApi.infiniteScroll.dataLoaded(!1, !1),
                r.reject(e)
            }).
            finally(n.resolve)
        }
        function _() {
            var e = t.loadingTracker.createPromise();
            return g.listTargets(t.group.groupId, {
                onRetry: function() {
                    function e() {
                        return _()
                    }
                    return e
                } ()
            }).then(function(e) {
                if (e.length > 0) {
                    E = !0;
                    try {
                        t.targetList.items.forEach(function(n) {
                            e.indexOf(n.targetId) > -1 && t.targetList.gridApi.selection.selectRow(n)
                        })
                    } finally {
                        E = !1
                    }
                }
            }).
            finally(e.resolve)
        }
        function C(t) {
            if (!E) { (e.isArray(t) ? t: [t]).forEach(function(e) {
                    var t = e.isSelected,
                    n = e.entity;
                    return t ? w(n) : I(n)
                })
            }
        }
        function I(e) {
            var n = t.changeSet.add.indexOf(e.targetId);
            n < 0 ? t.changeSet.remove.push(e.targetId) : t.changeSet.add.splice(n, 1)
        }
        function w(e) {
            var n = t.changeSet.remove.indexOf(e.targetId);
            n < 0 ? t.changeSet.add.push(e.targetId) : t.changeSet.remove.splice(n, 1)
        }
        function k() {
            h.set("edit-group-targets", t.targetList.gridApi.saveState.save())
        }
        function A() {
            var e = h.get("edit-group-targets");
            e && t.targetList.gridApi.saveState.restore(t, e)
        }
        function L() {
            h.remove("edit-group-targets"),
            i.reload(i.current)
        }
        var E = !1,
        $ = r.defer();
        t.group = {
            groupId: a.groupId,
            name: ""
        },
        t.loadingTracker = c({
            activationDelay: d.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        t.changeSet = {
            add: [],
            remove: []
        },
        t.targetList = {
            items: [],
            nextCursor: void 0
        },
        t.targetList.gridOptions = {
            data: t.targetList.items,
            appScopeProvider: t,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableFullRowSelection: !1,
            enableRowHeaderSelection: p.hasPermission("changeGroupMembership"),
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            gridMenuTitleFilter: l,
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                field: "address",
                displayName: s.getString("地址"),
                width: 320
            },
            {
                field: "description",
                displayName: s.getString("备注"),
                cellTooltip: !0,
                width: 240
            },
            {
                field: "criticality",
                displayName: s.getString("业务重要性"),
                cellFilter: "axBusinessCriticality",
                visible: !1,
                width: 160
            }],
            gridMenuCustomItems: [{
                title: s.getString("Reset Layout"),
                action: L
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.targetId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.targetId
                }
                return e
            } (),
            infiniteScrollRowsFromEnd: 20,
            infiniteScrollUp: !1,
            infiniteScrollDown: !0,
            onRegisterApi: function() {
                function e(e) {
                    t.targetList.gridApi = e,
                    e.infiniteScroll.on.needLoadMoreData(t, x),
                    e.selection.on.rowSelectionChanged(t, C),
                    e.colResizable.on.columnSizeChanged(t, k),
                    e.core.on.columnVisibilityChanged(t, k),
                    e.core.on.sortChanged(t, k),
                    $.resolve(e)
                }
                return e
            } ()
        },
        t.selectedItems = m,
        t.selectedItemsCount = v,
        t.update = y,
        t.hasChanges = S,
        t.$on("destroy", b),
        function() {
            T().then($.promise).then(x)
        } ()
    }
    t.$inject = ["$scope", "$rootScope", "$q", "$state", "$stateParams", "gettext", "gettextCatalog", "promiseTracker", "toastr", "translateFilter", "axConstant", "CurrentUser", "TargetsApi", "TargetGroupsApi", "axUserPreferences"],
    e.module("WVS").controller("axEditGroupTargetsCtrl", t)
} (angular),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c) {
        function u(t) {
            return p(t.url) && (t.noLoadingTracker !== !0 && (e.isArray(t.tracker) || (t.tracker = t.tracker ? [t.tracker] : []), t.tracker.indexOf(n.globalPromiseTracker) < 0 && (t.tracker.unshift(n.globalPromiseTracker), void 0 === t.$promiseTrackerDeferred && (t.$promiseTrackerDeferred = t.$promiseTrackerDeferred || []), t.$promiseTrackerDeferred.push(n.globalPromiseTracker.createPromise()))), t.noAuthToken !== !0 && (t.headers || (t.headers = {}), t.headers[c.API_AUTH_HEADER] = s.get(c.API_AUTH_HEADER)), t.timeout || (t.timeout = c.API_REQUEST_TIMEOUT)),
            t
        }
        function l(e) {
            if (e && e.config && p(e.config.url)) {
                var t = e.headers ? e.headers(c.API_AUTH_HEADER) : void 0;
                t && s.set(c.API_AUTH_HEADER, t)
            }
            return e
        }
        function d(t) {
            if (t && t.config && p(t.config.url)) {
                if (i.error({
                    httpStatus: t.status,
                    errorInfo: t.data
                }), 404 === t.status) return t.data = null,
                r.when(t);
                e.extend(t, {
                    publishResponseError: g
                },
                f(t.status, t.statusText, t.data, t.config)),
                e.isFunction(t.config.formatError) && t.config.formatError(t),
                t.config.noPublishError !== !0 && n.$emit("axApiError", t),
                401 === t.status && t.config.noLoginRedirect !== !0 && n.$emit("axAuthRequired", t)
            }
            return r.reject(t)
        }
        function p(e) {
            return 0 === e.indexOf(c.API_BASE_PATH)
        }
        function f(r, i, s, u) {
            var l = o.get("gettextCatalog"),
            d = o.get("axEscapeHtmlFilter"),
            p = d("http-" + r),
            f = d(i);
            if (e.isObject(s) && s.code === c.SYI_ERROR_CODES.LICENSE_NOT_ACTIVATED && n.$emit(c.PRODUCT_ACTIVATION_REQUIRED), e.isObject(s) && s.message) {
                if (f = s.message, 409 === r && "Group name should be unique" === s.message) f = l.getString("A group with this name already exists.");
                else if (400 === r && 400 === s.code && t.get(s, "details[0].body.problems[0].code")) {
                    var g = t.get(s, "details[0].body.problems[0]");
                    switch (g.code) {
                    case "invalid_condition":
                        "maxLength" === g.condition && (f = a("Input length exceeds the supported value."));
                        break;
                    case "format":
                        "email" === g.expected_format && (f = a("The email address provided is not valid."))
                    }
                }
                if (403 === r && "Forbidden" === f) f = l.getString("Access Denied for your user role. Contact your Administrator.");
                else if (409 === r && e.isNumber(s.code)) switch (s.code) {
                case c.SYI_ERROR_CODES.MI_CONTINUOUS_MODE_NOT_SUPPORTED:
                    f = l.getString("Continuous scanning cannot be enabled because the scans of this target require manual intervention.");
                    break;
                case c.SYI_ERROR_CODES.MI_NOT_FROM_LOCALHOST:
                case c.SYI_ERROR_CODES.MI_NO_SESSION_ID:
                    f = l.getString("The scans of this target require manual intervention - scans can only be created on the machine where this product is installed.");
                    break;
                case c.SYI_ERROR_CODES.MI_RECURRENT_SCANS_NOT_ALLOWED:
                case c.SYI_ERROR_CODES.MI_ONLY_SCAN_NOW_ALLOWED:
                    f = l.getString("The scans of this target require manual intervention - only instant scans are allowed.");
                    break;
                case c.SYI_ERROR_CODES.MI_SCAN_NOW_NOT_POSSIBLE_SYSTEM_EXCLUDED_HOURS:
                case c.SYI_ERROR_CODES.MI_SCAN_NOW_NOT_POSSIBLE_TARGET_EXCLUDED_HOURS:
                    f = l.getString("The scans of this target require manual intervention and excluded hours are in use.")
                }
            } else[ - 1, 502, 504].indexOf(r) > -1 ? f = l.getString("A connection to server could not be established. [Status: {{status}}]", {
                status: r
            }) : 403 === r ? f = l.getString("Access Denied for your user role. Contact your Administrator.") : s && (f = e.isString(s) && s.length > 0 ? d(s) : "<b>" + d(String(r)) + " " + d(i) + (u ? " [<em>" + d(u.method) + " " + d(u.url) + "</em>]": "") + '</b>: <span class="text-danger">' + d(e.toJson(s)) + "</span>");
            switch (r) {
            case 401:
                p = c.ERROR_CODES.AUTH_REQUIRED,
                f = a("Authentication required")
            }
            return {
                errorCode: p,
                errorMessage: f
            }
        }
        function g(e) {
            n.$emit("axApiError", e),
            401 === e.status && n.$emit("axAuthRequired", e)
        }
        return {
            request: u,
            response: l,
            responseError: d
        }
    }
    n.$inject = ["$rootScope", "$q", "$log", "gettext", "$injector", "localStorageService", "axConstant"],
    e.module("WVS").factory("axApiInterceptor", n)
} (angular, _),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u, l, d, p, f, g, h, m, v, y, S, b, T, x, _, C, I) {
        function w() {
            n.selectedLocation = null
        }
        function k() {
            n.filterAsideVisible = !n.filterAsideVisible
        }
        function A(e) {
            var t = n.searchFilters;
            switch (t.filterTags.splice(t.filterTags.indexOf(e), 1), e.key) {
            case "severity":
                t.severity = [];
                break;
            case "status":
                t.status = null;
                break;
            case "cvss":
                t.cvss = null;
                break;
            case "vuln_type":
                t.vulnType = null
            }
            W()
        }
        function L() {
            return y.currentUrlEncoded()
        }
        function E(e) {
            n.selectedVulnItems = e
        }
        function $() {
            return ["aborted", "completed", "failed"].indexOf(n.scan.status) > -1 || "completed" === n.scan.originalStatus
        }
        function R() {
            return ["aborted", "completed", "failed"].indexOf(n.scan.status) > -1 || "completed" === n.scan.originalStatus
        }
        function P() {
            S.chooseReportOptions().then(function(e) {
                return X(e.templateId, {
                    listType: "scan_result",
                    idList: [n.scan.resultId]
                })
            }).then(function() {
                l.go("app.list_reports", {},
                {
                    inherit: !1
                })
            })
        }
        function N(e, t) {
            var r = [];
            switch (t) {
            case "scan_result":
                r = [n.scan.resultId]
            }
            return Z(e, {
                listType: t,
                idList: r
            })
        }
        function D() {
            var t = e.extend(n.$new(), {
                message: d("您确定要停止所选的扫描？")
            });
            return m.confirm({
                scope: t
            }).then(J).
            finally(function() {
                return t.$destroy()
            })
        }
        function U() {
            ee = !0,
            l.go(l.current.name, {
                view: "events"
            }).
            finally(function() {
                ee = !1
            })
        }
        function V(t) {
            if (n.selectedLocation = t, n.locId = t.locId, n.locations = G(t), !n.selectedLocation) return c.when();
            var r = n.loadingTracker.createPromise();
            return _.getLocationDetails(n.scan.resultId, n.scan.scanId, t.locId, {
                cache: v
            }).then(function(t) {
                e.extend(n.selectedLocation, t)
            }).
            finally(r.resolve)
        }
        function M() {
            n.loadingTracker.cancel()
        }
        function F() {
            switch (u.view) {
            case "stats":
                n.sections.currentIndex = 0,
                n.currentSection = "stats";
                break;
            case "vulns":
                n.sections.currentIndex = 1,
                n.currentSection = "vulns";
                break;
            case "crawl":
                n.sections.currentIndex = 2,
                n.currentSection = "crawl";
                break;
            case "events":
                n.sections.currentIndex = 3,
                n.currentSection = "events";
                break;
            case "sessions":
                n.sections.currentIndex = 4,
                n.currentSection = "sessions"
            }
        }
        function O() {
            var e = n.searchFilters,
            t = [];
            e.severity.length > 0 && t.push("severity:" + e.severity.join(",")),
            e.status && ("rediscovered" === e.status ? (t.push("status:open"), t.push("rediscovered:true")) : t.push("status:" + e.status)),
            e.cvss && ("4" === e.cvss ? t.push("cvss_score:<=" + e.cvss) : "4-7" === e.cvss ? (t.push("cvss_score:>=4"), t.push("cvss_score:<=7")) : "7" === e.cvss && t.push("cvss_score:>=" + e.cvss)),
            e.vulnType && t.push("vt_id:" + e.vulnType),
            e.searchQuery = t.join(";")
        }
        function H(t) {
            return T.getScan(n.scan.scanId, e.extend({
                tracker: n.loadingTracker,
                onRetry: function() {
                    function e() {
                        return H()
                    }
                    return e
                } ()
            },
            t)).then(function(t) {
                if (null === t) s.warn("Scan " + String(n.scan.scanId) + "  no longer exists."),
                n.sections.items.forEach(function(e) {
                    return e.visible = !1
                });
                else {
                    e.extend(n.scan, t),
                    u.resultId !== n.scan.resultId && "default" !== u.resultId && (n.scan.resultId = u.resultId);
                    n.scan.schedule.recurrence && !n.sections.items.find(function(e) {
                        return "sessions" === e.view
                    }) && n.sections.items.push({
                        heading: d("Previous Sessions"),
                        view: "sessions",
                        visible: !0
                    }),
                    n.sections.items.forEach(function(e) {
                        return e.visible = t.resultId
                    }),
                    n.sections.items[0].visible = !0
                }
            }).then(function() {
                var e = n.scan,
                t = e.scanId,
                r = e.resultId;
                if (r && "stats" === n.currentSection) return _.getStatistics(t, r, {
                    noPublishError: !0,
                    noLoadingTracker: !0
                }).then(function(e) {
                    n.scanStatus = e
                })
            }).
            finally(K).
            finally(function() {
                var e = T.getScanNextRefresh(n.scan);
                n.$$destroyed || "stats" !== n.currentSection || null !== e && a(function() {
                    return H({
                        noPublishError: !0,
                        noLoadingTracker: !0,
                        tracker: null
                    })
                },
                e)
            })
        }
        function j(e) {
            n.locations.push(e)
        }
        function G(e) {
            var t = [];
            if (e) do {
                t.unshift(e), e = e.parentLoc
            } while ( e );
            return t
        }
        function q(e, t) {
            t !== e && (O(), K(), W())
        }
        function B(e, t) {
            e === t || ee || l.reload(l.current)
        }
        function K() {
            var e = n.searchFilters,
            t = [];
            if (e.severity.length > 0 && t.push({
                key: "severity",
                label: d("严重程度:"),
                value: e.severity.map(function(t) {
                    var n = e.severityList.find(function(e) {
                        return e.value === t
                    });
                    return p.getString(n.text)
                }).join(", ")
            }), e.status) {
                var r = e.statusList.find(function(t) {
                    return t.value === e.status
                });
                t.push({
                    key: "status",
                    label: d("Status:"),
                    value: p.getString(r.text)
                })
            }
            if (e.cvss) {
                var i = e.cvssList.find(function(t) {
                    return t.value === e.cvss
                });
                t.push({
                    key: "cvss",
                    label: "CVSS:",
                    value: p.getString(i.text)
                })
            }
            e.vulnType && t.push({
                key: "vuln_type",
                label: d("Vulnerability Type:"),
                value: e.vulnTypeName || e.vulnType
            }),
            e.filterTags = t
        }
        function W() {
            var e = n.searchFilters;
            ee = !0;
            var t = {
                scanId: u.scanId,
                view: u.view,
                returnUrl: u.returnUrl,
                severity: e.severity.length > 0 ? e.severity.join(",") : void 0,
                status: null !== e.status ? e.status: void 0,
                cvss: null !== e.cvss ? e.cvss: void 0,
                type: null !== e.vulnType ? e.vulnType: void 0
            };
            l.go(l.current.name, t, {
                inherit: !1
            }).
            finally(function() {
                ee = !1
            })
        }
        function z() {
            var e = n.loadingTracker.createPromise(),
            t = {
                tracker: n.loadingTracker,
                cache: C
            };
            return I.getVulnerabilityType(n.searchFilters.vulnType, t).then(function(e) {
                var t = e.name;
                n.searchFilters.vulnTypeName = t
            }).
            finally(e.resolve).
            finally(K)
        }
        function Y() {
            return b.getExportTypes("scan_result", {
                tracker: n.loadingTracker,
                onRetry: function() {
                    function e() {
                        return Y()
                    }
                    return e
                } ()
            }).then(function(t) {
                n.exportTemplateTypeList = t.map(function(t) {
                    return e.extend({
                        sourceType: "scan_result"
                    },
                    t)
                })
            })
        }
        function Z(t, r) {
            if (te.active()) {
                var i = e.extend(n.$new(), {
                    message: d("Another download is in progress.")
                });
                return m.alert({
                    scope: i
                }).
                finally(function() {
                    return i.$destroy()
                })
            }
            var a = n.loadingTracker.createPromise();
            return b.generateNewExport(t, r, {
                tracker: n.loadingTracker,
                onRetry: function() {
                    function e() {
                        return Z(t, r)
                    }
                    return e
                } ()
            }).then(function(e) {
                "failed" !== e.status && g.success(p.getString("Your download will automatically start in a few moments")),
                Q(e.reportId)
            }).
            finally(a.resolve)
        }
        function Q(t) {
            var a, o, s = te.createPromise(),
            u = !1;
            return u ? c.when() : (a = i(function() {
                return u = !0,
                b.getExport(t, {
                    tracker: te,
                    noPublishError: !0
                }).then(function(t) {
                    if (null === t) {
                        var n = {
                            errorMessage: d("Your report could not be downloaded [Report deleted]")
                        };
                        return s.reject(n),
                        c.reject(n)
                    }
                    if ("failed" === t.status) {
                        var r = {
                            errorMessage: d("Your data could not be exported [Failed]")
                        };
                        return c.reject(r)
                    } (t.downloadLinkPDF || t.downloadLinkHTML || t.downloadLinkXML) && (e.element("#download-helper").attr("src", t.downloadLinkPDF || t.downloadLinkHTML || t.downloadLinkXML), s.resolve())
                }).
                catch(function(e) {
                    throw s.reject(e),
                    r.$emit("axError", e),
                    e
                }).
                finally(function() {
                    u = !1
                })
            },
            1e3), o = n.$on("$destroy", a.cancel), s.promise.
            finally(function() {
                i.cancel(a),
                o()
            }), s.promise)
        }
        function X(e, t) {
            return b.generateNewReport(e, t, {
                tracker: n.loadingTracker,
                onRetry: function() {
                    function n() {
                        return X(e, t)
                    }
                    return n
                } ()
            }).then(function() {
                g.success(p.getString("Your report is being created"))
            })
        }
        function J() {
            return T.abortScan(n.scan.scanId, {
                tracker: n.loadingTracker,
                onRetry: function() {
                    function e() {
                        return J()
                    }
                    return e
                } ()
            }).then(function(t) {
                e.extend(n.scan, t),
                u.resultId !== n.scan.resultId && "default" !== u.resultId && (n.scan.resultId = u.resultId)
            })
        }
        var ee = !1,
        te = f({
            activationDelay: h.PROMISE_TRACKER_ACTIVATION_DELAY
        });
        n.loadingTracker = f({
            activationDelay: h.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        n.scan = {
            scanId: u.scanId,
            resultId: null,
            target: {
                targetId: null,
                address: ""
            }
        },
        n.filterAsideVisible = !1,
        n.returnUrl = u.returnUrl,
        n.searchFilters = {
            searchQuery: "",
            severity: x.getStateParam("severity", !0, t.map(h.VULN_SEVERITY_LEVEL, t.property("value"))),
            severityList: h.VULN_SEVERITY_LEVEL,
            status: x.getStateParam("status", !1, t.map(h.VULN_STATUS, t.property("value")).concat(["!open"])),
            statusList: h.VULN_STATUS.concat([{
                value: "!open",
                text: d("Not Open")
            }]),
            cvss: x.getStateParam("cvss", !1, t.map(h.CVSS_SCORE, t.property("value"))),
            cvssList: h.CVSS_SCORE,
            vulnType: x.getStateParam("type"),
            vulnTypeName: null,
            filterTags: []
        },
        n.locId = 0,
        n.locations = [],
        n.selectedLocation = null,
        n.sections = {
            currentIndex: 0,
            items: [{
                heading: d("扫描状态和信息"),
                view: "stats",
                visible: !1
            },
            {
                heading: d("漏洞"),
                view: "vulns",
                visible: !1
            },
            {
                heading: d("网站结构"),
                view: "crawl",
                visible: !1
            },
            {
                heading: d("事件"),
                view: "events",
                visible: !1
            }]
        },
        n.currentSection = "stats",
        n.selectedVulnItems = [],
        n.exportTemplateTypeList = [],
        n.scanStatus = void 0,
        n.hideLocationDetails = w,
        n.toggleFilter = k,
        n.onCrawlLocationLoaded = j,
        n.onCrawLocationDetails = V,
        n.onVulnerabilitiesSelectionChanged = E,
        n.removeFilterTag = A,
        n.onGenerateReport = P,
        n.currentUrl = L,
        n.onExport = N,
        n.canGenerateReport = $,
        n.canGenerateExport = R,
        n.onStopScan = D,
        n.navigateToEvents = U,
        n.$on("$destroy", M),
        n.$watch(function() {
            return u.view
        },
        function(e, t) {
            e !== t && F()
        }),
        n.$watch("sections.currentIndex",
        function(t, r) {
            if (t !== r) {
                var i = n.sections.items[t];
                n.currentSection = i.view,
                ee = !0,
                l.go(l.current.name, e.extend({
                    view: i.view
                })).
                finally(function() {
                    ee = !1
                })
            }
        }),
        n.$watch("searchFilters.severity", q),
        n.$watch("searchFilters.status", q),
        n.$watch("searchFilters.cvss", q),
        n.$watch("searchFilters.vulnType", q),
        n.$watchCollection(function() {
            return u
        },
        B),
        function() {
            K(),
            O(),
            F(),
            H(),
            Y(),
            n.searchFilters.vulnType && z()
        } (),
        n.changeLocation = function(e) {
            var t = n.locations.indexOf(e);
            t > -1 ? t + 1 < n.locations.length && n.locations.splice(t + 1) : n.locations.splice(0),
            n.locId = e.locId
        }
    }
    n.$inject = ["$scope", "$rootScope", "$interval", "$timeout", "axFormatDurationFilter", "$log", "$q", "$stateParams", "$state", "gettext", "gettextCatalog", "promiseTracker", "toastr", "axConstant", "axGeneralModal", "axLocationsCache", "axPage", "axReportOptionsModal", "ReportsApi", "ScansApi", "axStateHelpers", "ResultsApi", "axVulnTypesCache", "VulnerabilitiesApi"],
    e.module("WVS").controller("axScanDetailsCtrl", n)
} (angular, _),
function(e) {
    "use strict";
    function t() {}
    e.module("WVS").controller("axScanDetailsVulnsCtrl", t)
} (angular),
function(e) {
    "use strict";
    function t(e) {
        e.statsNotAvailable = function() {
            e.noStats = !0
        },
        e.noStats = !1
    }
    t.$inject = ["$scope"],
    e.module("WVS").controller("axScanDetailsStatsCtrl", t)
} (angular),
function(e) {
    "use strict";
    function t(t, n, r, i, a, o, s, c, u, l) {
        function d() {
            return c.currentUrlEncoded()
        }
        function p() {
            var r = t.loadingTracker.createPromise();
            return n.when().then(function() {
                return t.sessionList.gridApi.infiniteScroll.saveScrollPercentage()
            }).then(function() {
                return u.getScanResultHistory(i.scanId, t.sessionList.nextCursor, s.LIST_PAGE_SIZE, {
                    onRetry: function() {
                        function e() {
                            return p()
                        }
                        return e
                    } ()
                })
            }).then(function(n) {
                var r = n.results,
                i = n.pagination;
                r.forEach(function(e) {
                    t.sessionList.items.find(function(t) {
                        return t.resultId === e.resultId
                    }) || t.sessionList.items.push(e)
                }),
                t.sessionList.nextCursor = i.nextCursor,
                t.sessionList.gridApi.infiniteScroll.dataLoaded(!1, e.isDefined(i.nextCursor))
            }).
            catch(function(e) {
                return t.sessionList.gridApi.infiniteScroll.dataLoaded(!1, !1),
                n.reject(e)
            }).
            finally(r.resolve)
        }
        function f() {
            l.set("scan-details-sessions", t.sessionList.gridApi.saveState.save())
        }
        function g() {
            var e = l.get("scan-details-sessions");
            e && t.sessionList.gridApi.saveState.restore(t, e)
        }
        function h() {
            l.remove("scan-details-sessions"),
            r.reload(r.current.name)
        }
        var m = n.defer();
        t.loadingTracker = o({
            activationDelay: s.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        t.sessionList = {
            items: [],
            nextCursor: void 0
        },
        t.sessionList.gridOptions = {
            data: t.sessionList.items,
            appScopeProvider: t,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                cellFilter: "date:'medium'",
                displayName: a.getString("起始日期"),
                field: "startDate",
                width: 160
            },
            {
                cellFilter: "date:'medium'",
                displayName: a.getString("结束日期"),
                field: "endDate",
                width: 160
            },
            {
                cellTemplate: __axtr("/templates/scans/scan-details/sections/sessions/cells/status.html"),
                displayName: a.getString("状态"),
                field: "status",
                width: 130
            },
            {
                cellTemplate: __axtr("/templates/scans/scan-details/sections/sessions/cells/actions.html"),
                displayName: "",
                name: "actions",
                width: 160
            }],
            gridMenuCustomItems: [{
                title: a.getString("重置布局"),
                action: h
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.scanId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.scanId
                }
                return e
            } (),
            infiniteScrollRowsFromEnd: 20,
            infiniteScrollUp: !1,
            infiniteScrollDown: !0,
            onRegisterApi: function() {
                function e(e) {
                    t.sessionList.gridApi = e,
                    e.infiniteScroll.on.needLoadMoreData(t, p),
                    e.colResizable.on.columnSizeChanged(t, f),
                    e.core.on.columnVisibilityChanged(t, f),
                    e.core.on.sortChanged(t, f),
                    m.resolve()
                }
                return e
            } ()
        },
        t.returnUrl = i.returnUrl,
        t.currentUrl = d,
        function() {
            m.promise.then(p).
            finally(g)
        } ()
    }
    t.$inject = ["$scope", "$q", "$state", "$stateParams", "gettextCatalog", "promiseTracker", "axConstant", "axPage", "ScansApi", "axUserPreferences"],
    e.module("WVS").controller("axScanDetailsSessionsCtrl", t)
} (angular),
function(e) {
    "use strict";
    function t(e) {
        e.searchFilters = {
            searchQuery: "resource_type:6;resource_id:" + String(e.scan.resultId)
        }
    }
    t.$inject = ["$scope"],
    e.module("WVS").controller("axScanDetailsEventsCtrl", t)
} (angular),
function(e) {
    "use strict";
    function t() {}
    e.module("WVS").controller("axScanDetailsCrawlCtrl", t)
} (angular),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u, l, d, p, f, g, h, m, v, y, S, b, T, x, _, C, I, w, k, A, L) {
        function E(t) {
            return ce(function() {
                var n = e.isString(t) && t.length > 0 ? "name:*" + encodeURIComponent(t) : void 0;
                return r.when().then(function() {
                    if (y.hasFeature("target_groups") !== !0) return r.reject({
                        status: 403
                    })
                }).then(function() {
                    return w.getGroups(n, void 0, 10, {
                        cache: d,
                        noPublishError: !0
                    }).then(function(e) {
                        var t = e.groups;
                        i.searchFilters.groupList = t
                    })
                }).then(function() {
                    if (i.searchFilters.group.length > 0) return i.searchFilters.group.reduce(function(e, t) {
                        return i.searchFilters.groupList.find(function(e) {
                            return e.groupId === i.searchFilters.groupList
                        }) ? e: e.then(function() {
                            return w.getGroup(t, {
                                cache: d,
                                noPublishError: !0
                            })
                        }).then(function(e) {
                            i.searchFilters.groupList.push(e)
                        })
                    },
                    r.when())
                }).then(function() {
                    i.searchFilters.groupList = T(i.searchFilters.groupList, "name")
                }).
                catch(function(e) {
                    return 403 === e.status || e.publishResponseError && e.publishResponseError(e),
                    r.reject(e)
                }).
                finally(Y)
            })
        }
        function $(t) {
            return ce(function() {
                var n = e.isString(t) && t.length > 0 ? "text_search:*" + encodeURIComponent(t) : void 0;
                return r.when().then(function() {
                    if (i.filterAsideVisible) return k.getTargets(n, void 0, 10, {
                        cache: m
                    }).then(function(e) {
                        var t = e.targets;
                        i.searchFilters.targetList = t
                    })
                }).then(function() {
                    if (i.searchFilters.target) {
                        if (!i.searchFilters.targetList.find(function(e) {
                            return e.targetId === i.searchFilters.target
                        })) return k.getTarget(i.searchFilters.target, {
                            cache: m
                        }).then(function(e) {
                            i.searchFilters.targetList.push(e)
                        })
                    }
                }).then(function() {
                    i.searchFilters.targetList = T(i.searchFilters.targetList, "address")
                }).
                finally(Y)
            })
        }
        function R() {
            i.filterAsideVisible = !i.filterAsideVisible
        }
        function P(t) {
            var n = i.scanList.gridApi && i.scanList.gridApi.selection,
            r = n ? n.getSelectedRows() : [];
            return r.length > 0 && e.isDefined(t) && (e.isArray(t) || (t = [t]), r = r.filter(function(e) {
                return t.indexOf(e.status) > -1
            })),
            r
        }
        function N(t) {
            if (!e.isDefined(t)) {
                var n = i.scanList.gridApi && i.scanList.gridApi.selection;
                return n ? n.getSelectedCount() : 0
            }
            return P(t).length
        }
        function D() {
            var t = e.extend(i.$new(), {
                message: S(N() > 1 ? "您确定要删除所选的扫描？": "您确定要删除所选的扫描？"),
                title: S(N() > 1 ? "删除扫描": "删除扫描")
            });
            return l.confirm({
                scope: t
            }).then(te).then(K).
            finally(function() {
                return t.$destroy()
            })
        }
        function U() {
            if (P().filter(function(e) {
                return ["queued", "starting", "processing"].indexOf(e.status) > -1
            }).length > 0) {
                var t = e.extend(i.$new(), {
                    message: S(N() > 1 ? "您确定要停止所选扫描吗？": "您确定要停止所选扫描吗？"),
                    title: S(N() > 1 ? "停止扫描": "停止扫描")
                });
                return l.confirm({
                    scope: t
                }).then(ne).
                finally(function() {
                    return t.$destroy()
                })
            }
        }
        function V() {
            return N(["aborted", "completed", "failed"]) > 0 || P(["scheduled"]).filter(function(e) {
                return "completed" === e.originalStatus
            }).length > 0
        }
        function M() {
            var e = P(["aborted", "completed", "failed"]).concat(P(["scheduled"]).filter(function(e) {
                return "completed" === e.originalStatus
            }));
            return 2 === e.map(function(e) {
                return e.scanId
            }).length && 1 === t.uniqBy(e,
            function(e) {
                return e.target.targetId
            }).length
        }
        function F() {
            var e = P(["aborted", "completed", "failed"]).concat(P(["scheduled"]).filter(function(e) {
                return "completed" === e.originalStatus
            })),
            n = e.map(function(e) {
                return e.scanId
            }),
            r = 2 === n.length && 1 === t.uniqBy(e,
            function(e) {
                return e.target.targetId
            }).length;
            f.chooseReportOptions(r).then(function(e) {
                return ee(e.templateId, {
                    listType: "scans",
                    idList: n
                })
            }).then(function() {
                a.go("app.list_reports", {},
                {
                    inherit: !1
                })
            })
        }
        function O() {
            var e = P(["aborted", "completed", "failed"]).concat(P(["scheduled"]).filter(function(e) {
                return "completed" === e.originalStatus
            })),
            n = e.map(function(e) {
                return e.scanId
            }),
            r = i.loadingTracker.createPromise();
            _.getReportTemplates().then(function(e) {
                return ee(t.get(e.find(function(e) {
                    return e.comparison
                }), "templateId"), {
                    listType: "scans",
                    idList: n
                })
            }).then(function() {
                a.go("app.list_reports", {},
                {
                    inherit: !1
                })
            }).
            finally(r.resolve)
        }
        function H() {
            return p.currentUrlEncoded()
        }
        function j(e) {
            var t = i.searchFilters;
            switch (t.filterTags.splice(t.filterTags.indexOf(e), 1), e.key) {
            case "threat":
                t.threatLevel = [];
                break;
            case "criticality":
                t.criticality = [];
                break;
            case "status":
                t.status = [];
                break;
            case "profile":
                t.profile = [];
                break;
            case "target":
                t.target = null;
                break;
            case "group":
                t.group = []
            }
            Z()
        }
        function G(t) {
            return u.editSchedule(t.schedule).then(function(n) {
                var r = {
                    schedule: {
                        scheduleDate: n.recurrence ? void 0 : n.scheduleDate,
                        disabled: n.disabled,
                        timeSensitive: n.timeSensitive,
                        recurrence: n.recurrence
                    }
                };
                return le(t.scanId, r).then(function(n) {
                    e.extend(t, n),
                    A.success(b.getString("Schedule has been updated."))
                }).then(function() {
                    i.scanList.gridApi.core.notifyDataChange(L.dataChange.EDIT)
                })
            })
        }
        function q() {
            return h.addTarget().then(function(e) {
                a.go("app.target_config", {
                    returnUrl: H(),
                    targetId: e.targetId
                },
                {
                    inherit: !1
                })
            })
        }
        function B() {
            if (de) try {
                n.cancel(de)
            } finally {
                de = null
            }
            i.loadingTracker.cancel()
        }
        function K() {
            return r.all([k.getTargets(void 0, void 0, 1, {
                noLoadingTracker: !0
            }), I.getScans(void 0, void 0, 1, {
                noLoadingTracker: !0
            })]).then(function(e) {
                var t = babelHelpers.slicedToArray(e, 2),
                n = t[0].targets,
                r = t[1].scans;
                i.noScansInSystem = 0 === r.length,
                i.noTargetsInSystem = 0 === n.length && i.noScansInSystem
            })
        }
        function W(e, t) {
            t !== e && (Y(), Z(), ue())
        }
        function z(e, t) {
            e === t || fe || a.reload(a.current)
        }
        function Y() {
            var e = i.searchFilters,
            n = [],
            r = t.curryRight(t.join, 2)(", "),
            a = function(e, n) {
                return b.getString(t.get(n, e, S("N/A")))
            };
            e.threatLevel.length > 0 && n.push({
                key: "threat",
                label: S("Threat:"),
                value: r(e.threatLevel.map(function(t) {
                    var n = e.threatLevelList.find(function(e) {
                        return e.value === t
                    });
                    return a("text", n)
                }))
            }),
            e.criticality.length > 0 && n.push({
                label: S("关键性:"),
                key: "criticality",
                value: r(e.criticality.map(function(t) {
                    var n = e.criticalityList.find(function(e) {
                        return e.value === t
                    });
                    return a("text", n)
                }))
            }),
            e.status.length > 0 && n.push({
                key: "status",
                label: S("状态:"),
                value: r(e.status.map(function(t) {
                    var n = e.statusList.find(function(e) {
                        return e.value === t
                    });
                    return a("text", n)
                }))
            }),
            e.profile.length > 0 && n.push({
                key: "profile",
                label: S("扫描类型:"),
                value: r(e.profile.map(function(t) {
                    var n = e.profileList.find(function(e) {
                        return e.profileId === t
                    });
                    return a("name", n)
                }))
            }),
            e.target && n.push({
                key: "target",
                label: S("目标:"),
                value: a("address", e.targetList.find(function(t) {
                    return t.targetId === e.target
                }))
            }),
            e.group.length > 0 && n.push({
                label: S("组织:"),
                key: "group",
                value: r(e.group.map(function(t) {
                    var n = e.groupList.find(function(e) {
                        return e.groupId === t
                    });
                    return a("name", n)
                }))
            }),
            i.searchFilters.filterTags = n
        }
        function Z() {
            var e = i.searchFilters,
            t = e.threatLevel,
            n = e.criticality,
            r = e.status,
            s = e.profile,
            c = e.group,
            u = e.target,
            l = function(e) {
                return Array.isArray(e) ? e.length > 0 ? e.join(",") : void 0 : null !== e && "" !== e ? e: void 0
            },
            d = i.generateReportView ? o.gr: void 0,
            p = {
                threat: l(t),
                criticality: l(n),
                status: l(r),
                profile: l(s),
                group: l(c),
                target: l(u),
                gr: d
            };
            fe = !0,
            a.go(a.current.name, p, {
                inherit: !1
            }).
            finally(function() {
                fe = !1
            })
        }
        function Q() {
            return C.getScanningProfiles({
                tracker: i.loadingTracker
            }).then(function(e) {
                i.searchFilters.profileList = e,
                i.searchFilters.profile = g.getStateParam("profile", !0, t.map(e, t.property("profileId"))),
                Y()
            })
        }
        function X() {
            var e = [],
            n = i.searchFilters,
            r = t.curryRight(t.join, 2)(",");
            return n.threatLevel.length > 0 && e.push("threat:" + r(n.threatLevel)),
            n.criticality.length > 0 && e.push("criticality:" + r(n.criticality)),
            n.status.length > 0 && e.push("status:" + r(n.status)),
            n.profile.length > 0 && e.push("profile_id:" + r(n.profile)),
            n.target && e.push("target_id:" + n.target),
            n.group.length > 0 && e.push("group_id:" + r(n.group)),
            e.join(";")
        }
        function J(t) {
            return ce(function() {
                return i.scanList.gridApi.infiniteScroll.saveScrollPercentage(),
                I.getScans(X(), i.scanList.nextCursor, t ? t.limit: c.LIST_PAGE_SIZE, {
                    onRetry: function() {
                        function e() {
                            return J(t)
                        }
                        return e
                    } ()
                }).then(function(t) {
                    var n = t.scans,
                    r = t.pagination;
                    n.forEach(function(e) {
                        i.scanList.items.find(function(t) {
                            return t.scanId === e.scanId
                        }) || i.scanList.items.push(e)
                    }),
                    i.scanList.nextCursor = r.nextCursor,
                    i.scanList.gridApi.infiniteScroll.dataLoaded(!1, e.isDefined(i.scanList.nextCursor))
                }).
                catch(function(e) {
                    return i.scanList.gridApi.infiniteScroll.dataLoaded(!1, !1),
                    r.reject(e)
                })
            })
        }
        function ee(e, t) {
            return _.generateNewReport(e, t, {
                tracker: i.loadingTracker,
                onRetry: function() {
                    function n() {
                        return ee(e, t)
                    }
                    return n
                } ()
            }).then(function() {
                A.success(b.getString("Your report is being created"))
            })
        }
        function te() {
            return ce(function() {
                var e = 0;
                return P().reduce(function(t, n) {
                    return t.then(function() {
                        return I.removeScan(n.scanId)
                    }).then(function() {
                        i.scanList.gridApi.selection.unSelectRow(n),
                        i.scanList.items.splice(i.scanList.items.indexOf(n), 1),
                        e++
                    })
                },
                r.when()).then(function() {
                    if (e > 0 && void 0 !== i.scanList.nextCursor) return J({
                        limit: e
                    })
                }).then(K)
            })
        }
        function ne() {
            return ce(function() {
                var t = 0,
                n = ["aborted", "aborting", "completed", "failed", "scheduled"];
                return P().reduce(function(r, a) {
                    return n.indexOf(a.status) > -1 ? (i.scanList.gridApi.selection.unSelectRow(a), r) : r.then(function() {
                        return I.abortScan(a.scanId)
                    }).then(function(n) {
                        n ? (e.extend(a, n), i.scanList.gridApi.selection.unSelectRow(a)) : (i.scanList.items.splice(i.scanList.items.indexOf(a), 1), t++)
                    })
                },
                r.when()).then(function() {
                    if (t > 0 && void 0 !== i.scanList.nextCursor) return J({
                        limit: t
                    })
                })
            })
        }
        function re() {
            i.scanList.gridApi && i.scanList.gridApi.infiniteScroll.resetScroll(!1, e.isDefined(i.scanList.nextCursor))
        }
        function ie() {
            v.set("list-scans", i.scanList.gridApi.saveState.save())
        }
        function ae() {
            var e = v.get("list-scans");
            e && i.scanList.gridApi.saveState.restore(i, e)
        }
        function oe() {
            v.remove("list-scans"),
            a.reload(a.current)
        }
        function se() {
            if (i.$$destroyed || pe) return r.when();
            var e = r.defer(),
            n = i.$on("$destroy",
            function() {
                return e.resolve()
            });
            r.when().then(function() {
                pe = !0
            }).then(function() {
                var n = t.chain(t.get(i, "scanList.gridApi.grid.renderContainers.body.renderedRows", [])).map(t.property("entity")).take(20).value();
                return I.refreshScans(n, {
                    timeout: e.promise
                }).then(function(e) {
                    e.forEach(function(e) {
                        var n = i.scanList.items,
                        r = n.find(t.matchesProperty("scanId", e.scanId));
                        if (r && "processing" === r.status) {
                            if (n.indexOf(r) > 0) for (var a = 1; a < n.length; a++) if (null === i.scanList.items[a].lastRun || r.lastRun > n[a].lastRun) {
                                n.splice(a, 0, r),
                                n.splice(n.lastIndexOf(r), 1);
                                break
                            }
                        }
                    })
                })
            }).
            finally(function() {
                n(),
                pe = !1
            })
        }
        function ce(e) {
            var t = i.loadingTracker.createPromise();
            return r.when().then(e).
            finally(t.resolve)
        }
        function ue() {
            i.scanList.items.splice(0),
            i.scanList.nextCursor = void 0,
            i.scanList.gridApi && i.scanList.gridApi.selection && i.scanList.gridApi.selection.clearSelectedRows(),
            re();
            var e = r.defer();
            return s(function() {
                ge.promise.then(J).then(e.resolve, e.reject)
            }),
            e.promise
        }
        function le(e, t) {
            return I.updateScan(e, t, {
                onRetry: function() {
                    function n() {
                        return le(e, t)
                    }
                    return n
                } ()
            })
        }
        var de, pe, fe = !1,
        ge = r.defer(),
        he = c.SCAN_STATUS.filter(function(e) {
            return "continuous" !== e.value
        });
        i.loadingTracker = x({
            activationDelay: c.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        i.scanList = {
            items: [],
            nextCursor: void 0
        },
        i.scanList.gridOptions = {
            data: i.scanList.items,
            appScopeProvider: i,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                cellTemplate: __axtr("/templates/scans/list-scan/cell/address.html"),
                field: "target.address",
                displayName: b.getString("目标"),
                width: 320
            },
            {
                displayName: b.getString("备注"),
                field: "target.description",
                visible: !1,
                width: 240
            },
            {
                displayName: b.getString("扫描类型"),
                field: "profile.name",
                width: 230
            },
            {
                cellTemplate: __axtr("/templates/scans/list-scan/cell/schedule.html"),
                displayName: b.getString("计划表"),
                field: "schedule",
                width: 350
            },
            {
                cellTemplate: __axtr("/templates/scans/list-scan/cell/status.html"),
                displayName: b.getString("状态"),
                field: "status",
                width: 130
            },
            {
                cellTemplate: __axtr("/templates/scans/list-scan/cell/vuln-counters.html"),
                displayName: b.getString("漏洞"),
                field: "severityCounts",
                width: 160
            }],
            gridMenuCustomItems: [{
                title: b.getString("重置布局"),
                action: oe
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.scanId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.scanId
                }
                return e
            } (),
            infiniteScrollRowsFromEnd: 20,
            infiniteScrollUp: !1,
            infiniteScrollDown: !0,
            onRegisterApi: function() {
                function e(e) {
                    i.scanList.gridApi = e,
                    e.infiniteScroll.on.needLoadMoreData(i, J),
                    e.colResizable.on.columnSizeChanged(i, ie),
                    e.core.on.columnVisibilityChanged(i, ie),
                    e.core.on.sortChanged(i, ie),
                    ge.resolve()
                }
                return e
            } ()
        },
        i.searchFilters = {
            threatLevel: g.getStateParam("threat", !0, t.map(c.THREAT_LEVEL, t.property("value"))),
            threatLevelList: c.THREAT_LEVEL,
            criticality: g.getStateParam("criticality", !0, t.map(c.BUSINESS_CRITICALITY, t.property("value"))),
            criticalityList: c.BUSINESS_CRITICALITY,
            status: g.getStateParam("status", !0, t.map(he, t.property("value"))),
            statusList: he,
            profile: g.getStateParam("profile", !0),
            profileList: [],
            target: g.getStateParam("target", !1),
            targetList: [],
            group: g.getStateParam("group", !0),
            groupList: [],
            filterTags: []
        },
        i.filterAsideVisible = !1,
        i.generateReportView = !!o.gr,
        i.noTargetsInSystem = !1,
        i.noScansInSystem = !1,
        i.toggleFilter = R,
        i.selectedItems = P,
        i.selectedItemsCount = N,
        i.onDeleteSelectedScans = D,
        i.onStopSelectedScans = U,
        i.canGenerateReport = V,
        i.canGenerateComparisonReport = M,
        i.onGenerateReport = F,
        i.onGenerateComparisonReport = O,
        i.searchGroups = E,
        i.searchTargets = $,
        i.currentUrl = H,
        i.removeFilterTag = j,
        i.editSchedule = G,
        i.addTargetModal = q,
        i.$on("$destroy", B),
        i.$on("axScrollTop", re),
        i.$watch("searchFilters.status", W),
        i.$watch("searchFilters.target", W),
        i.$watch("searchFilters.group", W),
        i.$watch("searchFilters.profile", W),
        i.$watch("searchFilters.threatLevel", W),
        i.$watch("searchFilters.criticality", W),
        i.$watchCollection(function() {
            return o
        },
        z),
        function() {
            Y(),
            ge.promise.then(function() {
                return E().
                catch(function() {
                    return null
                })
            }).then(function() {
                return $().
                catch(function() {
                    return null
                })
            }).then(function() {
                return Q().
                catch(function() {
                    return null
                })
            }).then(function() {
                return K().
                catch(function() {
                    return null
                })
            }).then(J).
            finally(function() {
                ae(),
                de = n(se, c.LIST_REFRESH_INTERVAL)
            }),
            o.gr && (a.current.data.page.subtitle = S("Generate Report"), i.$on("$destroy",
            function() {
                delete a.current.data.page.subtitle
            }))
        } ()
    }
    n.$inject = ["$interval", "$q", "$scope", "$state", "$stateParams", "$timeout", "axConstant", "axEditScheduleModal", "axGeneralModal", "axGroupsCache", "axPage", "axReportOptionsModal", "axStateHelpers", "axTargetModal", "axTargetsCache", "axUserPreferences", "CurrentUser", "gettext", "gettextCatalog", "orderByFilter", "promiseTracker", "ReportsApi", "ScannerApi", "ScansApi", "TargetGroupsApi", "TargetsApi", "toastr", "uiGridConstants"],
    e.module("WVS").controller("axListScansCtrl", n)
} (angular, _),
function(e) {
    "use strict";
    var t = function() {
        function e(t, n, r) {
            babelHelpers.classCallCheck(this, e),
            this.$rootScope = t,
            this.$q = n,
            this.$uibModal = r
        }
        return e.$inject = ["$rootScope", "$q", "$uibModal"],
        babelHelpers.createClass(e, [{
            key: "resetSensorSecret",
            value: function() {
                function e() {
                    var e = this.$rootScope,
                    t = this.$q,
                    n = this.$uibModal,
                    r = t.defer(),
                    i = e.$new(),
                    a = n.open({
                        keyboard: !1,
                        backdrop: "static",
                        templateUrl: __axtr("/templates/modals/sensor-secret/sensor-secret.modal.html"),
                        scope: i,
                        controller: "axSensorSecretModalCtrl"
                    });
                    return i.$on("axResetSensorSecret",
                    function(e, t) {
                        e.stopPropagation && e.stopPropagation(),
                        a.close(t)
                    }),
                    a.result.then(function(e) {
                        r.resolve(e)
                    }).
                    finally(function() {
                        i.$destroy()
                    }),
                    r.promise
                }
                return e
            } ()
        }]),
        e
    } ();
    e.module("WVS").service("axSensorSecretModal", t)
} (angular),
function(e, t) {
    "use strict";
    function n(e) {
        function n() {
            e.$emit("axResetSensorSecret", {
                sensorSecret: e.secretSection.visible && e.secretSection.secretHash ? e.secretSection.secretHash: void 0
            })
        }
        function r() {
            e.secretSection.secretHash = e.secretSection.visible && e.secretSection.secret ? t.MD5(e.secretSection.secret).toString() : ""
        }
        e.secretSection = {
            secret: "",
            retypeSecret: "",
            secretHash: "",
            visible: !1
        },
        e.resetSecret = n,
        e.$watch(function() {
            return e.secretSection.secret
        },
        r),
        e.$watch(function() {
            return e.secretSection.visible
        },
        r)
    }
    n.$inject = ["$scope"],
    e.module("WVS").controller("axSensorSecretModalCtrl", n)
} (angular, CryptoJS),
function(e) {
    "use strict";
    var t = function() {
        function t(e, n, r) {
            babelHelpers.classCallCheck(this, t),
            this.$q = e,
            this.$rootScope = n,
            this.$uibModal = r
        }
        return t.$inject = ["$q", "$rootScope", "$uibModal"],
        babelHelpers.createClass(t, [{
            key: "chooseScanningOptions",
            value: function() {
                function t() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
                    n = this.$rootScope,
                    r = this.$q,
                    i = this.$uibModal,
                    a = r.defer(),
                    o = e.extend(n.$new(), {
                        scanningOptions: t
                    }),
                    s = i.open({
                        keyboard: !1,
                        backdrop: "static",
                        templateUrl: __axtr("/templates/modals/scanning-options/scanning-options.modal.html"),
                        scope: o,
                        controller: "axScanningOptionsModalCtrl",
                        controllerAs: "$ctrl",
                        bindToController: !0
                    });
                    return o.$on("axLaunchScan",
                    function(e, t) {
                        e.stopPropagation && e.stopPropagation(),
                        s.close(t)
                    }),
                    s.result.then(function(e) {
                        a.resolve(e)
                    }).
                    finally(function() {
                        o.$destroy()
                    }),
                    a.promise
                }
                return t
            } ()
        }]),
        t
    } ();
    e.module("WVS").service("axScanningOptionsModal", t)
} (angular),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c) {
        function u() {
            var t = g.scanningOptions,
            r = e.extend({
                reportType: t.reportType,
                scanProfile: t.scanProfile
            },
            g.selectedSchedule);
            n.$emit("axLaunchScan", r)
        }
        function l(e) {
            g.selectedSchedule = e
        }
        function d() {
            g.loadingTracker.cancel()
        }
        function p() {
            return c.getScanningProfiles({
                noPublishError: !0,
                tracker: g.loadingTracker
            }).then(function(e) {
                g.scanProfileList = e,
                g.scanningOptions.scanProfile = t.get(e, "[0].profileId", null),
                e.find(function(e) {
                    return e.isCustom
                }) && (g.grouping = !0, g.scanProfileList.forEach(function(e) {
                    e.group = i(e.isCustom ? "Custom Profiles": "Standard Profiles")
                }))
            }).
            catch(function(e) {
                return g.error = e.errorMessage,
                r.reject(e)
            })
        }
        function f() {
            return s.getReportTemplates({
                noPublishError: !0,
                tracker: g.loadingTracker
            }).then(function(e) {
                g.reportTypeList = e.filter(function(e) {
                    return ! e.comparison
                })
            }).
            catch(function(e) {
                return g.error = e.errorMessage,
                r.reject(e)
            })
        }
        var g = this;
        g.loadingTracker = a({
            activationDelay: o.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        g.error = "",
        g.scanningOptions = {
            reportType: null,
            scanProfile: null
        },
        g.targetCount = n.scanningOptions ? n.scanningOptions.targetCount: 0,
        g.reportTypeList = [],
        g.scanProfileList = [],
        g.currentSchedule = null,
        g.selectedSchedule = {},
        g.grouping = !1,
        n.scanningOptions && (g.targetCount = n.scanningOptions.targetCount, n.scanningOptions.profileId && (g.scanningOptions.scanProfile = n.scanningOptions.profileId), n.scanningOptions.reportType && (g.scanningOptions.reportType = n.scanningOptions.reportType), n.scanningOptions.schedule && (g.currentSchedule = n.scanningOptions.schedule)),
        g.onLaunchScan = u,
        g.onScheduleChanged = l,
        n.$on("$destroy", d),
        function() {
            p(),
            f()
        } ()
    }
    n.$inject = ["$scope", "$q", "gettext", "promiseTracker", "axConstant", "ReportsApi", "ScannerApi"],
    e.module("WVS").controller("axScanningOptionsModalCtrl", n)
} (angular, _),
function(e) {
    "use strict";
    function t(t, n, r) {
        function i(i) {
            var a = n.defer(),
            o = e.extend(t.$new(), {
                allowComparisonTemplates: i
            }),
            s = r.open({
                keyboard: !1,
                backdrop: "static",
                templateUrl: __axtr("/templates/modals/report-options/report-options.modal.html"),
                controller: "axReportOptionsModalCtrl",
                scope: o
            });
            return o.$on("axGenerateReport",
            function(e, t) {
                e.stopPropagation && e.stopPropagation(),
                s.close(t)
            }),
            s.result.then(function(e) {
                a.resolve(e)
            }),
            s.result.
            finally(function() {
                o.$destroy()
            }),
            a.promise
        }
        this.chooseReportOptions = i
    }
    t.$inject = ["$rootScope", "$q", "$uibModal"],
    e.module("WVS").service("axReportOptionsModal", t)
} (angular),
function(e) {
    "use strict";
    function t(e, t, n, r, i) {
        function a() {
            e.$emit("axGenerateReport", {
                templateId: e.reportOptions.templateId
            })
        }
        function o() {
            e.loadingTracker.cancel()
        }
        function s() {
            return i.getReportTemplates({
                noPublishError: !0,
                tracker: e.loadingTracker
            }).then(function(t) {
                e.reportOptions.templateList = e.allowComparisonTemplates ? t: t.filter(function(e) {
                    return ! e.comparison
                })
            }).
            catch(function(n) {
                return e.error = n.errorMessage,
                t.reject(n)
            })
        }
        e.loadingTracker = n({
            activationDelay: r.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        e.reportOptions = {
            templateId: null,
            templateList: []
        },
        e.error = "",
        e.aboutReportTemplatesHelpLink = r.HELP_LINKS["reports.templates"],
        e.generateReport = a,
        e.$on("$destroy", o),
        function() {
            s()
        } ()
    }
    t.$inject = ["$scope", "$q", "promiseTracker", "axConstant", "ReportsApi"],
    e.module("WVS").controller("axReportOptionsModalCtrl", t)
} (angular),
function(e) {
    "use strict";
    function t(t, n, r) {
        function i(i) {
            var a = {
                bugTracker: "github",
                url: "https://api.github.com",
                project: null,
                issueType: null,
                name: "Default",
                auth: {
                    kind: "http_basic",
                    username: "",
                    password: ""
                }
            },
            o = !i;
            i = e.extend({},
            a, i || {});
            var s = n.defer(),
            c = e.extend(t.$new(), {
                trackerConfig: i,
                newTrackerConfig: o
            }),
            u = r.open({
                keyboard: !1,
                backdrop: "static",
                templateUrl: __axtr("/templates/modals/issue-tracker/issue-tracker.modal.html"),
                scope: c,
                controller: "axConfigureIssueTrackerModalCtrl",
                controllerAs: "$ctrl",
                bindToController: !0
            });
            return c.$on("axUpdateTrackerConfig",
            function(e, t) {
                e.stopPropagation && e.stopPropagation(),
                u.close(t)
            }),
            u.result.then(function(e) {
                s.resolve(e)
            }),
            u.result.
            finally(function() {
                c.$destroy()
            }),
            s.promise
        }
        this.configureIssueTracker = i
    }
    t.$inject = ["$rootScope", "$q", "$uibModal"],
    e.module("WVS").service("axConfigureIssueTrackerModal", t)
} (angular),
function(e) {
    "use strict";
    function t(e, t, n, r, i, a) {
        function o() {
            var r = g.connectionTracker.createPromise();
            return i.checkConnection(e.trackerConfig, {
                noPublishError: !0
            }).then(function(e) {
                var n = e.success,
                r = e.errorMessage;
                if (g.error = n ? null: r, g.error) return t.reject({
                    errorMessage: r
                })
            }).
            catch(function(e) {
                return g.error = e.errorMessage || n("Connection to issue tracker cannot be established"),
                t.reject(e)
            }).then(function() {
                if (0 === g.projects.length) return s().then(function() {
                    if (g.projects.length > 0) return e.trackerConfig.project = g.projects[0],
                    c();
                    g.noProjects = !0
                })
            }).
            finally(r.resolve)
        }
        function s() {
            var r = g.projectsTracker.createPromise();
            return i.listProjects(e.trackerConfig, {
                noPublishError: !0
            }).then(function(e) {
                g.error = null,
                g.projects = e,
                g.noProjects = 0 === e.length
            }).
            catch(function(e) {
                return g.error = e.errorMessage || n("No projects are available"),
                t.reject(e)
            }).
            finally(r.resolve)
        }
        function c() {
            var r = g.issueTypesTracker.createPromise();
            return i.listIssueTypes(e.trackerConfig, e.trackerConfig.project, {
                noPublishError: !0
            }).then(function(e) {
                g.error = null,
                g.issueTypes = e
            }).
            catch(function(e) {
                return g.error = e.errorMessage || n("No issue types are available for selected project"),
                t.reject(e)
            }).
            finally(r.resolve)
        }
        function u() {
            return t.when().then(function() {
                return g.validateOnClose ? p() : void 0
            }).then(function() {
                g.error = null,
                e.$emit("axUpdateTrackerConfig", e.trackerConfig.bugTracker ? e.trackerConfig: null)
            })
        }
        function l() {
            return g.connectionTracker.active() || g.validationTracker.active() || g.projectsTracker.active() || g.issueTypesTracker.active()
        }
        function d() {
            g.validationTracker.cancel(),
            g.connectionTracker.cancel()
        }
        function p() {
            var r = g.validationTracker.createPromise();
            return i.checkConnection(e.trackerConfig, {
                noPublishError: !0
            }).then(function(e) {
                var n = e.success,
                r = e.errorMessage;
                if (g.error = n ? null: r, r) return t.reject(r)
            }).then(function() {
                return i.listProjects(e.trackerConfig, {
                    noPublishError: !0
                })
            }).then(function(r) {
                if (!r.find(function(t) {
                    return e.trackerConfig.project && t.projectId === e.trackerConfig.project.projectId
                })) return g.error = n("The selected project is not available"),
                t.reject(g.error)
            }).then(function() {
                if (e.trackerConfig.issueType) return i.listIssueTypes(e.trackerConfig, e.trackerConfig.project, {
                    noPublishError: !0
                }).then(function(r) {
                    if (!r.find(function(t) {
                        return t.issueTypeId === e.trackerConfig.issueType.issueTypeId
                    })) return g.error = n("The selected issue type is not available"),
                    t.reject(g.error)
                })
            }).
            catch(function(e) {
                return g.validateFailed = !0,
                g.error = e.errorMessage || e.message || String(e),
                t.reject(e)
            }).
            finally(r.resolve)
        }
        function f(t, n) {
            if (t !== n) {
                switch (t) {
                case "github":
                    e.trackerConfig.auth.kind = "http_basic",
                    e.trackerConfig.url = h;
                    break;
                case "tfs":
                    e.trackerConfig.url = m,
                    e.trackerConfig.auth.kind = "ntlm";
                    break;
                case "jira":
                    e.trackerConfig.url = v,
                    e.trackerConfig.auth.kind = "http_basic"
                } ("tfs" === t || "jira" === t) && g.issueTypeForm && g.issueTypeForm.issueType.$invalid && g.issueTypeForm.issueType.$setTouched()
            }
        }
        var g = this,
        h = "https://api.github.com/",
        m = "http://localhost:8080/tfs",
        v = "http://localhost:8080/";
        g.bugTrackers = a.BUG_TRACKERS,
        g.authOptions = {
            jira: a.JIRA_BUG_TRACKER_AUTH
        },
        g.projects = [],
        g.issueTypes = [],
        g.validateOnClose = !0,
        g.validateFailed = !1,
        g.error = "",
        g.noProjects = !1,
        g.validationTracker = r({
            activationDelay: 0
        }),
        g.connectionTracker = r({
            activationDelay: 0
        }),
        g.projectsTracker = r({
            activationDelay: 0
        }),
        g.issueTypesTracker = r({
            activationDelay: 0
        }),
        g.newTrackerConfig = e.newTrackerConfig,
        g.onTestConnection = o,
        g.onRefreshProjects = s,
        g.onRefreshIssueTypes = c,
        g.onUpdate = u,
        g.shouldOverlayContents = l,
        e.$on("$destroy", d),
        function() {
            e.$watch("trackerConfig.bugTracker", f),
            g.projects = e.trackerConfig.project ? [e.trackerConfig.project] : [],
            g.issueTypes = e.trackerConfig.issueType ? [e.trackerConfig.issueType] : []
        } ()
    }
    t.$inject = ["$scope", "$q", "gettext", "promiseTracker", "IssueTrackersApi", "axConstant"],
    e.module("WVS").controller("axConfigureIssueTrackerModalCtrl", t)
} (angular),
function(e) {
    "use strict";
    function t(t, n, r) {
        function i(i) {
            var a = n.defer(),
            o = e.extend(t.$new(), {
                profile: i
            }),
            s = r.open({
                keyboard: !1,
                backdrop: "static",
                templateUrl: __axtr("/templates/modals/exclusion-hours/exclusion-hours.modal.html"),
                scope: o,
                controller: "axExclusionHoursProfileModalCtrl",
                controllerAs: "$ctrl",
                bindToController: !0,
                size: "lg"
            });
            return o.$on("axProfileUpdated",
            function(e, t) {
                e.stopPropagation && e.stopPropagation(),
                s.close(t)
            }),
            o.$on("axProfileCreated",
            function(e, t) {
                e.stopPropagation && e.stopPropagation(),
                s.close(t)
            }),
            s.result.then(function(e) {
                a.resolve(e)
            }),
            s.result.
            finally(function() {
                o.$destroy()
            }),
            a.promise
        }
        this.open = i
    }
    t.$inject = ["$rootScope", "$q", "$uibModal"],
    e.module("WVS").service("axExclusionHoursProfileModal", t)
} (angular),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s) {
        function c(t) {
            p.selectedProfile && (p.selectedProfile.exclusions = e.copy(t))
        }
        function u() {
            var e = p.loadingTracker.createPromise();
            r.when().then(function() {
                return s.createExcludedHoursProfile(p.selectedProfile, {
                    noPublishError: !0,
                    tracker: p.loadingTracker
                })
            }).then(function(e) {
                p.error = null,
                n.$emit("axProfileCreated", e)
            }).
            catch(function(e) {
                return p.error = e.errorMessage || a("The excluded hours profile could not be created"),
                r.reject(e)
            }).
            finally(e.resolve)
        }
        function l() {
            var e = p.loadingTracker.createPromise();
            r.when().then(function() {
                return s.modifyExcludedHoursProfile(t.omit(p.selectedProfile, ["isNew"]), {
                    noPublishError: !0,
                    tracker: p.loadingTracker
                })
            }).then(function(e) {
                p.error = null,
                n.$emit("axProfileCreated", e)
            }).
            catch(function(e) {
                return p.error = e.errorMessage || a("The excluded hours profile could not be updated"),
                r.reject(e)
            }).
            finally(e.resolve)
        }
        function d() {
            p.loadingTracker.cancel()
        }
        var p = this;
        p.loadingTracker = o({
            activationDelay: 0
        }),
        p.selectedProfile = void 0,
        p.error = "",
        p.currentUser = i.get(),
        e.extend(p, {
            onCreateProfile: u,
            onUpdateProfile: l,
            onExclusionsChanged: c
        }),
        n.$on("$destroy", d),
        function() {
            n.profile ? p.selectedProfile = e.copy(n.profile) : p.selectedProfile = {
                name: "New Profile",
                timeOffset: -(new Date).getTimezoneOffset(),
                exclusions: t.range(168).map(t.stubFalse),
                isNew: !0
            }
        } ()
    }
    n.$inject = ["$scope", "$q", "CurrentUser", "gettext", "promiseTracker", "ExcludedHoursApi"],
    e.module("WVS").controller("axExclusionHoursProfileModalCtrl", n)
} (angular, _),
function(e) {
    "use strict";
    function t(t, n, r) {
        function i(i) {
            if (null === i) throw new Error("Parameter 'schedule' cannot be null.");
            var a = n.defer(),
            o = e.extend(t.$new(), {
                schedule: i
            }),
            s = r.open({
                keyboard: !1,
                backdrop: "static",
                templateUrl: __axtr("/templates/modals/edit-schedule/edit-schedule.modal.html"),
                scope: o,
                controller: "axEditScheduleModalCtrl",
                controllerAs: "$ctrl",
                bindToController: !0
            });
            return o.$on("axUpdateSchedule",
            function(e, t) {
                e.stopPropagation && e.stopPropagation(),
                s.close(t)
            }),
            o.$on("axDisableSchedule",
            function(e, t) {
                e.stopPropagation && e.stopPropagation(),
                s.close({
                    disabled: t.disabled
                })
            }),
            s.result.then(function(e) {
                a.resolve(e)
            }),
            s.result.
            finally(function() {
                o.$destroy()
            }),
            a.promise
        }
        this.editSchedule = i
    }
    t.$inject = ["$rootScope", "$q", "$uibModal"],
    e.module("WVS").service("axEditScheduleModal", t)
} (angular),
function(e) {
    "use strict";
    function t(t) {
        function n() {
            t.$emit("axUpdateSchedule", e.extend(e.copy(a.selectedSchedule), {
                disabled: !1
            }))
        }
        function r() {
            t.$emit("axDisableSchedule", e.extend(e.copy(a.selectedSchedule), {
                disabled: !0
            }))
        }
        function i(e) {
            a.selectedSchedule = e
        }
        var a = this;
        a.currentSchedule = t.schedule,
        a.selectedSchedule = {},
        a.onUpdateSchedule = n,
        a.onScheduleChanged = i,
        a.onDisableSchedule = r
    }
    t.$inject = ["$scope"],
    e.module("WVS").controller("axEditScheduleModalCtrl", t)
} (angular),
function(e) {
    "use strict";
    var t = function() {
        function t(e, n, r) {
            babelHelpers.classCallCheck(this, t),
            this.$rootScope = e,
            this.$q = n,
            this.$uibModal = r
        }
        return t.$inject = ["$rootScope", "$q", "$uibModal"],
        babelHelpers.createClass(t, [{
            key: "editGroup",
            value: function() {
                function t(t) {
                    var n = this.$rootScope,
                    r = this.$q,
                    i = this.$uibModal,
                    a = r.defer(),
                    o = e.extend(n.$new(), {
                        group: {
                            groupId: t.groupId,
                            name: t.name,
                            description: t.description
                        }
                    }),
                    s = i.open({
                        keyboard: !1,
                        backdrop: "static",
                        templateUrl: __axtr("/templates/modals/edit-group/edit-group.modal.html"),
                        scope: o,
                        controller: "axEditGroupModalCtrl"
                    });
                    return o.$on("axGroupUpdated",
                    function(e, t) {
                        e.stopPropagation && e.stopPropagation(),
                        s.close(t)
                    }),
                    s.result.then(function(e) {
                        a.resolve(e)
                    }),
                    s.result.
                    finally(function() {
                        o.$destroy()
                    }),
                    a.promise
                }
                return t
            } ()
        }]),
        t
    } ();
    e.module("WVS").service("axEditGroupModal", t)
} (angular),
function(e) {
    "use strict";
    function t(t, n, r, i, a) {
        function o() {
            var r = t.loadingTracker.createPromise();
            return a.updateGroup(t.group, {
                noPublishError: !0
            }).then(function(n) {
                return t.error = "",
                t.$emit("axGroupUpdated", e.copy(n)),
                n
            }).
            catch(function(e) {
                return t.error = e.errorMessage,
                n.reject(e)
            }).
            finally(r.resolve)
        }
        function s() {
            t.loadingTracker.cancel()
        }
        t.loadingTracker = r({
            activationDelay: i.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        t.error = "",
        t.updateGroup = o,
        t.$on("$destroy", s)
    }
    t.$inject = ["$scope", "$q", "promiseTracker", "axConstant", "TargetGroupsApi"],
    e.module("WVS").controller("axEditGroupModalCtrl", t)
} (angular),
function(e, t) {
    "use strict";
    function n(n, r, i) {
        function a(a) {
            var o = r.defer(),
            s = e.extend(n.$new(), {
                targetIdList: a.map(function(e) {
                    return t.get(e, "targetId", e)
                })
            }),
            c = i.open({
                keyboard: !1,
                backdrop: "static",
                templateUrl: __axtr("/templates/modals/configure-groups/configure-groups.modal.html"),
                scope: s,
                controller: "axConfigureTargetGroupsModalCtrl"
            });
            return s.$on("axGroupMembershipChanged",
            function(e) {
                e.stopPropagation && e.stopPropagation(),
                c.close()
            }),
            s.$on("axCreateGroupModal",
            function(e) {
                e.stopPropagation && e.stopPropagation(),
                c.dismiss(),
                n.$broadcast("axCreateGroupModal")
            }),
            c.result.then(function() {
                o.resolve()
            }),
            c.result.
            finally(function() {
                s.$destroy()
            }),
            o.promise
        }
        this.configureGroups = a
    }
    n.$inject = ["$rootScope", "$q", "$uibModal"],
    e.module("WVS").service("axTargetConfigureGroupsModal", n)
} (angular, _),
function(e) {
    "use strict";
    function t(t, n, r, i, a, o, s, c) {
        function u() {
            var e = t.loadingTracker.createPromise();
            return l().reduce(function(e, n) {
                var r = n.groupId;
                return e.then(function() {
                    return c.changeTargets(r, {
                        add: t.targetIdList
                    },
                    {
                        noPublishError: !0
                    })
                })
            },
            n.when()).
            catch(function(e) {
                return t.error = e.errorMessage,
                n.reject(e)
            }).then(function() {
                t.error = "",
                a.success(r.getString("Group membership updated")),
                t.$emit("axGroupMembershipChanged")
            }).
            finally(e.resolve)
        }
        function l() {
            var e = t.groupList.gridApi && t.groupList.gridApi.selection;
            return e ? e.getSelectedRows() : []
        }
        function d() {
            var e = t.groupList.gridApi && t.groupList.gridApi.selection;
            return e ? e.getSelectedCount() : 0
        }
        function p() {
            t.$emit("axCreateGroupModal")
        }
        function f() {
            t.loadingTracker.cancel()
        }
        function g() {
            t.groupList.gridApi.infiniteScroll.saveScrollPercentage();
            var r = t.loadingTracker.createPromise();
            return c.getGroups(void 0, t.groupList.nextCursor, s.LIST_PAGE_SIZE, {
                noPublishError: !0,
                onRetry: function() {
                    function e() {
                        return g()
                    }
                    return e
                } ()
            }).then(function(n) {
                var r = n.groups,
                i = n.pagination;
                r.forEach(function(e) {
                    t.groupList.items.find(function(t) {
                        return t.groupId === e.groupId
                    }) || t.groupList.items.push(e)
                }),
                t.groupList.nextCursor = i.nextCursor,
                t.groupList.gridApi.infiniteScroll.dataLoaded(!1, e.isDefined(i.nextCursor)),
                t.error = ""
            }).
            catch(function(e) {
                return t.groupList.gridApi.infiniteScroll.dataLoaded(!1, !1),
                t.error = e.errorMessage,
                n.reject(e)
            }).
            finally(r.resolve)
        }
        var h = n.defer();
        t.loadingTracker = i({
            activationDelay: s.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        t.error = "",
        t.groupList = {
            items: [],
            nextCursor: void 0
        },
        t.groupList.gridOptions = {
            data: t.groupList.items,
            appScopeProvider: t,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !1,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            enableHorizontalScrollbar: o.scrollbars.NEVER,
            enableVerticalScrollbar: o.scrollbars.ALWAYS,
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            columnDefs: [{
                field: "name",
                displayName: r.getString("Name"),
                width: "*"
            },
            {
                field: "description",
                displayName: r.getString("Description"),
                width: "*"
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.groupId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.groupId
                }
                return e
            } (),
            infiniteScrollRowsFromEnd: 20,
            infiniteScrollUp: !1,
            infiniteScrollDown: !0,
            onRegisterApi: function() {
                function e(e) {
                    t.groupList.gridApi = e,
                    e.infiniteScroll.on.needLoadMoreData(t, g),
                    h.resolve()
                }
                return e
            } ()
        },
        t.$on("$destroy", f),
        e.extend(t, {
            createGroup: p,
            selectedItems: l,
            selectedItemsCount: d,
            updateGroupMembership: u
        }),
        function() {
            h.promise.then(g)
        } ()
    }
    t.$inject = ["$scope", "$q", "gettextCatalog", "promiseTracker", "toastr", "uiGridConstants", "axConstant", "TargetGroupsApi"],
    e.module("WVS").controller("axConfigureTargetGroupsModalCtrl", t)
} (angular),
function(e) {
    "use strict";
    function t(t, n, r) {
        function i() {
            var i = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
            a = n.defer(),
            o = e.extend(t.$new(), {
                maxUsersLimitReached: i
            }),
            s = r.open({
                keyboard: !1,
                backdrop: "static",
                templateUrl: __axtr("/templates/modals/add-user/add-user.modal.html"),
                scope: o,
                controller: "axAddUserModalCtrl"
            });
            return o.$on("axUserAdded",
            function(e, t) {
                e.stopPropagation && e.stopPropagation(),
                s.close(t)
            }),
            s.result.then(function(e) {
                a.resolve(e)
            }),
            s.result.
            finally(function() {
                o.$destroy()
            }),
            a.promise
        }
        this.addUser = i
    }
    t.$inject = ["$rootScope", "$q", "$uibModal"],
    e.module("WVS").service("axAddUserModal", t)
} (angular),
function(e) {
    "use strict";
    function t(e, t, n, r, i) {
        function a() {
            var n = e.loadingTracker.createPromise(),
            r = n.resolve;
            return i.addUser(e.user, {
                noPublishError: !0
            }).then(function(t) {
                e.error = "",
                e.$emit("axUserAdded", t)
            }).
            catch(function(n) {
                return e.error = n.errorMessage,
                t.reject(n)
            }).
            finally(r)
        }
        function o() {
            e.loadingTracker.cancel()
        }
        e.loadingTracker = n({
            activationDelay: r.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        e.user = {
            email: "",
            firstName: "",
            lastName: "",
            role: "",
            accessAllGroups: !1,
            password: "",
            retypePassword: ""
        },
        e.roleList = r.USER_ROLE,
        e.error = "",
        e.addUser = a,
        e.$on("$destroy", o)
    }
    t.$inject = ["$scope", "$q", "promiseTracker", "axConstant", "ChildUsersApi"],
    e.module("WVS").controller("axAddUserModalCtrl", t)
} (angular),
function(e) {
    "use strict";
    function t(t, n, r) {
        function i() {
            var i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
            a = n.defer(),
            o = e.extend(t.$new(), {
                address: i
            }),
            s = r.open({
                keyboard: !1,
                backdrop: "static",
                templateUrl: __axtr("/templates/modals/add-target/add-target.modal.html"),
                scope: o,
                controller: "axAddTargetModalCtrl"
            });
            return o.$on("axTargetAdded",
            function(e, t) {
                e.stopPropagation && e.stopPropagation(),
                s.close(t)
            }),
            s.result.then(function(e) {
                a.resolve(e)
            }),
            s.result.
            finally(function() {
                o.$destroy()
            }),
            a.promise
        }
        this.addTarget = i
    }
    t.$inject = ["$rootScope", "$q", "$uibModal"],
    e.module("WVS").service("axAddTargetModal", t)
} (angular),
function(e, t) {
    "use strict";
    function n(e, n, r, i, a, o) {
        function s() {
            var i = e.loadingTracker.createPromise(),
            a = e.target,
            s = a.address,
            c = a.description,
            u = a.criticality;
            return o.addTarget(s, c, u, {
                noPublishError: !0
            }).then(function(t) {
                e.error = "",
                e.$emit("axTargetAdded", t)
            }).
            catch(function(i) {
                var a = t.get(i, "data.details[0].body.problems[0]", null);
                return a && "format" === a.code && "body.address" === a.param_path ? e.error = r("Address is not valid [invalid-address-format]") : e.error = i.errorMessage,
                n.reject(i)
            }).
            finally(i.resolve)
        }
        function c() {
            e.loadingTracker.cancel()
        }
        e.loadingTracker = i({
            activationDelay: a.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        e.target = {
            address: null != e.address ? e.address: "",
            description: null != e.description ? e.description: "",
            criticality: null != e.criticality ? e.criticality: "10"
        },
        e.criticalityList = a.BUSINESS_CRITICALITY,
        e.error = "",
        e.addTarget = s,
        e.$on("$destroy", c)
    }
    n.$inject = ["$scope", "$q", "gettext", "promiseTracker", "axConstant", "TargetsApi"],
    e.module("WVS").controller("axAddTargetModalCtrl", n)
} (angular, _),
function(e) {
    "use strict";
    var t = function() {
        function e(t, n, r) {
            babelHelpers.classCallCheck(this, e),
            this.$rootScope = t,
            this.$q = n,
            this.$uibModal = r
        }
        return e.$inject = ["$rootScope", "$q", "$uibModal"],
        babelHelpers.createClass(e, [{
            key: "addGroup",
            value: function() {
                function e() {
                    var e = this.$rootScope,
                    t = this.$q,
                    n = this.$uibModal,
                    r = t.defer(),
                    i = e.$new(),
                    a = n.open({
                        keyboard: !1,
                        backdrop: "static",
                        templateUrl: __axtr("/templates/modals/add-group/add-group.modal.html"),
                        scope: i,
                        controller: "axAddGroupModalCtrl"
                    });
                    return i.$on("axGroupAdded",
                    function(e, t) {
                        e.stopPropagation && e.stopPropagation(),
                        a.close(t)
                    }),
                    a.result.then(function(e) {
                        r.resolve(e)
                    }).
                    finally(function() {
                        i.$destroy()
                    }),
                    r.promise
                }
                return e
            } ()
        }]),
        e
    } ();
    e.module("WVS").service("axAddGroupModal", t)
} (angular),
function(e) {
    "use strict";
    function t(e, t, n, r, i) {
        function a() {
            var n = e.loadingTracker.createPromise();
            return i.addGroup(e.group.name, e.group.description, {
                noPublishError: !0
            }).then(function(t) {
                e.error = "",
                e.$emit("axGroupAdded", t)
            }).
            catch(function(n) {
                return e.error = n.errorMessage,
                t.reject(n)
            }).
            finally(n.resolve)
        }
        function o() {
            e.loadingTracker.cancel()
        }
        e.loadingTracker = n({
            activationDelay: r.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        e.group = {
            name: "",
            description: ""
        },
        e.error = "",
        e.$on("$destroy", o),
        e.addGroup = a
    }
    t.$inject = ["$scope", "$q", "promiseTracker", "axConstant", "TargetGroupsApi"],
    e.module("WVS").controller("axAddGroupModalCtrl", t)
} (angular),
function(e) {
    "use strict";
    var t = function() {
        function e(t, n, r) {
            var i = this;
            babelHelpers.classCallCheck(this, e),
            this.$rootScope = t,
            this.$q = n,
            this.$uibModal = r,
            this.show = function() {
                var e = i.$q,
                t = i.$rootScope,
                n = i.$uibModal,
                r = e.defer(),
                a = t.$new();
                return n.open({
                    keyboard: !1,
                    backdrop: "static",
                    templateUrl: __axtr("/templates/modals/activation/activation.modal.html"),
                    scope: a
                }).result.then(r.resolve, r.reject).
                finally(function() {
                    return a.$destroy()
                }),
                r.promise
            }
        }
        return e.$inject = ["$rootScope", "$q", "$uibModal"],
        e
    } ();
    e.module("WVS").service("axActivationModal", t)
} (angular),
function(e) {
    "use strict";
    function t() {
        return {
            restrict: "A",
            controller: n
        }
    }
    function n(e, t, n, r, i, a, o, s, c, u) {
        function l() {
            return n.get("/build.json", {
                cache: !1,
                timeout: 5e3
            }).then(function(e) {
                return 200 === e.status ? e.data.build: a.reject()
            })
        }
        function d() {
            return c.positionClass = "toast-bottom-left",
            o.info(y, {
                allowHtml: !0,
                preventOpenDuplicates: !0,
                timeOut: 0,
                extendedTimeOut: 0,
                closeButton: !0,
                tapToDismiss: !1,
                autoDismiss: !1,
                onHidden: function() {
                    function t() {
                        e.enabled = !0
                    }
                    return t
                } ()
            }).open.promise.
            finally(function() {
                c.positionClass = "toast-top-right"
            })
        }
        function p() {
            return a.when().then(function() {
                return v ? a.reject() : v = !0
            }).then(l).then(function(t) {
                if (null === m) m = t,
                i.info("Using build " + String(m));
                else if (t !== m) return i.info("A new version of Acunetix is available. Build " + String(t)),
                e.enabled = !1,
                d()
            }).
            finally(function() {
                v = !1
            })
        }
        function f(e) {
            h && (r.cancel(h), h = null),
            e && (h = r(p, u.VERSION_CHECK_INTERVAL))
        }
        function g(t, n) {
            t !== n && f(e.enabled)
        }
        var h = null,
        m = null,
        v = !1,
        y = s.getString('Acunetix has just been updated. <a class="btn btn-sm btn-default" href="/" target="_self" onclick="window.location.reload(true);return false;">REFRESH</a>');
        e.$watch("enabled", g),
        e.$watch(function() {
            return u.VERSION_CHECK_INTERVAL
        },
        g),
        e.$on("$destroy", t.$on(u.API_EVENTS.USER_LOGGED_IN, p)),
        function() {
            e.enabled = !0,
            f(!0),
            p()
        } ()
    }
    n.$inject = ["$scope", "$rootScope", "$http", "$interval", "$log", "$q", "toastr", "gettextCatalog", "toastrConfig", "axConstant"],
    e.module("WVS").directive("axVersionCheck", t)
} (angular),
function(e) {
    "use strict";
    function t() {
        return {
            restrict: "E",
            link: function() {
                function e(e, t, n) {
                    function r() {
                        var e = "";
                        switch (parseInt(n.severity)) {
                        case 0:
                            e = "info";
                            break;
                        case 1:
                            e = "low";
                            break;
                        case 2:
                            e = "medium";
                            break;
                        case 3:
                            e = "high"
                        }
                        t.removeClass(["ax-severity-indicator--", "ax-severity-indicator--high", "ax-severity-indicator--medium", "ax-severity-indicator--low", "ax-severity-indicator--info"].join(" ")).addClass("ax-severity-indicator ax-severity-indicator--" + e).css("marginTop", "-2px")
                    }
                    n.$observe("severity", r),
                    r()
                }
                return e
            } ()
        }
    }
    e.module("WVS").directive("axSeverityIndicator", t)
} (angular),
function(e) {
    "use strict";
    function t(e) {
        return {
            link: function() {
                function t(t, n) {
                    e.enabled(n, !1)
                }
                return t
            } ()
        }
    }
    t.$inject = ["$animate"],
    e.module("WVS").directive("axNoAnimate", t)
} (angular),
function(e) {
    "use strict";
    function t(t, n) {
        return {
            restrict: "E",
            scope: {
                toggleVisibility: "&"
            },
            link: function() {
                function t(t, r) {
                    function i(i) {
                        t.$applyAsync(function() {
                            var a = e.element(i.target);
                            if (! (a.hasClass("ui-select-match-close") || a.closest(".uib-datepicker").size() > 0 || a.closest(".ui-select-choices-row-inner").size() > 0)) {
                                e.element(n[0].elementFromPoint(i.clientX, i.clientY)).closest("ax-filter-aside").size() > 0 || 0 === a.closest("ax-filter-aside,.ax-filter-button").size() && r.hasClass("ax-filter-aside--visible") && t.toggleVisibility()
                            }
                        })
                    }
                    function a() {
                        n.off("click", i)
                    }
                    n.on("click", i),
                    t.$on("$destroy", a)
                }
                return t
            } ()
        }
    }
    t.$inject = ["$rootScope", "$document"],
    e.module("WVS").directive("axFilterAside", t)
} (angular),
function(e) {
    "use strict";
    function t(e, t) {
        return {
            restrict: "E",
            link: function() {
                function n(n, r, i) {
                    function a() {
                        var n = "",
                        a = parseInt(i.criticality),
                        o = t(e(a));
                        switch (a) {
                        case 0:
                            n = "low";
                            break;
                        case 10:
                            n = "normal";
                            break;
                        case 20:
                            n = "high";
                            break;
                        case 30:
                            n = "critical"
                        }
                        r.removeClass(["ax-criticality-indicator--", "ax-criticality-indicator--critical", "ax-criticality-indicator--high", "ax-criticality-indicator--normal", "ax-criticality-indicator--low"].join(" ")).addClass("ax-criticality-indicator ax-criticality-indicator--" + n).text(o)
                    }
                    i.$observe("criticality", a),
                    a()
                }
                return n
            } ()
        }
    }
    t.$inject = ["axBusinessCriticalityFilter", "translateFilter"],
    e.module("WVS").directive("axCriticalityIndicator", t)
} (angular),
function(e) {
    "use strict";
    function t(t, n) {
        return {
            restrict: "A",
            transclude: !0,
            scope: !1,
            template: '<i class="fa fa-fw fa-chevron-left"></i><span class="m-l-xs" ng-transclude>{{::\'返回\'|translate}}</span>',
            link: function() {
                function r(r, i) {
                    function a() {
                        try {
                            var t = decodeURIComponent(r.returnUrl);
                            n.url(e.isString(t) ? t: "/")
                        } catch(e) {}
                    }
                    function o() {
                        i.css("display", r.returnUrl ? "": "none")
                    }
                    function s(e) {
                        r.returnUrl = e,
                        o()
                    }
                    r.returnUrl = t.returnUrl,
                    r.navigateBack = a,
                    r.canNavigateBack = function() {
                        return e.isString(r.returnUrl) && r.returnUrl.length > 0
                    },
                    i.on("click",
                    function() {
                        r.$applyAsync(a)
                    }),
                    r.$watch(function() {
                        return t.returnUrl
                    },
                    s),
                    o()
                }
                return r
            } ()
        }
    }
    t.$inject = ["$stateParams", "$location"],
    e.module("WVS").directive("axBackButton", t)
} (angular),
function(e) {
    "use strict";
    function t(t) {
        return {
            restrict: "A",
            link: function() {
                function n(n, r) {
                    var i = e.element('<div class="app app-header-fixed app-aside-fixed" id="app" ng-class="{\'app-aside-folded\':app.asideFolded}" ui-view></div>'),
                    a = t(i);
                    r.prepend(a(n))
                }
                return n
            } ()
        }
    }
    t.$inject = ["$compile"],
    e.module("WVS").directive("axApplicationHost", t)
} (angular),
function(e, t) {
    "use strict";
    function n() {
        return {
            restrict: "AC",
            link: function() {
                function n(n, r, i) {
                    function a(n) {
                        n.preventDefault();
                        var a = i.uiToggleClass.split(","),
                        s = i.target && i.target.split(",") || [r],
                        c = 0;
                        e.forEach(a,
                        function(e) {
                            var n = s[s.length && c];
                            e.indexOf("*") !== -1 && o(e, n),
                            t(n).toggleClass(e),
                            c++
                        }),
                        r.toggleClass("active")
                    }
                    function o(e, n) {
                        for (var r = new RegExp("\\s" + e.replace(/\*/g, "[A-Za-z0-9-_]+").split(" ").join("\\s|\\s") + "\\s", "g"), i = " " + t(n)[0].className + " "; r.test(i);) i = i.replace(r, " ");
                        t(n)[0].className = t.trim(i)
                    }
                    r.on("click",
                    function(e) {
                        n.$applyAsync(function() {
                            return a(e)
                        })
                    })
                }
                return n
            } ()
        }
    }
    e.module("WVS").directive("uiToggleClass", n)
} (angular, jQuery),
function(e, t) {
    "use strict";
    function n(e, n) {
        return {
            restrict: "A",
            link: function() {
                function r(r, i, a) {
                    function o() {
                        e(function() {
                            var e = a.uiShift,
                            t = a.target;
                            c.hasClass("in") || c[e](t).addClass("in")
                        })
                    }
                    function s() {
                        d && d.prepend(i),
                        !d && c.insertAfter(l),
                        c.removeClass("in")
                    }
                    var c = t(i),
                    u = t(n),
                    l = c.prev(),
                    d = void 0,
                    p = u.width(); ! l.length && (d = c.parent()),
                    p < 768 && o() || s(),
                    u.resize(function() {
                        p !== u.width() && e(function() {
                            u.width() < 768 && o() || s(),
                            p = u.width()
                        })
                    })
                }
                return r
            } ()
        }
    }
    n.$inject = ["$timeout", "$window"],
    e.module("WVS").directive("uiShift", n)
} (angular, jQuery),
function(e) {
    "use strict";
    function t(t, n) {
        return {
            restrict: "AC",
            link: function() {
                function r(r, i, a) {
                    "_top" === a.uiScrollTo && a.uiScrollToTarget ? i.on("click",
                    function() {
                        return r.$apply(function() {
                            e.element(a.uiScrollToTarget).scrollTop(0)
                        }),
                        !1
                    }) : i.on("click",
                    function() {
                        r.$apply(function() {
                            t.hash(a.uiScrollTo),
                            n()
                        })
                    })
                }
                return r
            } ()
        }
    }
    t.$inject = ["$location", "$anchorScroll"],
    e.module("WVS").directive("uiScrollTo", t)
} (angular),
function(e, t) {
    "use strict";
    function n(e) {
        return {
            restrict: "AC",
            link: function() {
                function n(n, r) {
                    var i = t(e),
                    a = t(".app-aside"),
                    o = void 0;
                    r.on("click", "a",
                    function(e) {
                        o && o.trigger("mouseleave.nav");
                        var n = t(this);
                        n.parent().siblings(".active").toggleClass("active"),
                        n.next().is("ul") && n.parent().toggleClass("active") && e.preventDefault(),
                        n.next().is("ul") || i.width() < 768 && t(".off-screen").removeClass("show off-screen")
                    }),
                    r.on("mouseenter", "a",
                    function(e) {
                        if (o && o.trigger("mouseleave.nav"), t("> .nav", a).remove(), !(!t(".app-aside-fixed.app-aside-folded").length || i.width() < 768 || t(".app-aside-dock").length)) {
                            var n = t(e.target),
                            r = void 0,
                            s = i.height(); ! n.is("a") && (n = n.closest("a")),
                            n.next().is("ul") && (o = n.next(), n.parent().addClass("active"), r = n.parent().position().top + 50, o.css("top", r), r + o.height() > s && o.css("bottom", 0), r + 150 > s && o.css("bottom", s - r - 50).css("top", "auto"), o.appendTo(a), o.on("mouseleave.nav",
                            function() {
                                t(".dropdown-backdrop").remove(),
                                o.appendTo(n.parent()),
                                o.off("mouseleave.nav").css("top", "auto").css("bottom", "auto"),
                                n.parent().removeClass("active")
                            }), t(".smart").length && t('<div class="dropdown-backdrop"/>').insertAfter(".app-aside").on("click",
                            function(e) {
                                e && e.trigger("mouseleave.nav")
                            }))
                        }
                    }),
                    a.on("mouseleave",
                    function() {
                        o && o.trigger("mouseleave.nav"),
                        t("> .nav", a).remove()
                    })
                }
                return n
            } ()
        }
    }
    n.$inject = ["$window"],
    e.module("WVS").directive("uiNav", n)
} (angular, jQuery),
function(e) {
    "use strict";
    function t(t, n) {
        return {
            restrict: "A",
            compile: function() {
                function r(r, i) {
                    if (!e.isFunction(r[i.uiJq])) throw new Error('ui-jq: The "' + i.uiJq + '" function does not exist');
                    var a = t && t[i.uiJq];
                    return function() {
                        function t(t, r, i) {
                            function o() {
                                var n = [];
                                return i.uiOptions ? (n = t.$eval("[" + i.uiOptions + "]"), e.isObject(a) && e.isObject(n[0]) && (n[0] = e.extend({},
                                a, n[0]))) : a && (n = [a]),
                                n
                            }
                            function s() {
                                n(function() {
                                    r[i.uiJq].apply(r, o())
                                },
                                0, !1)
                            }
                            i.ngModel && r.is("select,input,textarea") && r.bind("change",
                            function() {
                                r.trigger("input")
                            }),
                            s(),
                            function() {
                                i.uiRefresh && t.$watch(i.uiRefresh,
                                function(e, t) {
                                    e != t && s()
                                })
                            } ()
                        }
                        return t
                    } ()
                }
                return r
            } ()
        }
    }
    t.$inject = ["uiJqConfig", "$timeout"],
    e.module("WVS").value("uiJqConfig", {}).directive("uiJq", t)
} (angular),
function(e) {
    "use strict";
    function t(e, t) {
        return {
            link: function() {
                function n(n, r, i) {
                    var a = t(i.uiFocus);
                    n.$watch(a,
                    function(t) {
                        t === !0 && e(function() {
                            r[0].focus()
                        })
                    }),
                    a.assign && r.bind("blur",
                    function() {
                        n.$applyAsync(function() {
                            return a.assign(n, !1)
                        })
                    })
                }
                return n
            } ()
        }
    }
    t.$inject = ["$timeout", "$parse"],
    e.module("WVS").directive("uiFocus", t)
} (angular),
function(e) {
    "use strict";
    function t(e, t) {
        return {
            restrict: "AC",
            template: '<span class="bar"></span>',
            link: function() {
                function e(e, n) {
                    n.addClass("butterbar hide"),
                    e.$on("$stateChangeStart",
                    function() {
                        t(),
                        n.removeClass("hide").addClass("active")
                    }),
                    e.$on("$stateChangeSuccess",
                    function(e) {
                        e.targetScope.$watch("$viewContentLoaded",
                        function() {
                            n.addClass("hide").removeClass("active")
                        })
                    })
                }
                return e
            } ()
        }
    }
    t.$inject = ["$rootScope", "$anchorScroll"],
    e.module("WVS").directive("uiButterbar", t)
} (angular),
function(e) {
    "use strict";
    function t(e) {
        return {
            link: function() {
                function t(t, n, r) {
                    t.$watch(function() {
                        return t.$eval(r.setNgAnimate, t)
                    },
                    function(t) {
                        e.enabled( !! t, n)
                    })
                }
                return t
            } ()
        }
    }
    t.$inject = ["$animate"],
    e.module("WVS").directive("setNgAnimate", t)
} (angular),
function(e) {
    "use strict";
    var t = function() {
        function e(t) {
            babelHelpers.classCallCheck(this, e),
            this.$state = t
        }
        return e.$inject = ["$state"],
        babelHelpers.createClass(e, [{
            key: "navigateToVulnerabilitiesPage",
            value: function() {
                function e(e) {
                    var t = this.$state;
                    this.scanId ? t.go("app.scan_details", {
                        scanId: this.scanId,
                        view: "vulns",
                        severity: e,
                        returnUrl: this.returnUrl
                    }) : this.targetId && t.go("app.list_vulns", {
                        target: this.targetId,
                        status: "open",
                        severity: e,
                        returnUrl: this.returnUrl
                    })
                }
                return e
            } ()
        },
        {
            key: "$onInit",
            value: function() {
                function e() {
                    this.hasLinks = !(!this.scanId && !this.targetId)
                }
                return e
            } ()
        },
        {
            key: "$onChanges",
            value: function() {
                function e() {
                    this.hasLinks = !(!this.scanId && !this.targetId)
                }
                return e
            } ()
        }]),
        e
    } ();
    e.module("WVS").component("axVulnCounters", {
        controller: t,
        templateUrl: __axtr("/templates/components/vuln-counters/vuln-counters.component.html"),
        bindings: {
            vulns: "<",
            targetId: "<?",
            scanId: "<?",
            returnUrl: "<?",
            highSeverityOnly: "<?"
        }
    })
} (angular),
function(e) {
    "use strict";
    var t = {
        3 : "high",
        2 : "medium",
        1 : "low",
        0 : "safe",
        "-1": "none"
    },
    n = function() {
        function n(e, t) {
            babelHelpers.classCallCheck(this, n),
            this.$scope = e,
            this.$element = t,
            e.$applyAsync(function() {
                t.addClass("ax-threat-level__indicator")
            })
        }
        return n.$inject = ["$scope", "$element"],
        babelHelpers.createClass(n, [{
            key: "$onChanges",
            value: function() {
                function n(n) {
                    var r = this.$scope,
                    i = this.$element,
                    a = null;
                    n && n.threat && t.hasOwnProperty(n.threat.currentValue) && (a = t[n.threat.currentValue]),
                    r.$applyAsync(function() {
                        e.forEach(t,
                        function(e) {
                            i.removeClass("ax-threat-level__indicator--" + String(e))
                        }),
                        null !== a && i.addClass("ax-threat-level__indicator--" + String(a))
                    })
                }
                return n
            } ()
        }]),
        n
    } ();
    e.module("WVS").component("axThreatLevel", {
        controller: n,
        template: "",
        bindings: {
            threat: "<"
        }
    })
} (angular),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c) {
        function u(e, n) {
            n && (Array.isArray(e.children) && t.get(e, "children[0].dummy", !1) && e.children.splice(0), 0 === t.get(e, "children.length", 0) && p(e))
        }
        function l(e) {
            if (e.isPlaceholder) {
                d(e.parentLoc).then(function() {
                    t.remove(e.parentLoc.children, e),
                    e.parentLoc = null
                })
            } else m.onLocationSelected && m.onLocationSelected({
                location: e
            })
        }
        function d(e) {
            return m.scanId && m.resultId ? p(e) : r.when()
        }
        function p(n) {
            if (t.get(n, "isFile")) return r.when();
            var a = m.loadingTracker.createPromise();
            return c.getLocationChildren(m.resultId, m.scanId, t.get(n, "locId", 0), t.get(n, "nextCursor"), o.LIST_PAGE_SIZE, {
                cache: s,
                onRetry: function() {
                    function e() {
                        return d(n)
                    }
                    return e
                } ()
            }).then(function(t) {
                var r = t.locations,
                a = t.pagination,
                o = !1;
                if (0 === m.siteStructure.length && r.length > 0 && (o = !0), r.forEach(function(e) {
                    e.parentLoc = n,
                    (e.isFolder || e.isIP) && (e.children = [{
                        locId: (new Date).getDate(),
                        dummy: !0,
                        name: ""
                    }])
                }), n) if (Array.isArray(n.children)) {
                    var s; (s = n.children).push.apply(s, babelHelpers.toConsumableArray(r))
                } else n.children = r;
                else {
                    var c; (c = m.siteStructure).push.apply(c, babelHelpers.toConsumableArray(r))
                }
                if (n && e.isDefined(a.nextCursor) && (n.nextCursor = a.nextCursor, n.children.push({
                    isPlaceholder: !0,
                    name: i.getString("Load more..."),
                    parentLoc: n,
                    locId: (new Date).getDate()
                })), !n && m.siteStructure.length > 0 && (m.selectedLocation = m.siteStructure[0], m.onLocationSelected && m.onLocationSelected({
                    location: m.selectedLocation
                })), o && m.siteStructure.length > 0) return p(r[0]).then(function() {
                    r[0].children.splice(0, 1),
                    m.expandedNodes.push(r[0])
                })
            }).
            catch(function(e) {
                return r.reject(e)
            }).
            finally(a.resolve)
        }
        function f() {
            d()
        }
        function g(e) {
            e.locId && !e.locId.isFirstChange() && (m.selectedLocation = h(m.siteStructure, e.locId.currentValue) || (m.siteStructure.length > 0 ? m.siteStructure[0] : null), m.selectedLocation && m.onLocationSelected && m.onLocationSelected({
                location: m.selectedLocation
            }))
        }
        function h(e, t) {
            for (var n = 0; n < e.length; n++) {
                if (e[n].locId === t) return e[n];
                if (Array.isArray(e[n].children)) {
                    var r = h(e[n].children, t);
                    if (r) return r
                }
            }
            return null
        }
        var m = this;
        m.loadingTracker = a({
            activationDelay: o.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        m.siteStructure = [],
        m.treeOptions = {
            allowDeselect: !1,
            equality: function() {
                function e(e, t) {
                    return e == t || !(!e || !t) && e.locId === t.locId
                }
                return e
            } (),
            isLeaf: function() {
                function e(e) {
                    return ! e.isFolder && !e.isIP
                }
                return e
            } (),
            injectClasses: {
                iLeaf: "fa fa-file-text",
                iExpanded: "fa fa-folder-open",
                iCollapsed: "fa fa-folder"
            }
        },
        m.selectedLocation = null,
        m.expandedNodes = [],
        m.onNodeToggle = u,
        m.onNodeSelected = l,
        m.$onInit = f,
        m.$onChanges = g
    }
    n.$inject = ["$scope", "$q", "gettextCatalog", "promiseTracker", "axConstant", "axLocationsCache", "ResultsApi"],
    e.module("WVS").component("axSiteStructure", {
        controller: n,
        templateUrl: __axtr("/templates/components/site-structure/site-structure.component.html"),
        bindings: {
            scanId: "<",
            resultId: "<",
            locId: "<?",
            onLocationSelected: "&?",
            onLocationLoaded: "&?"
        }
    })
} (angular, _),
function(e, t) {
    "use strict";
    function n(e, n, r) {
        function i() {
            var e = {
                scheduleType: d.scheduleType,
                scheduleDate: d.scheduleDateOptions.selectedDate,
                timeSensitive: !1
            };
            if (d.timeSensitiveOptions.enabled) {
                var n = d.timeSensitiveOptions.selectedTime;
                n && (e.scheduleDate.setHours(n.getHours()), e.scheduleDate.setMinutes(n.getMinutes()), e.scheduleDate.setSeconds(0), e.scheduleDate.setMilliseconds(0), e.timeSensitive = !0)
            }
            if ("recurrent" === e.scheduleType) switch (d.recurrenceOption) {
            case "DAILY":
            case "WEEKLY":
            case "MONTHLY":
                var r = new t({
                    freq: t[d.recurrenceOption],
                    interval: 1,
                    dtstart: e.scheduleDate
                });
                e.recurrence = t.axConversions.rfc3339ToPy(r.toString());
                break;
            case "CUSTOM":
                if (d.rrule) {
                    var i = t.parseString(d.rrule);
                    i.dtstart = e.scheduleDate,
                    e.recurrence = t.axConversions.rfc3339ToPy(new t(i).toString())
                }
            }
            d.onScheduleChanged && d.onScheduleChanged({
                schedule: e
            })
        }
        function a() {
            if (d.scheduleDateOptions.selectedDate) {
                var e = d.timeSensitiveOptions.enabled ? d.timeSensitiveOptions.selectedTime: null,
                t = 0,
                n = 0;
                if (e) {
                    var r = [e.getHours(), e.getMinutes()];
                    t = r[0],
                    n = r[1]
                }
                d.scheduleDateOptions.selectedDate.setHours(t),
                d.scheduleDateOptions.selectedDate.setMinutes(n),
                d.scheduleDateOptions.selectedDate.setSeconds(0),
                d.scheduleDateOptions.selectedDate.setMilliseconds(0)
            }
        }
        function o(e) {
            return e.setHours(0),
            e.setMinutes(0),
            e.setSeconds(0),
            e
        }
        function s(e) {
            e ? (e.scheduleType ? d.scheduleType = e.scheduleType: d.scheduleType = "instant", e.scheduleDate && (d.scheduleDateOptions.selectedDate = e.scheduleDate, d.scheduleType = "future"), e.timeSensitive && (d.timeSensitiveOptions.enabled = !0, d.timeSensitiveOptions.selectedTime = new Date(e.scheduleDate.getTime())), e.recurrence && (d.scheduleType = "recurrent", d.recurrenceOption = "CUSTOM", d.rrule = t.axConversions.pyToRRULE(e.recurrence).toString())) : (d.scheduleType = "instant", d.scheduleDateOptions.selectedDate = o(new Date), d.recurrenceOption = "DAILY", d.timeSensitiveOptions.enabled = !1, d.timeSensitiveOptions.selectedTime = null, d.rrule = "")
        }
        function c() {
            s(d.schedule),
            d.scheduleTypeEditable = !d.schedule,
            e.$watch(function() {
                return d.scheduleType
            },
            i),
            e.$watch(function() {
                return d.recurrenceOption
            },
            i),
            e.$watch(function() {
                return d.scheduleDateOptions.selectedDate
            },
            i),
            e.$watch(function() {
                return d.scheduleDateOptions.selectedDate
            },
            a),
            e.$watch(function() {
                return d.timeSensitiveOptions.enabled
            },
            i),
            e.$watch(function() {
                return d.timeSensitiveOptions.enabled
            },
            a),
            e.$watch(function() {
                return d.timeSensitiveOptions.selectedTime
            },
            i),
            e.$watch(function() {
                return d.timeSensitiveOptions.selectedTime
            },
            a),
            e.$watch(function() {
                return d.rrule
            },
            i)
        }
        function u(e) {
            if (e.schedule && !e.schedule.isFirstChange()) {
                s(e.schedule.currentValue)
            }
        }
        function l() {}
        var d = this;
        d.scheduleType = "instant",
        d.scheduleTypeEditable = !1,
        d.scheduleTypeList = r.SCHEDULE_TYPE.filter(function(e) {
            return "continuous" !== e.value
        }),
        d.scheduleDateOptions = {
            calendarVisible: !1,
            datePickerOptions: {
                showWeeks: !1,
                maxMode: "day"
            },
            selectedDate: o(new Date)
        },
        d.recurrenceOption = "DAILY",
        d.recurrenceOptionList = [{
            value: "DAILY",
            text: n("Daily")
        },
        {
            value: "WEEKLY",
            text: n("Weekly")
        },
        {
            value: "MONTHLY",
            text: n("Monthly")
        },
        {
            value: "YEARLY",
            text: n("Yearly")
        },
        {
            value: "CUSTOM",
            text: n("Custom")
        }],
        d.timeSensitiveOptions = {
            enabled: !1,
            pickerOptions: {
                showMeridian: !1,
                minuteStep: 5,
                showSpinners: !1
            },
            selectedTime: null
        },
        d.rrule = "",
        d.$onInit = c,
        d.$onChanges = u,
        d.$onDestroy = l
    }
    n.$inject = ["$scope", "gettext", "axConstant"],
    e.module("WVS").component("axScheduleEditor", {
        bindings: {
            schedule: "<?",
            onScheduleChanged: "&?"
        },
        templateUrl: __axtr("/templates/components/schedule-editor/schedule-editor.component.html"),
        controller: n
    })
} (angular, RRule),
function(e) {
    "use strict";
    function t(e, t, n, r, i, a) {
        function o() {
            e.$watch(function() {
                return l.scanStatus ? l.scanStatus.status: null
            },
            u),
            e.$watch(function() {
                return i.get()
            },
            function(e) {
                return l.currentUser = e
            })
        }
        function s() {
            return r.currentUrlEncoded()
        }
        function c(e) {
            a.addTarget(e).then(function(e) {
                t.go("app.target_config", {
                    targetId: e.targetId,
                    returnUrl: s()
                },
                {
                    inherit: !1
                })
            })
        }
        function u(e) {
            l.scanHealth = "failed" === e || "aborted" === e || "aborting" === e ? -1 : "scheduled" !== e ? 1 : 0
        }
        var l = this;
        l.currentUser = i.get(),
        l.$onInit = o,
        l.currentUrl = s,
        l.onCreateScanTarget = c,
        l.scanHealth = 0
    }
    t.$inject = ["$scope", "$state", "$stateParams", "axPage", "CurrentUser", "axTargetModal"],
    e.module("WVS").component("axScanStatus", {
        templateUrl: __axtr("/templates/components/scan-status/scan-status.component.html"),
        controller: t,
        bindings: {
            scanId: "<?",
            resultId: "<?",
            scanStatus: "<?",
            targetInfo: "<?"
        }
    })
} (angular),
function(e) {
    "use strict";
    var t = function() {
        function e(t, n, r, i, a) {
            babelHelpers.classCallCheck(this, e),
            this.$element = t,
            this.$q = n,
            this.$rootScope = r,
            this.axConstant = i,
            this.axActivationModal = a,
            this._activationModalIsOpen = !1
        }
        return e.$inject = ["$element", "$q", "$rootScope", "axConstant", "axActivationModal"],
        babelHelpers.createClass(e, [{
            key: "_onProductNotActivated",
            value: function() {
                function e() {
                    var e = this,
                    t = this.$q,
                    n = this.axActivationModal;
                    this._activationModalIsOpen || t.when().then(function() {
                        return e._activationModalIsOpen = !0,
                        n.show()
                    }).
                    finally(function() {
                        e._activationModalIsOpen = !1
                    })
                }
                return e
            } ()
        },
        {
            key: "$onInit",
            value: function() {
                function e() {
                    var e = this,
                    t = this.$rootScope,
                    n = this.axConstant;
                    this.$element.css("display", "none"),
                    this._axProductNotActivatedDeregister = t.$on(n.PRODUCT_ACTIVATION_REQUIRED,
                    function() {
                        return e._onProductNotActivated()
                    })
                }
                return e
            } ()
        },
        {
            key: "$onDestroy",
            value: function() {
                function e() {
                    this._axProductNotActivatedDeregister()
                }
                return e
            } ()
        }]),
        e
    } ();
    e.module("WVS").component("axProductActivation", {
        controller: t
    })
} (angular),
function(e) {
    "use strict";
    var t = function() {
        function e(t, n, r) {
            babelHelpers.classCallCheck(this, e),
            this.$scope = t,
            this.CurrentUser = n,
            this.axConstant = r,
            this.testWebsites = r.TEST_WEBSITES,
            this.currentUser = n.get()
        }
        return e.$inject = ["$scope", "CurrentUser", "axConstant"],
        babelHelpers.createClass(e, [{
            key: "$onInit",
            value: function() {
                function e() {
                    var e = this,
                    t = this.$scope,
                    n = this.CurrentUser;
                    t.$watch(function() {
                        return n.get()
                    },
                    function(t) {
                        e.currentUser = t || void 0
                    })
                }
                return e
            } ()
        }]),
        e
    } ();
    e.module("WVS").component("axLicenseInfo", {
        templateUrl: __axtr("/templates/components/license-info/license-info.component.html"),
        controller: t,
        bindings: {
            licenseInfo: "<"
        }
    })
} (angular),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o) {
        function s() {
            try {
                var r = t.fromString(p.rrule);
                switch (r.options.freq) {
                case t.DAILY:
                    p.frequency = "day";
                    break;
                case t.WEEKLY:
                    p.frequency = "week";
                    break;
                case t.MONTHLY:
                    p.frequency = "month";
                    break;
                case t.YEARLY:
                    p.frequency = "year"
                }
                r.options.interval && (p.frequencyValue = r.options.interval),
                r.options.until && (p.endsOption = "date", p.endDate = r.options.until),
                e.forEach(r.options.byweekday,
                function(e) {
                    p.selectedWeekDays[p.weekDayList[e].value] = !0
                })
            } catch(e) {}
            n.$watch(function() {
                return p.frequency
            },
            l),
            n.$watch(function() {
                return p.frequencyValue
            },
            l),
            n.$watch(function() {
                return p.endDate
            },
            l),
            n.$watch(function() {
                return p.endsOption
            },
            l),
            n.$watch(function() {
                return p.startDate
            },
            l),
            n.$watchCollection(function() {
                return p.selectedWeekDays
            },
            l)
        }
        function c() {
            p.endDateCalendarVisible = !p.endDateCalendarVisible,
            p.endDateCalendarVisible && (p.endsOption = "date")
        }
        function u() {
            var e = function() {
                switch (p.frequency) {
                case "day":
                    return p.frequencyValue > 1 ? o.getString("Repeats every {{days}} days", {
                        days: p.frequencyValue
                    }) : o.getString("Repeats daily");
                case "week":
                    var e = Object.keys(p.selectedWeekDays).filter(function(e) {
                        return p.selectedWeekDays[e]
                    }).map(function(e) {
                        return p.weekDayList.find(function(t) {
                            return t.value === e
                        })
                    }),
                    t = g(e.map(function(e) {
                        return e.dayName
                    }), "order", !1, "+");
                    if (7 === t.length) return p.frequencyValue > 1 ? o.getString("Repeats every 2 weeks, every day") : o.getString("Repeats weekly, every day");
                    if (t.length > 0) {
                        var n, r = [t.slice(0, -1).join(", "), t.slice( - 1).join("")],
                        i = r[0],
                        a = r[1];
                        if (n = 0 === i.length ? o.getString("{{dayName}}", {
                            dayName: a
                        }) : o.getString("{{prevDays}} and {{lastDay}}", {
                            prevDays: i,
                            lastDay: a
                        }), p.frequencyValue > 1) return o.getString("Repeats every {{frequency}} weeks on {{days}}", {
                            frequency: p.frequencyValue,
                            days: n
                        });
                        if (1 === p.frequencyValue) return o.getString("Repeats weekly on {{days}} ", {
                            days: n
                        })
                    }
                    return o.getString("Repeats weekly");
                case "month":
                    return p.frequencyValue > 1 ? o.getString("Repeats every {{frequency}} months on the same day each month", {
                        frequency: p.frequencyValue
                    }) : o.getString("Repeats monthly on the same day each month");
                case "year":
                    return p.frequencyValue > 1 ? o.getString("Repeats every {{frequency}} years", {
                        frequency: p.frequencyValue
                    }) : o.getString("Repeats yearly")
                }
            } ();
            return "date" === p.endsOption && p.endDate ? e + o.getString(" until {{date}}", {
                date: f(p.endDate, "mediumDate")
            }) : e
        }
        function l() {
            try {
                var n = {
                    freq: t.DAILY,
                    interval: 1,
                    dtstart: e.isDate(p.startDate) ? p.startDate: new Date
                };
                switch (p.frequency) {
                case "day":
                    n.freq = t.DAILY;
                    break;
                case "week":
                    n.freq = t.WEEKLY,
                    n.byweekday = Object.keys(p.selectedWeekDays).filter(function(e) {
                        return !! p.selectedWeekDays[e]
                    }).map(function(e) {
                        return t[e]
                    });
                    break;
                case "month":
                    n.freq = t.MONTHLY,
                    n.bymonthday = n.dtstart.getDate();
                    break;
                case "year":
                    n.freq = t.YEARLY
                }
                e.isNumber(p.frequencyValue) && p.frequencyValue > 0 && p.frequencyValue < 100 && (n.interval = p.frequencyValue),
                "date" === p.endsOption && e.isDate(p.endDate) && (n.until = p.endDate);
                var r = new t(n);
                p.rrule = r.toString()
            } catch(e) {
                i.warning(e)
            }
        }
        function d(e) {
            return e.setHours(0),
            e.setMinutes(0),
            e.setSeconds(0),
            e
        }
        var p = this,
        f = r("date"),
        g = r("orderBy");
        p.frequencyList = [{
            value: "day",
            text: a("Day")
        },
        {
            value: "week",
            text: a("Week")
        },
        {
            value: "month",
            text: a("Month")
        },
        {
            value: "year",
            text: a("Year")
        }],
        p.frequency = p.frequencyList[0].value,
        p.frequencyValue = 1,
        p.weekDayList = [{
            order: 1,
            value: "MO",
            dayName: "Monday",
            text: a("Mon")
        },
        {
            order: 2,
            value: "TU",
            dayName: "Tuesday",
            text: a("Tue")
        },
        {
            order: 3,
            value: "WE",
            dayName: "Wednesday",
            text: a("Wed")
        },
        {
            order: 4,
            value: "TH",
            dayName: "Thursday",
            text: a("Thu")
        },
        {
            order: 5,
            value: "FR",
            dayName: "Friday",
            text: a("Fri")
        },
        {
            order: 6,
            value: "SA",
            dayName: "Saturday",
            text: a("Sat")
        },
        {
            order: 7,
            value: "SU",
            dayName: "Sunday",
            text: a("Sun")
        }],
        p.selectedWeekDays = {},
        p.endDateDatePickerOptions = {
            minDate: d(new Date),
            showWeeks: !1,
            maxMode: "day"
        },
        p.endDateCalendarVisible = !1,
        p.endDate = d(new Date),
        p.endsOption = "never",
        p.toggleEndDateCalendarVisibility = c,
        p.getRepeatMessage = u,
        p.$onInit = s
    }
    n.$inject = ["$scope", "$filter", "$log", "gettext", "gettextCatalog"],
    e.module("WVS").component("axRecurrencePicker", {
        templateUrl: __axtr("/templates/components/ical/ical.component.html"),
        controller: n,
        bindings: {
            startDate: "<",
            rrule: "="
        }
    })
} (angular, RRule),
function(e) {
    "use strict";
    function t() {
        var e = this;
        this.toggle = function(t) {
            return t.stopPropagation(),
            t.preventDefault(),
            e.toggleAside && e.toggleAside(),
            !1
        }
    }
    e.module("WVS").component("axFilterTags", {
        templateUrl: __axtr("/templates/components/filter-tags/filter-tags.component.html"),
        controller: t,
        bindings: {
            tags: "<",
            removeTag: "&?",
            toggleAside: "&?"
        }
    })
} (angular),
function(e) {
    "use strict";
    function t(t, r, i) {
        function a(e) {
            e && (u.currentFile = e, c()),
            u.onFileSelected && u.onFileSelected({
                file: u.currentFile
            })
        }
        function o(t) {
            return t.status === !1 && e.isNumber(t.totalBytes) && e.isNumber(t.uploadedBytes) && t.uploadedBytes < t.totalBytes
        }
        function s(e) {
            return e.totalBytes > 0 ? Math.round(e.uploadedBytes / e.totalBytes * 100) : 0
        }
        function c() {
            u.state = n.hasFile,
            u.currentFile ? u.uploading ? (u.state = n.uploading, u.uploadProgress = s(u.currentFile)) : u.currentFile.status === !0 ? u.state = n.complete: u.currentFile.status === !1 && o(u.currentFile) && (u.state = n.incomplete, u.uploadProgress = s(u.currentFile)) : u.state = n.noFile
        }
        var u = this;
        u.state = n.noFile,
        u.currentFile = null,
        u.$onInit = function() {
            e.isUndefined(u.disallowChange) && (u.disallowChange = !1),
            e.isUndefined(u.disallowRemove) && (u.disallowRemove = !1),
            t.$watch(function() {
                return u.currentFile ? u.currentFile.uploadedBytes: 0
            },
            c),
            r.find('input[type="file"]').on("change",
            function(e) {
                t.$applyAsync(function() {
                    if (e.target.files.length > 0) {
                        var t = e.target.files[0];
                        a({
                            name: t.name,
                            totalBytes: t.size,
                            nativeFileUpload: t
                        })
                    }
                })
            })
        },
        u.$onChanges = function(e) {
            e.file && (u.uploading && !e.file.isFirstChange() && i.warn("Changing current file while control is in uploading state"), u.currentFile = e.file.currentValue, c()),
            e.uploading && c()
        },
        u.$onDestroy = function() {
            r.find('input[type="file"]').off("change"),
            u.currentFile = null,
            u.state = n.noFile
        },
        u.chooseFile = function() {
            t.$applyAsync(function() {
                r.find('input[type="file"]').click()
            })
        },
        u.removeFile = function() {
            t.$applyAsync(function() {
                r.find('input[type="file"]').val("");
                try {
                    u.currentFile && u.onFileRemoved && u.onFileRemoved({
                        file: u.currentFile
                    })
                } finally {
                    u.currentFile = null
                }
            })
        }
    }
    t.$inject = ["$scope", "$element", "$log"];
    var n = {
        noFile: "no-file",
        hasFile: "has-file",
        uploading: "uploading",
        incomplete: "incomplete",
        complete: "complete"
    };
    e.module("WVS").component("axFileUpload", {
        controller: t,
        templateUrl: __axtr("/templates/components/file-upload/file-upload.component.html"),
        bindings: {
            accept: "@?",
            uploading: "<?",
            file: "<?",
            onFileSelected: "&?",
            onFileRemoved: "&?",
            readOnly: "<?",
            disallowChange: "<?",
            disallowRemove: "<?"
        }
    })
} (angular),
function(e, t) {
    "use strict";
    function n() {
        function e(e) {
            if (e.profile) {
                if (e.profile.currentValue) {
                    e.profile.currentValue.exclusions.forEach(function(e, t) {
                        s.hours[Math.floor(t / 24)].hours[t % 24].selected = e
                    })
                } else s.hours.forEach(function(e) {
                    e.hours.forEach(function(e) {
                        e.selected = !1
                    })
                });
                s.readOnly || o()
            }
        }
        function n(e) {
            s.readOnly || (e.selected = !e.selected, o())
        }
        function r(e) {
            if (!s.readOnly) {
                var t = !!e.hours.find(function(e) {
                    return ! e.selected
                });
                e.hours.forEach(function(e) {
                    e.selected = t
                }),
                o()
            }
        }
        function a(e) {
            if (!s.readOnly) {
                for (var t = !1,
                n = 0; n < s.hours.length; n++) if (!s.hours[n].hours[e].selected) {
                    t = !0;
                    break
                }
                for (var r = 0; r < s.hours.length; r++) s.hours[r].hours[e].selected = t;
                o()
            }
        }
        function o() {
            if (s.onExclusionsChanged) {
                var e = s.hours.reduce(function(e, t) {
                    return e.push.apply(e, babelHelpers.toConsumableArray(t.hours.map(function(e) {
                        return e.selected
                    }))),
                    e
                },
                []);
                s.onExclusionsChanged({
                    exclusions: e
                })
            }
        }
        var s = this;
        s.hourLabels = t.range(24).map(function(e) {
            return e < 10 ? t.padStart(String(e), 2, "0") : e.toString()
        }),
        s.hours = i.map(function(e) {
            return {
                dayName: e,
                hours: t.range(24).map(function(e) {
                    return {
                        label: e < 10 ? t.padStart(String(e), 2, "0") : e.toString(),
                        selected: !1
                    }
                })
            }
        }),
        s.$onChanges = e,
        s.onRowCellClicked = n,
        s.onRowHeaderClicked = r,
        s.onColumnHeaderClicked = a
    }
    var r = e.identity,
    i = [r("Sunday"), r("Monday"), r("Tuesday"), r("Wednesday"), r("Thursday"), r("Friday"), r("Saturday")];
    e.module("WVS").component("axExclusionHours", {
        controller: n,
        templateUrl: __axtr("/templates/components/exclusion-hours/exclusion-hours.component.html"),
        bindings: {
            profile: "<?",
            readOnly: "<?",
            onExclusionsChanged: "&?"
        }
    })
} (angular, _),
function(e) {
    "use strict";
    function t(t, i, a, o, s, c, u, l, d, p) {
        function f() {
            var e = I.loadingTracker.createPromise();
            return i.when().then(function() {
                I.eventList.gridApi.infiniteScroll.saveScrollPercentage()
            }).then(function() {
                return d.getEvents(I.searchQuery, I.eventList.nextCursor, u.LIST_PAGE_SIZE, {
                    onRetry: function() {
                        function e() {
                            return f()
                        }
                        return e
                    } ()
                })
            }).then(function(e) {
                var t = e.notifications,
                r = e.pagination;
                t.forEach(function(e) {
                    I.eventList.items.find(function(t) {
                        return t.eventId === e.eventId
                    }) || I.eventList.items.push(e)
                }),
                I.eventList.nextCursor = r.nextCursor,
                I.eventList.gridApi.infiniteScroll.dataLoaded(!1, n(r.nextCursor))
            }).
            catch(function(e) {
                return I.eventList.gridApi.infiniteScroll.dataLoaded(!1, !1),
                i.reject(e)
            }).
            finally(e.resolve)
        }
        function g() {
            var e = I.eventList.gridApi && I.eventList.gridApi.selection;
            return e ? e.getSelectedRows() : []
        }
        function h() {
            var e = I.eventList.gridApi && I.eventList.gridApi.selection;
            return e ? e.getSelectedCount() : 0
        }
        function m() {
            k = t.$watchCollection(function() {
                return o
            },
            function() {
                I.returnUrl = l.currentUrlEncoded()
            })
        }
        function v() {
            I.eventList.gridApi && I.eventList.gridApi.infiniteScroll.resetScroll(!1, void 0 !== I.eventList.nextCursor)
        }
        function y() {
            return I.eventList.items.splice(0),
            I.eventList.nextCursor = void 0,
            w.promise.then(f)
        }
        function S() {
            I.layoutSaveKey && p.set(I.layoutSaveKey, I.eventList.gridApi.saveState.save())
        }
        function b() {
            if (I.layoutSaveKey) {
                var e = p.get(I.layoutSaveKey);
                e && I.eventList.gridApi.saveState.restore(t, e)
            }
        }
        function T() {
            I.layoutSaveKey && (p.remove(I.layoutSaveKey), a.reload(a.current))
        }
        function x() {
            r(I.returnUrl) && m(),
            w.promise.then(y).then(b)
        }
        function _(t) {
            n(t.returnUrl) && !t.returnUrl.isFirstChange() && (e.isString(t.returnUrl.currentValue) && !k ? m() : r(t.returnUrl) && k && (k(), k = void 0)),
            n(t.layoutSaveKey) && !t.layoutSaveKey.isFirstChange() && t.layoutSaveKey.previousValue && (p.remove(t.layoutSaveKey.previousValue), S()),
            t.searchQuery && !t.searchQuery.isFirstChange() && y()
        }
        function C() {
            I.loadingTracker.cancel()
        }
        var I = this,
        w = i.defer(),
        k = void 0;
        I.loadingTracker = c(u.PROMISE_TRACKER_ACTIVATION_DELAY),
        I.eventList = {
            items: [],
            nextCursor: void 0
        },
        I.eventList.gridOptions = {
            data: I.eventList.items,
            appScopeProvider: I,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableRowHeaderSelection: !1,
            enableRowSelection: !1,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                field: "eventTypeId",
                displayName: s.getString("事件"),
                cellFilter: "axEventName",
                width: 300
            },
            {
                field: "eventData",
                displayName: s.getString("附加信息"),
                width: "*"
            },
            {
                field: "created",
                displayName: s.getString("创建于"),
                cellFilter: "date:'medium'",
                width: 160
            }],
            gridMenuCustomItems: [{
                title: s.getString("重置布局"),
                action: T
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.eventId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.eventId
                }
                return e
            } (),
            infiniteScrollRowsFromEnd: 20,
            infiniteScrollUp: !1,
            infiniteScrollDown: !0,
            onRegisterApi: function() {
                function e(e) {
                    I.eventList.gridApi = e,
                    e.infiniteScroll.on.needLoadMoreData(t, f),
                    e.colResizable.on.columnSizeChanged(t, S),
                    e.core.on.columnVisibilityChanged(t, S),
                    e.core.on.sortChanged(t, S),
                    w.resolve()
                }
                return e
            } ()
        },
        I.selectedItems = g,
        I.selectedItemsCount = h,
        I.$onInit = x,
        I.$onChanges = _,
        I.$onDestroy = C,
        t.$on("axScrollTop", v)
    }
    t.$inject = ["$scope", "$q", "$state", "$stateParams", "gettextCatalog", "promiseTracker", "axConstant", "axPage", "NotificationsApi", "axUserPreferences"];
    var n = e.isDefined,
    r = e.isUndefined;
    e.module("WVS").component("axEvents", {
        templateUrl: __axtr("/templates/components/events/events.component.html"),
        controller: t,
        bindings: {
            returnUrl: "<?",
            searchQuery: "<",
            layoutSaveKey: "@?"
        }
    })
} (angular),
function(e) {
    "use strict";
    function t(t, n) {
        function r() {
            c.errors.splice(0)
        }
        function i(t, n) {
            var r = n.errorMessage || n.message,
            i = ~~c.maxDisplayErrors,
            o = {};
            0 !== c.errors.length && c.errors[0].message === r || (o = {
                message: r
            },
            c.errors.unshift(o)),
            i > 0 && c.errors.length > i && c.errors.splice(i),
            n.config && e.isFunction(n.config.onRetry) ? o.onRetry = a(n.config.onRetry, n) : e.isFunction(n.onRetry) && (o.onRetry = a(n.onRetry, n))
        }
        function a(e, t) {
            return function() {
                function i() {
                    try {
                        r(),
                        e.call(void 0, t)
                    } catch(e) {
                        n.error(e)
                    }
                }
                return i
            } ()
        }
        function o() {
            c.errors = [],
            u = t.$on("axApiError", i),
            l = t.$on("axError", i)
        }
        function s() {
            c.errors.splice(0),
            u(),
            l()
        }
        var c = this,
        u = void 0,
        l = void 0;
        this.dismiss = r,
        this.$onInit = o,
        this.$onDestroy = s
    }
    t.$inject = ["$rootScope", "$log"],
    e.module("WVS").component("axErrorPresenter", {
        controller: t,
        templateUrl: __axtr("/templates/components/error-presenter/error-presenter.component.html"),
        bindings: {
            maxDisplayErrors: "<?"
        }
    })
} (angular),
function(e) {
    "use strict";
    function t() {}
    e.module("WVS").component("axCrawlBreadcrumb", {
        controller: t,
        templateUrl: __axtr("/templates/components/crawl-breadcrumb/crawl-breadcrumb.component.html"),
        bindings: {
            locations: "<",
            onLocationClick: "&?"
        }
    })
} (angular),
function(e) {
    "use strict";
    var t = function() {
        function e(t, n, r, i, a, o, s) {
            var c = this;
            babelHelpers.classCallCheck(this, e),
            this.$scope = t,
            this.promiseTracker = n,
            this.$document = i,
            this.$state = a,
            this.gettextCatalog = o,
            this.AccountApi = s,
            this.loadingTracker = n({
                activationDelay: r.PROMISE_TRACKER_ACTIVATION_DELAY
            }),
            this.error = "",
            i[0].body.classList.add("bg-black-opacity"),
            t.$on("destroy",
            function() {
                i[0].body.classList.remove("bg-black-opacity"),
                c.loadingTracker.cancel()
            })
        }
        return e.$inject = ["$scope", "promiseTracker", "axConstant", "$document", "$state", "gettextCatalog", "AccountApi"],
        babelHelpers.createClass(e, [{
            key: "onResetPassword",
            value: function() {
                function e() {
                    var e = this,
                    t = this.AccountApi,
                    n = (this.gettextCatalog, this.loadingTracker),
                    r = n.createPromise();
                    this.error = "",
                    t.resetPassword("", {
                        noPublishError: !0,
                        noAuthToken: !0
                    }).
                    catch(function(t) {
                        e.error = t.errorMessage || t.message
                    }).
                    finally(r.resolve)
                }
                return e
            } ()
        },
        {
            key: "onNavigateToLoginPage",
            value: function() {
                function e() {
                    this.$state.go("login", {},
                    {
                        inherit: !1
                    })
                }
                return e
            } ()
        }]),
        e
    } ();
    e.module("WVS").controller("axResetPasswordCtrl", t)
} (angular),
function(e) {
    "use strict";
    function t(e, t, n, r, i, a, o) {
        function s() {
            var t = e.loadingTracker.createPromise(),
            n = e.credentials,
            r = n.email,
            i = n.password,
            a = n.rememberMe;
            return o.signIn(r, i, a, {
                noAuthToken: !0,
                noLoginRedirect: !0,
                tracker: e.loadingTracker
            }).
            catch(function(t) {
                e.loginError = t.errorMessage
            }).
            finally(t.resolve)
        }
        function c() {
            t[0].body.classList.remove("bg-black-opacity"),
            e.loadingTracker.cancel()
        }
        function u(e, t) {
            t.errorCode === a.ERROR_CODES.AUTH_REQUIRED ? t.errorMessage = r("Email或密码无效") : 403 === t.status && t.data && t.data.code === a.SYI_ERROR_CODES.FEATURE_NOT_ALLOWED && (t.errorMessage = r("账号没有被激活"))
        }
        e.loadingTracker = i({
            activationDelay: a.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        e.loginError = "",
        e.credentials = {
            email: "",
            password: "",
            rememberMe: !1
        },
        e.signIn = s,
        e.$on("$destroy", c),
        e.$on("$destroy", n.$on("axApiError", u)),
        function() {
            n.documentTitle = r("Acunetix - 登录"),
            t[0].body.classList.add("bg-black-opacity")
        } ()
    }
    t.$inject = ["$scope", "$document", "$rootScope", "gettext", "promiseTracker", "axConstant", "AccountApi"],
    e.module("WVS").controller("axLoginCtrl", t)
} (angular),
function(e) {
    "use strict";
    var t = e.identity,
    n = {
        AV: {
            name: t("访问向量"),
            values: {
                L: {
                    name: t("本地"),
                    description: t("只有本地访问可利用的漏洞需要攻击者才能对易受攻击的系统或本地（shell）帐户进行物理访问。 本地可利用漏洞的示例是诸如Firewire / USB DMA攻击和本地特权升级（例如sudo）等外围攻击。")
                },
                A: {
                    name: t("局域网"),
                    description: t("可利用与相邻的网络接入的漏洞要求攻击者能够访问任一广播或脆弱软件的冲突域。 本地网络的示例包括本地IP子网，蓝牙，IEEE 802.11和本地以太网段。")
                },
                N: {
                    name: t("网络"),
                    description: t('可利用具有网络访问的漏洞意味着有漏洞的软件绑定到网络堆栈和攻击者不需要本地网络访问或本地访问。 这种脆弱性通常被称为“远程利用”。 网络攻击的一个例子是RPC缓冲区溢出。')
                }
            }
        },
        AC: {
            name: t("访问复杂性"),
            values: {
                H: {
                    name: t("高"),
                    description: t("存在专门的访问条件。 例如：<br> <ul> <li>在大多数配置中，除了攻击系统（例如，DNS劫持）之外，攻击方必须已经具有提升的权限或欺骗附加系统。</li> <li>攻击 取决于知识渊博的人很容易发现的社会工程方法。 例如，受害者必须执行几种可疑或非典型的操作。</li> <li>在实践中，很少出现易受攻击的配置。</li> <li>如果存在竞争条件，则窗口非常窄。</li></ul>")
                },
                M: {
                    name: t("中"),
                    description: t("访问条件有些专业化; 以下是示例：<br> <ul> <li>攻击方仅限于某些授权级别的系统或用户，可能不受信任。</li> <li>某些信息必须在成功之前收集 攻击可以启动。</li> <li>受影响的配置是非默认配置，不是普遍配置的（例如，当服务器通过特定方案执行用户帐户身份验证但不存在于另一个身份验证方案时，会出现一个漏洞 ）</li> <li>攻击需要少量的社会工程，偶尔会愚蠢的用户（例如，网络钓鱼攻击修改网络浏览器状态栏显示虚假链接，必须在某人的好友列表之前 发送IM漏洞利用）。</li> </ul>")
                },
                L: {
                    name: t("低"),
                    description: t("专业访问条件或减轻情节不存在。 以下是示例：<br> <ul> <li>受影响的产品通常需要访问广泛的系统和用户，可能是匿名的和不可信的（例如面向Internet的Web或邮件服务器）。</li> <li>受影响的配置是缺省或无处不在。</li> <li>攻击可以手动执行，并且需要很少的技能或额外的信息收集。</li> <li>争用条件是懒一个（即，它 在技术上是一个比赛，但容易胜算）。</li> </ul>")
                }
            }
        },
        Au: {
            name: t("身份验证"),
            values: {
                M: {
                    name: t("多"),
                    description: t("利用此漏洞需要攻击者验证两次或更多次，即使每次都使用相同的凭据。 一个例子是攻击者对操作系统进行身份验证，以及提供凭据以访问该系统上托管的应用程序。")
                },
                S: {
                    name: t("单一"),
                    description: t("该漏洞需要攻击者登录系统（例如在命令行或通过桌面会话或Web界面）。")
                },
                N: {
                    name: t("无"),
                    description: t("验证不需要利用此漏洞。")
                }
            }
        },
        C: {
            name: t("保密性影响"),
            values: {
                N: {
                    name: t("无"),
                    description: t("对系统的机密性没有影响。")
                },
                P: {
                    name: t("局部"),
                    description: t("有大量的信息披露。 访问某些系统文件是可能的，但是攻击并没有得到什么，或者损失的范围被限制在控制。 一个例子是在数据库中仅泄漏某些表中的漏洞。")
                },
                C: {
                    name: t("完整的"),
                    description: t("目前总的信息披露，导致所有的系统文件被泄露。 攻击者能够读取系统的所有数据（内存，文件等）.)")
                }
            }
        },
        I: {
            name: t("完整性影响"),
            values: {
                N: {
                    name: t("无"),
                    description: t("对系统的完整性没有影响。")
                },
                P: {
                    name: t("局部"),
                    description: t("某些系统文件或信息的修改是可能的，但是攻击者无法控制可以修改的内容，或者攻击者的影响范围有限。 例如，系统或应用程序文件可能会被覆盖或修改，但攻击者无法控制哪些文件受到影响，或者攻击者只能在有限的上下文或范围内修改文件。")
                },
                C: {
                    name: t("完整的"),
                    description: t("系统保护完全丧失，导致整个系统受到威胁。 攻击者能够修改目标系统上的任何文件。")
                }
            }
        },
        A: {
            name: t("可用性影响"),
            values: {
                N: {
                    name: t("无"),
                    description: t("对系统的可用性没有影响。")
                },
                P: {
                    name: t("局部"),
                    description: t("有一个在资源可用性性能降低或中断。 一个例子是一个基于网络的泛洪攻击，允许成功连接的数量有限的互联网服务。")
                },
                C: {
                    name: t("完整"),
                    description: t("有受影响资源的完全关闭。 攻击者可以使资源完全不可用。")
                }
            }
        },
        E: {
            name: t("可利用性"),
            values: {
                U: {
                    name: t("未经证实"),
                    description: t("没有攻击代码可用，或利用完全是理论上的。")
                },
                POC: {
                    name: t("验证型思想"),
                    description: t("概念验证漏洞代码或大多数系统不实用的攻击演示可用。 代码或技术在所有情况下都不起作用，并且可能需要熟练的攻击者的实质修改。")
                },
                F: {
                    name: t("实用"),
                    description: t("功能性攻击代码是可用的。 该代码适用于存在此漏洞的大多数情况。")
                },
                H: {
                    name: t("高"),
                    description: t("该漏洞是由功能移动自主代码利用的，或者不需要利用（手动触发），并且详细信息广泛可用。 代码工作在任何情况下，或正在积极通过移动自主代理交付（如蠕虫或病毒）。")
                },
                ND: {
                    name: t("未定义"),
                    description: t("将此值分配给指标不会影响分数。 这是一个信号，方程式跳过这个度量。")
                }
            }
        },
        RL: {
            name: t("修复程度"),
            values: {
                OF: {
                    name: t("官方修复"),
                    description: t("一个完整的供应商解决方案是可用的。 供应商已经发布了官方补丁，或者可以进行升级。")
                },
                TF: {
                    name: t("临时修复"),
                    description: t("有一个官方的，但临时的解决办法可用。 这包括其中的供应商发出的临时修补程序，工具，或解决方法。")
                },
                W: {
                    name: t("解决方法"),
                    description: t("有一个非官方的，非供应商的解决方案。 在某些情况下，受影响的技术的用户将创建自己的补丁或者提供步骤来解决或以其它方式减轻该漏洞。")
                },
                U: {
                    name: t("不可用"),
                    description: t("没有可用的解决方案或不可能应用。")
                },
                ND: {
                    name: t("未定义"),
                    description: t("将此值分配给指标不会影响分数。 这是一个信号，方程式跳过这个度量。")
                }
            }
        },
        RC: {
            name: t("Report Confidence"),
            values: {
                UC: {
                    name: t("Unconfirmed"),
                    description: t("There is a single unconfirmed source or possibly multiple conflicting reports. There is little confidence in the validity of the reports. An example is a rumor that surfaces from the hacker underground.")
                },
                UR: {
                    name: t("Uncorroborated"),
                    description: t("There are multiple non-official sources, possibly including independent security companies or research organizations. At this point there may be conflicting technical details or some other lingering ambiguity.")
                },
                C: {
                    name: t("Confirmed"),
                    description: t("The vulnerability has been acknowledged by the vendor or author of the affected technology. The vulnerability may also be Confirmed when its existence is confirmed from an external event such as publication of functional or proof-of-concept exploit code or widespread exploitation.")
                },
                ND: {
                    name: t("Not Defined"),
                    description: t("Assigning this value to the metric will not influence the score. It is a signal to the equation to skip this metric.")
                }
            }
        },
        CDP: {
            name: t("Collateral Damage Potential"),
            values: {
                N: {
                    name: t("None"),
                    description: t("There is no potential for loss of life, physical assets, productivity or revenue.")
                },
                L: {
                    name: t("Low"),
                    description: t("A successful exploit of this vulnerability may result in slight physical or property damage. Or, there may be a slight loss of revenue or productivity to the organization.")
                },
                LM: {
                    name: t("Low-Medium"),
                    description: t("A successful exploit of this vulnerability may result in moderate physical or property damage. Or, there may be a moderate loss of revenue or productivity to the organization.")
                },
                MH: {
                    name: t("Medium-High"),
                    description: t("A successful exploit of this vulnerability may result in significant physical or property damage or loss. Or, there may be a significant loss of revenue or productivity.")
                },
                H: {
                    name: t("High"),
                    description: t("A successful exploit of this vulnerability may result in catastrophic physical or property damage and loss. Or, there may be a catastrophic loss of revenue or productivity.")
                },
                ND: {
                    name: t("Not Defined"),
                    description: t("Assigning this value to the metric will not influence the score. It is a signal to the equation to skip this metric.")
                }
            }
        },
        TD: {
            name: t("Target Distribution"),
            values: {
                N: {
                    name: t("None"),
                    description: t("No target systems exist, or targets are so highly specialized that they only exist in a laboratory setting. Effectively 0% of the environment is at risk.")
                },
                L: {
                    name: t("Low"),
                    description: t("Targets exist inside the environment, but on a small scale. Between 1% - 25% of the total environment is at risk.")
                },
                M: {
                    name: t("Medium"),
                    description: t("Targets exist inside the environment, but on a medium scale. Between 26% - 75% of the total environment is at risk.")
                },
                H: {
                    name: t("High"),
                    description: t("Targets exist inside the environment on a considerable scale. Between 76% - 100% of the total environment is considered at risk.")
                },
                ND: {
                    name: t("Not Defined"),
                    description: t("Assigning this value to the metric will not influence the score. It is a signal to the equation to skip this metric.")
                }
            }
        },
        CR: {
            name: t("Confidentiality Requirement"),
            values: {
                L: {
                    name: t("Low"),
                    description: t("Loss of confidentiality is likely to have only a limited adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).")
                },
                M: {
                    name: t("Medium"),
                    description: t("Loss of confidentiality is likely to have a serious adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).")
                },
                H: {
                    name: t("High"),
                    description: t("Loss of confidentiality is likely to have a catastrophic adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).")
                },
                ND: {
                    name: t("Not Defined"),
                    description: t("Assigning this value to the metric will not influence the score. It is a signal to the equation to skip this metric.")
                }
            }
        },
        IR: {
            name: t("Integrity Requirement"),
            values: {
                L: {
                    name: t("Low"),
                    description: t("Loss of integrity is likely to have only a limited adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).")
                },
                M: {
                    name: t("Medium"),
                    description: t("Loss of integrity is likely to have a serious adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).")
                },
                H: {
                    name: t("High"),
                    description: t("Loss of integrity is likely to have a catastrophic adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).")
                },
                ND: {
                    name: t("Not Defined"),
                    description: t("Assigning this value to the metric will not influence the score. It is a signal to the equation to skip this metric.")
                }
            }
        },
        AR: {
            name: t("Availability Requirement"),
            values: {
                L: {
                    name: t("Low"),
                    description: t("Loss of availability is likely to have only a limited adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).")
                },
                M: {
                    name: t("Medium"),
                    description: t("Loss of availability is likely to have a serious adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).")
                },
                H: {
                    name: t("High"),
                    description: t("Loss of availability is likely to have a catastrophic adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).")
                },
                ND: {
                    name: t("Not Defined"),
                    description: t("Assigning this value to the metric will not influence the score. It is a signal to the equation to skip this metric.")
                }
            }
        }
    },
    r = {
        AV: {
            name: t("攻击向量"),
            values: {
                N: {
                    name: t("网络"),
                    description: t("可利用与网络接入的漏洞意味着易受攻击的组件被绑定到网络堆栈和攻击者的路径是通过OSI层3（网络层）。 这种脆弱性通常被称为“远程利用”，并且可以被认为是攻击被利用的一个或多个网络的跳之外。")
                },
                A: {
                    name: t("局域网"),
                    description: t("与相邻网络访问相关的漏洞意味着易受攻击的组件绑定到网络堆栈，但攻击仅限于相同的共享物理（如蓝牙，IEEE 802.11）或逻辑（例如本地IP子网）网络，无法执行 跨越OSI第3层边界（例如路由器）。")
                },
                L: {
                    name: t("本地"),
                    description: t("可利用本地访问的漏洞意味着易受攻击的组件不绑定到网络堆栈，攻击者的路径是通过读/写/执行功能。 在某些情况下，攻击者可能会在本地登录，以利用该漏洞，否则，她可能依赖用户交互来执行恶意文件。")
                },
                P: {
                    name: t("物理"),
                    description: t("利用物理访问可利用的漏洞需要攻击者亲自触摸或操纵易受攻击的组件。 物理互动可能是短暂的或持续的。")
                }
            }
        },
        AC: {
            name: t("攻击复杂性"),
            values: {
                L: {
                    name: t("低"),
                    description: t("专业访问条件或减轻情节不存在。 攻击者可以期待针对弱势组件的可重复的成功。")
                },
                H: {
                    name: t("高"),
                    description: t("成功的攻击取决于攻击者控制之外的条件。 也就是说，成功的攻击无法随意完成，但是要求攻击者在预期成功的攻击之前就投入大量的精力准备或执行易受攻击的组件。 例如，成功的攻击可能需要攻击者：执行目标特定的侦察; 准备目标环境，提高利用可靠性; 或者将自己注入到受害者请求的目标和资源之间的逻辑网络路径中，以便读取和/或修改网络通信（例如中间攻击中的人）。")
                }
            }
        },
        PR: {
            name: t("所需权限"),
            values: {
                N: {
                    name: t("无"),
                    description: t("攻击者在攻击之前是未经授权的，因此无需访问设置或文件进行攻击。")
                },
                L: {
                    name: t("低"),
                    description: t("攻击者被授权（即需要）提供基本用户功能的权限，这些权限通常只能影响用户拥有的设置和文件。 或者，具有低权限的攻击者可能只能对非敏感资源产生影响。")
                },
                H: {
                    name: t("高"),
                    description: t("攻击者被授权（即需要）特权，对可能影响组件范围设置和文件的易受攻击组件提供重要（例如管理）控制。")
                }
            }
        },
        UI: {
            name: t("用户交互"),
            values: {
                N: {
                    name: t("无"),
                    description: t("易受攻击的系统可以在没有任何用户的任何交互的情况下被利用。")
                },
                R: {
                    name: t("需要"),
                    description: t("成功利用此漏洞需要用户在漏洞利用之前采取一些行动。")
                }
            }
        },
        S: {
            name: t("范围"),
            values: {
                U: {
                    name: t("无变化"),
                    description: t("被利用的漏洞只能影响同一个权限管理的资源。 在这种情况下，易受攻击的组件和受影响的组件是相同的。")
                },
                C: {
                    name: t("发生变化"),
                    description: t("一个利用漏洞可以影响超出了易受攻击的组件旨在授权权限的资源。 在这种情况下，易受攻击的组件和受影响组件是不同的。")
                }
            }
        },
        C: {
            name: t("保密"),
            values: {
                N: {
                    name: t("无"),
                    description: t("受影响的组件中不存在机密性损失。")
                },
                L: {
                    name: t("低"),
                    description: t("有一些机密性的损失。 获得访问一些受限制的信息，但是攻击并没有什么获得的信息，或损失的金额或种类受到限制了控制。 信息披露不会对受影响的组件造成直接，严重的损失。")
                },
                H: {
                    name: t("高"),
                    description: t("完全丧失保密性，导致受影响的组件内的所有资源都泄露给攻击者。 或者，仅获得一些受限制的信息，但所公开的信息呈现直接的，严重的影响。")
                }
            }
        },
        I: {
            name: t("完整性"),
            values: {
                N: {
                    name: t("无"),
                    description: t("受影响的部分内没有完整性损失。")
                },
                L: {
                    name: t("低"),
                    description: t("数据的修改是可能的，但攻击者无法控制修改的后果，或修改的限制。 数据修改对受影响的组件没有直接，严重的影响。")
                },
                H: {
                    name: t("高"),
                    description: t("完全丧失完整性，或完全丧失保护。 例如，攻击者能够修改受受影响组件保护的任何/所有文件。 或者，只有一些文件可以被修改，但恶意修改会对受影响的组件造成直接，严重的后果。")
                }
            }
        },
        A: {
            name: t("可用性"),
            values: {
                N: {
                    name: t("无"),
                    description: t("受影响的组件中的可用性没有影响。")
                },
                L: {
                    name: t("低"),
                    description: t("资源可用性降低了性能或中断。 即使可以重复利用该漏洞，攻击者也无法完全拒绝对合法用户的服务。 在受影响组件的资源或者部分可用的所有的时间，或仅在某个时间完全可用，但总体上没有直接的，严重的后果受影响组件。")
                },
                H: {
                    name: t("高"),
                    description: t("可用性完全丧失，导致攻击者能够完全拒绝访问受影响组件中的资源; 这种损失是持续的（而攻击者继续提供攻击）或持续的（即使攻击完成后，状况仍然存在）。 另外，攻击者有权拒绝一些可用性的能力，但可用性的损失提出了一个直接的，严重的后果受影响组件（例如，攻击者不能破坏现有的连接，但是可以防止新的连接，攻击者可以反复利用漏洞 即，在成功攻击的每个实例，泄漏的内存只有少量的，但二次开发后使服务变得完全不可用）。")
                }
            }
        },
        E: {
            name: t("Exploit Code Maturity"),
            values: {
                X: {
                    name: t("Not Defined"),
                    description: t("Assigning this value to the metric will not influence the score.")
                },
                U: {
                    name: t("Unproven"),
                    description: t("No exploit code is available, or an exploit is theoretical.")
                },
                P: {
                    name: t("Proof-of-Concept"),
                    description: t("Proof-of-concept exploit code is available, or an attack demonstration is not practical for most systems. The code or technique is not functional in all situations and may require substantial modification by a skilled attacker.")
                },
                F: {
                    name: t("Functional"),
                    description: t("Functional exploit code is available. The code works in most situations where the vulnerability exists.")
                },
                H: {
                    name: t("High"),
                    description: t("Functional autonomous code exists, or no exploit is required (manual trigger) and details are widely available. Exploit code works in every situation, or is actively being delivered via an autonomous agent (such as a worm or virus). Network-connected systems are likely to encounter scanning or exploitation attempts. Exploit development has reached the level of reliable, widely-available, easy-to-use automated tools.")
                }
            }
        },
        RL: {
            name: t("Remediation Level"),
            values: {
                X: {
                    name: t("Not Defined"),
                    description: t("Assigning this value to the metric will not influence the score.")
                },
                O: {
                    name: t("Official Fix"),
                    description: t("A complete vendor solution is available. Either the vendor has issued an official patch, or an upgrade is available.")
                },
                T: {
                    name: t("Temporary Fix"),
                    description: t("There is an official but temporary fix available. This includes instances where the vendor issues a temporary hotfix, tool, or workaround.")
                },
                W: {
                    name: t("Workaround"),
                    description: t("There is an unofficial, non-vendor solution available. In some cases, users of the affected technology will create a patch of their own or provide steps to work around or otherwise mitigate the vulnerability.")
                },
                U: {
                    name: t("Unavailable"),
                    description: t("There is either no solution available or it is impossible to apply.")
                }
            }
        },
        RC: {
            name: t("Report Confidence"),
            values: {
                X: {
                    name: t("Not Defined"),
                    description: t("Assigning this value to the metric will not influence the score.")
                },
                U: {
                    name: t("Unknown"),
                    description: t("There are reports of impacts that indicate a vulnerability is present. The reports indicate that the cause of the vulnerability is unknown, or reports may differ on the cause or impacts of the vulnerability. Reporters are uncertain of the true nature of the vulnerability, and there is little confidence in the validity of the reports or whether a static Base score can be applied given the differences described. An example is a bug report which notes that an intermittent but non-reproducible crash occurs, with evidence of memory corruption suggesting that denial of service, or possible more serious impacts, may result.")
                },
                R: {
                    name: t("Reasonable"),
                    description: t("Significant details are published, but researchers either do not have full confidence in the root cause, or do not have access to source code to fully confirm all of the interactions that may lead to the result. Reasonable confidence exists, however, that the bug is reproducible and at least one impact is able to be verified (Proof-of-concept exploits may provide this). An example is a detailed write-up of research into a vulnerability with an explanation (possibly obfuscated or ’left as an exercise to the reader’) that gives assurances on how to reproduce the results.")
                },
                C: {
                    name: t("Confirmed"),
                    description: t("Detailed reports exist, or functional reproduction is possible (functional exploits may provide this). Source code is available to independently verify the assertions of the research, or the author or vendor of the affected code has confirmed the presence of the vulnerability.")
                }
            }
        },
        CR: {
            name: t("Confidentiality Requirement"),
            values: {
                X: {
                    name: t("Not Defined"),
                    description: t("Assigning this value to the metric will not influence the score.")
                },
                L: {
                    name: t("Low"),
                    description: t("Loss of Confidentiality is likely to have only a limited adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).")
                },
                M: {
                    name: t("Medium"),
                    description: t("Assigning this value to the metric will not influence the score.")
                },
                H: {
                    name: t("High"),
                    description: t("Loss of Confidentiality is likely to have a catastrophic adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).")
                }
            }
        },
        IR: {
            name: t("Integrity Requirement"),
            values: {
                X: {
                    name: t("Not Defined"),
                    description: t("Assigning this value to the metric will not influence the score.")
                },
                L: {
                    name: t("Low"),
                    description: t("Loss of Integrity is likely to have only a limited adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).")
                },
                M: {
                    name: t("Medium"),
                    description: t("Assigning this value to the metric will not influence the score.")
                },
                H: {
                    name: t("High"),
                    description: t("Loss of Integrity is likely to have a catastrophic adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).")
                }
            }
        },
        AR: {
            name: t("Availability Requirement"),
            values: {
                X: {
                    name: t("Not Defined"),
                    description: t("Assigning this value to the metric will not influence the score.")
                },
                L: {
                    name: t("Low"),
                    description: t("Loss of Availability is likely to have only a limited adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).")
                },
                M: {
                    name: t("Medium"),
                    description: t("Assigning this value to the metric will not influence the score.")
                },
                H: {
                    name: t("High"),
                    description: t("Loss of Availability is likely to have a catastrophic adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).")
                }
            }
        },
        MAV: {
            name: t("Modified Attack Vector"),
            values: {
                X: {
                    name: t("未定义"),
                    description: t("使用分配给相应基准分数指标的值")
                },
                N: {
                    name: t("网络"),
                    description: t("利用网络访问漏洞的漏洞意味着易受攻击的组件绑定到网络堆栈，攻击者的路径通过OSI第3层（网络层），这种漏洞通常被称为”可远程利用“，可以被认为作为攻击被利用的一个或多个网络跳。")
                },
                A: {
                    name: t("相邻网络"),
                    description: t("相邻网络访问可利用的漏洞意味着易受攻击的组件绑定到网络堆栈，但是攻击仅限于相同的共享物理（例如蓝牙，IEEE 802.11）或逻辑（例如本地IP子网）网络，并且不能在OSI第3层边界（例如路由器）上执行。")
                },
                L: {
                    name: t("本地"),
                    description: t("可利用本地访问的漏洞意味着易受攻击的组件不绑定到网络堆栈，攻击者的路径是通过读/写/执行功能，在某些情况下，攻击者可能会按照本地登录以利用此漏洞，否则，她可能依赖用户交互来执行恶意文件。")
                },
                P: {
                    name: t("物理"),
                    description: t("利用物理访问可利用的漏洞需要攻击者实际触摸或操纵易受攻击的组件，物理交互可能很短暂或持续。")
                }
            }
        },
        MAC: {
            name: t("Modified Attack Complexity"),
            values: {
                X: {
                    name: t("Not Defined"),
                    description: t("Use the value assigned to the corresponding Base Score metric.")
                },
                L: {
                    name: t("Low"),
                    description: t("Specialized access conditions or extenuating circumstances do not exist. An attacker can expect repeatable success against the vulnerable component.")
                },
                H: {
                    name: t("High"),
                    description: t("A successful attack depends on conditions beyond the attacker’s control. That is, a successful attack cannot be accomplished at will, but requires the attacker to invest in some measurable amount of effort in preparation or execution against the vulnerable component before a successful attack can be expected. For example, a successful attack may require the attacker: to perform target-specific reconnaissance; to prepare the target environment to improve exploit reliability; or to inject herself into the logical network path between the target and the resource requested by the victim in order to read and/or modify network communications (e.g. a man in the middle attack).")
                }
            }
        },
        MPR: {
            name: t("Modified Privileges Required"),
            values: {
                X: {
                    name: t("Not Defined"),
                    description: t("Use the value assigned to the corresponding Base Score metric.")
                },
                N: {
                    name: t("None"),
                    description: t("The attacker is unauthorized prior to attack, and therefore does not require any access to settings or files to carry out an attack.")
                },
                L: {
                    name: t("Low"),
                    description: t("The attacker is authorized with (i.e. requires) privileges that provide basic user capabilities that could normally affect only settings and files owned by a user. Alternatively, an attacker with Low privileges may have the ability to cause an impact only to non-sensitive resources.")
                },
                H: {
                    name: t("High"),
                    description: t("The attacker is authorized with (i.e. requires) privileges that provide significant (e.g. administrative) control over the vulnerable component that could affect component-wide settings and files.")
                }
            }
        },
        MUI: {
            name: t("Modified User Interaction"),
            values: {
                X: {
                    name: t("Not Defined"),
                    description: t("Use the value assigned to the corresponding Base Score metric.")
                },
                N: {
                    name: t("None"),
                    description: t("The vulnerable system can be exploited without any interaction from any user.")
                },
                R: {
                    name: t("Required"),
                    description: t("Successful exploitation of this vulnerability requires a user to take some action before the vulnerability can be exploited.")
                }
            }
        },
        MS: {
            name: t("Modified Scope"),
            values: {
                X: {
                    name: t("Not Defined"),
                    description: t("Use the value assigned to the corresponding Base Score metric.")
                },
                U: {
                    name: t("Unchanged"),
                    description: t("An exploited vulnerability can only affect resources managed by the same authority. In this case the vulnerable component and the impacted component are the same.")
                },
                C: {
                    name: t("Changed"),
                    description: t("An exploited vulnerability can affect resources beyond the authorization privileges intended by the vulnerable component. In this case the vulnerable component and the impacted component are different.")
                }
            }
        },
        MC: {
            name: t("Modified Confidentiality"),
            values: {
                X: {
                    name: t("Not Defined"),
                    description: t("Use the value assigned to the corresponding Base Score metric.")
                },
                N: {
                    name: t("None"),
                    description: t("There is no loss of confidentiality within the impacted component.")
                },
                L: {
                    name: t("Low"),
                    description: t("There is some loss of confidentiality. Access to some restricted information is obtained, but the attacker does not have control over what information is obtained, or the amount or kind of loss is constrained. The information disclosure does not cause a direct, serious loss to the impacted component.")
                },
                H: {
                    name: t("High"),
                    description: t("There is total loss of confidentiality, resulting in all resources within the impacted component being divulged to the attacker. Alternatively, access to only some restricted information is obtained, but the disclosed information presents a direct, serious impact.")
                }
            }
        },
        MI: {
            name: t("Modified Integrity"),
            values: {
                X: {
                    name: t("Not Defined"),
                    description: t("Use the value assigned to the corresponding Base Score metric.")
                },
                N: {
                    name: t("None"),
                    description: t("There is no loss of integrity within the impacted component.")
                },
                L: {
                    name: t("Low"),
                    description: t("Modification of data is possible, but the attacker does not have control over the consequence of a modification, or the amount of modification is constrained. The data modification does not have a direct, serious impact on the impacted component.")
                },
                H: {
                    name: t("High"),
                    description: t("There is a total loss of integrity, or a complete loss of protection. For example, the attacker is able to modify any/all files protected by the impacted component. Alternatively, only some files can be modified, but malicious modification would present a direct, serious consequence to the impacted component.")
                }
            }
        },
        MA: {
            name: t("Modified Availability"),
            values: {
                X: {
                    name: t("Not Defined"),
                    description: t("Use the value assigned to the corresponding Base Score metric.")
                },
                N: {
                    name: t("None"),
                    description: t("There is no impact to availability within the impacted component.")
                },
                L: {
                    name: t("Low"),
                    description: t("There is reduced performance or interruptions in resource availability. Even if repeated exploitation of the vulnerability is possible, the attacker does not have the ability to completely deny service to legitimate users. The resources in the impacted component are either partially available all of the time, or fully available only some of the time, but overall there is no direct, serious consequence to the impacted component.")
                },
                H: {
                    name: t("High"),
                    description: t("There is total loss of availability, resulting in the attacker being able to fully deny access to resources in the impacted component; this loss is either sustained (while the attacker continues to deliver the attack) or persistent (the condition persists even after the attack has completed). Alternatively, the attacker has the ability to deny some availability, but the loss of availability presents a direct, serious consequence to the impacted component (e.g., the attacker cannot disrupt existing connections, but can prevent new connections; the attacker can repeatedly exploit a vulnerability that, in each instance of a successful attack, leaks a only small amount of memory, but after repeated exploitation causes a service to become completely unavailable).")
                }
            }
        }
    },
    i = {
        2 : n,
        3 : r
    },
    a = {
        2 : "https://nvd.nist.gov/cvss.cfm?version=2&vector=",
        3 : "https://www.first.org/cvss/calculator/3.0#"
    },
    o = /^CVSS:3\.0\//,
    s = new RegExp("(?:CVE-\\d{4}-\\d+)", "g"),
    c = new RegExp("(CWE-\\d+)", "g"),
    u = function() {
        function e() {
            babelHelpers.classCallCheck(this, e)
        }
        return babelHelpers.createClass(e, [{
            key: "extractCVE",
            value: function() {
                function e(e) {
                    var t = [];
                    if (e) for (var n; n = s.exec(e);) t.push(n[0].substr(4));
                    return t
                }
                return e
            } ()
        },
        {
            key: "extractCWE",
            value: function() {
                function e(e) {
                    var t = [];
                    if (e) for (var n; n = c.exec(e);) t.push(n[0].substr(4));
                    return t
                }
                return e
            } ()
        },
        {
            key: "detectCVSSVersion",
            value: function() {
                function e(e) {
                    return o.test(e) ? "3": "2"
                }
                return e
            } ()
        },
        {
            key: "getCVSSMetrics",
            value: function() {
                function e(e, t) {
                    var n = t && String(t) ? t: this.detectCVSSVersion(e);
                    return "3" === n && (e = e.substr(9)),
                    e.split("/").map(function(e) {
                        var t = e.split(":"),
                        r = i[n][t[0]];
                        return {
                            metricName: r.name,
                            valueName: r.values[t[1]].name,
                            description: r.values[t[1]].description
                        }
                    })
                }
                return e
            } ()
        },
        {
            key: "getCVSSLink",
            value: function() {
                function e(e, t) {
                    var n = t && String(t) ? t: this.detectCVSSVersion(e);
                    return "" + String(a[n]) + String(e)
                }
                return e
            } ()
        }]),
        e
    } ();
    e.module("WVS").service("axVulnClassification", u)
} (angular),
function(e) {
    "use strict";
    var t = function() {
        function e(t, n) {
            babelHelpers.classCallCheck(this, e),
            this.localStorageService = t,
            this.CurrentUser = n
        }
        return e.$inject = ["localStorageService", "CurrentUser"],
        babelHelpers.createClass(e, [{
            key: "set",
            value: function() {
                function e(e, t) {
                    var n = this.CurrentUser.get("userId");
                    return !! n && (this.localStorageService.set(String(n) + "." + String(e), t), !0)
                }
                return e
            } ()
        },
        {
            key: "get",
            value: function() {
                function e(e) {
                    var t = this.CurrentUser.get("userId");
                    return t ? this.localStorageService.get(String(t) + "." + String(e)) : null
                }
                return e
            } ()
        },
        {
            key: "remove",
            value: function() {
                function e(e) {
                    var t = this.CurrentUser.get("userId");
                    t && this.localStorageService.remove(String(t) + "." + String(e))
                }
                return e
            } ()
        }]),
        e
    } ();
    e.module("WVS").service("axUserPreferences", t)
} (angular),
function(e) {
    "use strict";
    var t = function() {
        function t(e) {
            babelHelpers.classCallCheck(this, t),
            this.$stateParams = e
        }
        return t.$inject = ["$stateParams"],
        babelHelpers.createClass(t, [{
            key: "getStateParam",
            value: function() {
                function t(t) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                    r = arguments[2],
                    i = this.$stateParams;
                    if (e.isString(t)) {
                        var a = i.hasOwnProperty(t) && i[t] ? String(i[t]).trim() : null;
                        if (!a) return n ? [] : null;
                        var o = a;
                        return n ? (o = a.split(",").filter(function(e) {
                            return e.length > 0
                        }), e.isArray(r) ? o = o.filter(function(e) {
                            return r.indexOf(e) > -1
                        }) : e.isFunction(r) && (o = o.filter(r))) : e.isArray(r) && r.indexOf(o) < 0 ? o = null: e.isFunction(r) && (o = r(o) ? o: null),
                        o
                    }
                    return null
                }
                return t
            } ()
        }]),
        t
    } ();
    e.module("WVS").service("axStateHelpers", t)
} (angular),
function(e) {
    "use strict";
    function t(e) {
        var t = this;
        this.currentUrl = function() {
            return e.url()
        },
        this.currentUrlEncoded = function() {
            return encodeURIComponent(t.currentUrl())
        }
    }
    t.$inject = ["$location"],
    e.module("WVS").service("axPage", t)
} (angular),
function(e) {
    "use strict";
    var t = function() {
        function e(t, n, r, i) {
            babelHelpers.classCallCheck(this, e),
            this.$q = t,
            this.gettextCatalog = n,
            this.localStorageService = r,
            this.axConstant = i
        }
        return e.$inject = ["$q", "gettextCatalog", "localStorageService", "axConstant"],
        babelHelpers.createClass(e, [{
            key: "init",
            value: function() {
                function e() {
                    var e = this.axConstant,
                    t = this.localStorageService,
                    n = t.get("locale");
                    this.changeLanguage(n || e.DEFAULT_UI_LANGUAGE)
                }
                return e
            } ()
        },
        {
            key: "changeLanguage",
            value: function() {
                function e(e) {
                    var t = this.axConstant,
                    n = this.$q,
                    r = this.gettextCatalog,
                    i = this.localStorageService;
                    return e === t.DEFAULT_UI_LANGUAGE ? (i.remove("locale"), r.setCurrentLanguage(e), n.when()) : (i.set("locale", e), r.loadRemote("/locales/" + e + ".json").then(function() {
                        r.setCurrentLanguage(e)
                    }))
                }
                return e
            } ()
        }]),
        e
    } ();
    e.module("WVS").service("axLocale", t)
} (angular),
function(e) {
    "use strict";
    var t = e.identity,
    n = [{
        code: "AF",
        name: t("Afghanistan")
    },
    {
        code: "AX",
        name: t("Åland Islands")
    },
    {
        code: "AL",
        name: t("Albania")
    },
    {
        code: "DZ",
        name: t("Algeria")
    },
    {
        code: "AS",
        name: t("American Samoa")
    },
    {
        code: "AD",
        name: t("Andorra")
    },
    {
        code: "AO",
        name: t("Angola")
    },
    {
        code: "AI",
        name: t("Anguilla")
    },
    {
        code: "AQ",
        name: t("Antarctica")
    },
    {
        code: "AG",
        name: t("Antigua and Barbuda")
    },
    {
        code: "AR",
        name: t("Argentina")
    },
    {
        code: "AM",
        name: t("Armenia")
    },
    {
        code: "AW",
        name: t("Aruba")
    },
    {
        deprecated: !0,
        code: "AC",
        name: t("Ascension Island")
    },
    {
        code: "AU",
        name: t("Australia")
    },
    {
        inEU: !0,
        code: "AT",
        name: t("Austria")
    },
    {
        code: "AZ",
        name: t("Azerbaijan")
    },
    {
        code: "BS",
        name: t("Bahamas")
    },
    {
        code: "BH",
        name: t("Bahrain")
    },
    {
        code: "BD",
        name: t("Bangladesh")
    },
    {
        code: "BB",
        name: t("Barbados")
    },
    {
        code: "BY",
        name: t("Belarus")
    },
    {
        inEU: !0,
        code: "BE",
        name: t("Belgium")
    },
    {
        code: "BZ",
        name: t("Belize")
    },
    {
        code: "BJ",
        name: t("Benin")
    },
    {
        code: "BM",
        name: t("Bermuda")
    },
    {
        code: "BT",
        name: t("Bhutan")
    },
    {
        code: "BO",
        name: t("Bolivia")
    },
    {
        code: "BQ",
        name: t("Bonaire")
    },
    {
        code: "BA",
        name: t("Bosnia and Herzegovina")
    },
    {
        code: "BW",
        name: t("Botswana")
    },
    {
        code: "BV",
        name: t("Bouvet Island")
    },
    {
        code: "BR",
        name: t("Brazil")
    },
    {
        code: "IO",
        name: t("British Indian Ocean Territory")
    },
    {
        code: "BN",
        name: t("Brunei")
    },
    {
        inEU: !0,
        code: "BG",
        name: t("Bulgaria")
    },
    {
        code: "BF",
        name: t("Burkina Faso")
    },
    {
        code: "BI",
        name: t("Burundi")
    },
    {
        code: "CV",
        name: t("Cabo Verde")
    },
    {
        code: "KH",
        name: t("Cambodia")
    },
    {
        code: "CM",
        name: t("Cameroon")
    },
    {
        code: "CA",
        name: t("Canada")
    },
    {
        code: "KY",
        name: t("Cayman Islands")
    },
    {
        code: "CF",
        name: t("Central African Republic")
    },
    {
        code: "TD",
        name: t("Chad")
    },
    {
        code: "CL",
        name: t("Chile")
    },
    {
        code: "CN",
        name: t("China")
    },
    {
        code: "CX",
        name: t("Christmas Island")
    },
    {
        code: "CC",
        name: t("Cocos (Keeling) Islands")
    },
    {
        code: "CO",
        name: t("Colombia")
    },
    {
        code: "KM",
        name: t("Comoros")
    },
    {
        code: "CG",
        name: t("Congo")
    },
    {
        code: "CD",
        name: t("Congo (DRC)")
    },
    {
        code: "CK",
        name: t("Cook Islands")
    },
    {
        code: "CR",
        name: t("Costa Rica")
    },
    {
        code: "HR",
        name: t("Croatia")
    },
    {
        code: "CU",
        name: t("Cuba")
    },
    {
        code: "CW",
        name: t("Curaçao")
    },
    {
        inEU: !0,
        code: "CY",
        name: t("Cyprus")
    },
    {
        inEU: !0,
        code: "CZ",
        name: t("Czech Republic")
    },
    {
        inEU: !0,
        code: "DK",
        name: t("Denmark")
    },
    {
        code: "DJ",
        name: t("Djibouti")
    },
    {
        code: "DM",
        name: t("Dominica")
    },
    {
        code: "DO",
        name: t("Dominican Republic")
    },
    {
        code: "EC",
        name: t("Ecuador")
    },
    {
        code: "EG",
        name: t("Egypt")
    },
    {
        code: "SV",
        name: t("El Salvador")
    },
    {
        code: "GQ",
        name: t("Equatorial Guinea")
    },
    {
        code: "ER",
        name: t("Eritrea")
    },
    {
        inEU: !0,
        code: "EE",
        name: t("Estonia")
    },
    {
        code: "ET",
        name: t("Ethiopia")
    },
    {
        code: "FK",
        name: t("Falkland Islands")
    },
    {
        code: "FO",
        name: t("Faroe Islands")
    },
    {
        code: "FJ",
        name: t("Fiji Islands")
    },
    {
        inEU: !0,
        code: "FI",
        name: t("Finland")
    },
    {
        inEU: !0,
        code: "FR",
        name: t("France")
    },
    {
        code: "GF",
        name: t("French Guiana")
    },
    {
        code: "PF",
        name: t("French Polynesia")
    },
    {
        code: "TF",
        name: t("French Southern and Antarctic Lands")
    },
    {
        code: "GA",
        name: t("Gabon")
    },
    {
        code: "GM",
        name: t("Gambia, The")
    },
    {
        code: "GE",
        name: t("Georgia")
    },
    {
        inEU: !0,
        code: "DE",
        name: t("Germany")
    },
    {
        code: "GH",
        name: t("Ghana")
    },
    {
        code: "GI",
        name: t("Gibraltar")
    },
    {
        inEU: !0,
        code: "GR",
        name: t("Greece")
    },
    {
        code: "GL",
        name: t("Greenland")
    },
    {
        code: "GD",
        name: t("Grenada")
    },
    {
        code: "GP",
        name: t("Guadeloupe")
    },
    {
        code: "GU",
        name: t("Guam")
    },
    {
        code: "GT",
        name: t("Guatemala")
    },
    {
        code: "GG",
        name: t("Guernsey")
    },
    {
        code: "GN",
        name: t("Guinea")
    },
    {
        code: "GW",
        name: t("Guinea-Bissau")
    },
    {
        code: "GY",
        name: t("Guyana")
    },
    {
        code: "HT",
        name: t("Haiti")
    },
    {
        code: "HM",
        name: t("Heard Island and McDonald Islands")
    },
    {
        code: "VA",
        name: t("Holy See (Vatican City)")
    },
    {
        code: "HN",
        name: t("Honduras")
    },
    {
        code: "HK",
        name: t("Hong Kong SAR")
    },
    {
        inEU: !0,
        code: "HU",
        name: t("Hungary")
    },
    {
        code: "IS",
        name: t("Iceland")
    },
    {
        code: "IN",
        name: t("India")
    },
    {
        code: "ID",
        name: t("Indonesia")
    },
    {
        code: "IR",
        name: t("Iran")
    },
    {
        code: "IQ",
        name: t("Iraq")
    },
    {
        inEU: !0,
        code: "IE",
        name: t("Ireland")
    },
    {
        code: "IM",
        name: t("Isle of Man")
    },
    {
        code: "IL",
        name: t("Israel")
    },
    {
        inEU: !0,
        code: "IT",
        name: t("Italy")
    },
    {
        code: "JM",
        name: t("Jamaica")
    },
    {
        code: "SJ",
        name: t("Jan Mayen")
    },
    {
        code: "JP",
        name: t("Japan")
    },
    {
        code: "JE",
        name: t("Jersey")
    },
    {
        code: "JO",
        name: t("Jordan")
    },
    {
        code: "KZ",
        name: t("Kazakhstan")
    },
    {
        code: "KE",
        name: t("Kenya")
    },
    {
        code: "KI",
        name: t("Kiribati")
    },
    {
        code: "KR",
        name: t("Korea")
    },
    {
        code: "XK",
        name: t("Kosovo")
    },
    {
        code: "KW",
        name: t("Kuwait")
    },
    {
        code: "KG",
        name: t("Kyrgyzstan")
    },
    {
        code: "LA",
        name: t("Laos")
    },
    {
        inEU: !0,
        code: "LV",
        name: t("Latvia")
    },
    {
        code: "LB",
        name: t("Lebanon")
    },
    {
        code: "LS",
        name: t("Lesotho")
    },
    {
        code: "LR",
        name: t("Liberia")
    },
    {
        code: "LY",
        name: t("Libya")
    },
    {
        code: "LI",
        name: t("Liechtenstein")
    },
    {
        inEU: !0,
        code: "LT",
        name: t("Lithuania")
    },
    {
        inEU: !0,
        code: "LU",
        name: t("Luxembourg")
    },
    {
        code: "MO",
        name: t("Macao SAR")
    },
    {
        code: "MK",
        name: t("Macedonia, Former Yugoslav Republic of")
    },
    {
        code: "MG",
        name: t("Madagascar")
    },
    {
        code: "MW",
        name: t("Malawi")
    },
    {
        code: "MY",
        name: t("Malaysia")
    },
    {
        code: "MV",
        name: t("Maldives")
    },
    {
        code: "ML",
        name: t("Mali")
    },
    {
        inEU: !0,
        code: "MT",
        name: t("Malta")
    },
    {
        code: "MH",
        name: t("Marshall Islands")
    },
    {
        code: "MQ",
        name: t("Martinique")
    },
    {
        code: "MR",
        name: t("Mauritania")
    },
    {
        code: "MU",
        name: t("Mauritius")
    },
    {
        code: "YT",
        name: t("Mayotte")
    },
    {
        code: "MX",
        name: t("Mexico")
    },
    {
        code: "FM",
        name: t("Micronesia")
    },
    {
        code: "MD",
        name: t("Moldova")
    },
    {
        code: "MC",
        name: t("Monaco")
    },
    {
        code: "MN",
        name: t("Mongolia")
    },
    {
        code: "ME",
        name: t("Montenegro")
    },
    {
        code: "MS",
        name: t("Montserrat")
    },
    {
        code: "MA",
        name: t("Morocco")
    },
    {
        code: "MZ",
        name: t("Mozambique")
    },
    {
        code: "MM",
        name: t("Myanmar")
    },
    {
        code: "NA",
        name: t("Namibia")
    },
    {
        code: "NR",
        name: t("Nauru")
    },
    {
        code: "NP",
        name: t("Nepal")
    },
    {
        inEU: !0,
        code: "NL",
        name: t("Netherlands")
    },
    {
        deprecated: !0,
        code: "AN",
        name: t("Netherlands Antilles (Former)")
    },
    {
        code: "NC",
        name: t("New Caledonia")
    },
    {
        code: "NZ",
        name: t("New Zealand")
    },
    {
        code: "NI",
        name: t("Nicaragua")
    },
    {
        code: "NE",
        name: t("Niger")
    },
    {
        code: "NG",
        name: t("Nigeria")
    },
    {
        code: "NU",
        name: t("Niue")
    },
    {
        code: "NF",
        name: t("Norfolk Island")
    },
    {
        code: "KP",
        name: t("North Korea")
    },
    {
        code: "MP",
        name: t("Northern Mariana Islands")
    },
    {
        code: "NO",
        name: t("Norway")
    },
    {
        code: "OM",
        name: t("Oman")
    },
    {
        code: "PK",
        name: t("Pakistan")
    },
    {
        code: "PW",
        name: t("Palau")
    },
    {
        code: "PS",
        name: t("Palestinian Authority")
    },
    {
        code: "PA",
        name: t("Panama")
    },
    {
        code: "PG",
        name: t("Papua New Guinea")
    },
    {
        code: "PY",
        name: t("Paraguay")
    },
    {
        code: "PE",
        name: t("Peru")
    },
    {
        code: "PH",
        name: t("Philippines")
    },
    {
        code: "PN",
        name: t("Pitcairn Islands")
    },
    {
        inEU: !0,
        code: "PL",
        name: t("Poland")
    },
    {
        inEU: !0,
        code: "PT",
        name: t("Portugal")
    },
    {
        code: "PR",
        name: t("Puerto Rico")
    },
    {
        code: "QA",
        name: t("Qatar")
    },
    {
        code: "CI",
        name: t("Republic of Côte d'Ivoire")
    },
    {
        code: "RE",
        name: t("Reunion")
    },
    {
        inEU: !0,
        code: "RO",
        name: t("Romania")
    },
    {
        code: "RU",
        name: t("Russia")
    },
    {
        code: "RW",
        name: t("Rwanda")
    },
    {
        code: "XS",
        name: t("Saba")
    },
    {
        code: "SH",
        name: t("Saint Helena, Ascension and Tristan da Cunha")
    },
    {
        code: "WS",
        name: t("Samoa")
    },
    {
        code: "SM",
        name: t("San Marino")
    },
    {
        code: "ST",
        name: t("São Tomé and Príncipe")
    },
    {
        code: "SA",
        name: t("Saudi Arabia")
    },
    {
        code: "SN",
        name: t("Senegal")
    },
    {
        code: "RS",
        name: t("Serbia")
    },
    {
        deprecated: !0,
        code: "YU",
        name: t("Serbia, Montenegro")
    },
    {
        code: "SC",
        name: t("Seychelles")
    },
    {
        code: "SL",
        name: t("Sierra Leone")
    },
    {
        code: "SG",
        name: t("Singapore")
    },
    {
        code: "XE",
        name: t("Sint Eustatius")
    },
    {
        code: "SX",
        name: t("Sint Maarten")
    },
    {
        inEU: !0,
        code: "SK",
        name: t("Slovakia")
    },
    {
        inEU: !0,
        code: "SI",
        name: t("Slovenia")
    },
    {
        code: "SB",
        name: t("Solomon Islands")
    },
    {
        code: "SO",
        name: t("Somalia")
    },
    {
        code: "ZA",
        name: t("South Africa")
    },
    {
        code: "GS",
        name: t("South Georgia and the South Sandwich Islands")
    },
    {
        inEU: !0,
        code: "ES",
        name: t("Spain")
    },
    {
        code: "LK",
        name: t("Sri Lanka")
    },
    {
        code: "BL",
        name: t("St. Barthélemy")
    },
    {
        code: "KN",
        name: t("St. Kitts and Nevis")
    },
    {
        code: "LC",
        name: t("St. Lucia")
    },
    {
        code: "MF",
        name: t("St. Martin")
    },
    {
        code: "PM",
        name: t("St. Pierre and Miquelon")
    },
    {
        code: "VC",
        name: t("St. Vincent and the Grenadines")
    },
    {
        code: "SD",
        name: t("Sudan")
    },
    {
        code: "SR",
        name: t("Suriname")
    },
    {
        code: "SZ",
        name: t("Swaziland")
    },
    {
        inEU: !0,
        code: "SE",
        name: t("Sweden")
    },
    {
        code: "CH",
        name: t("Switzerland")
    },
    {
        code: "SY",
        name: t("Syria")
    },
    {
        code: "TW",
        name: t("Taiwan")
    },
    {
        code: "TJ",
        name: t("Tajikistan")
    },
    {
        code: "TZ",
        name: t("Tanzania")
    },
    {
        code: "TH",
        name: t("Thailand")
    },
    {
        code: "TL",
        name: t("Timor-Leste")
    },
    {
        deprecated: !0,
        code: "TP",
        name: t("Timor-Leste (East Timor)")
    },
    {
        code: "TG",
        name: t("Togo")
    },
    {
        code: "TK",
        name: t("Tokelau")
    },
    {
        code: "TO",
        name: t("Tonga")
    },
    {
        code: "TT",
        name: t("Trinidad and Tobago")
    },
    {
        deprecated: !0,
        code: "TA",
        name: t("Tristan da Cunha")
    },
    {
        code: "TN",
        name: t("Tunisia")
    },
    {
        code: "TR",
        name: t("Turkey")
    },
    {
        code: "TM",
        name: t("Turkmenistan")
    },
    {
        code: "TC",
        name: t("Turks and Caicos Islands")
    },
    {
        code: "TV",
        name: t("Tuvalu")
    },
    {
        code: "UG",
        name: t("Uganda")
    },
    {
        code: "UA",
        name: t("Ukraine")
    },
    {
        code: "AE",
        name: t("United Arab Emirates")
    },
    {
        inEU: !0,
        code: "UK",
        name: t("United Kingdom")
    },
    {
        code: "US",
        name: t("United States")
    },
    {
        code: "UM",
        name: t("United States Minor Outlying Islands")
    },
    {
        code: "UY",
        name: t("Uruguay")
    },
    {
        code: "UZ",
        name: t("Uzbekistan")
    },
    {
        code: "VU",
        name: t("Vanuatu")
    },
    {
        code: "VE",
        name: t("Venezuela")
    },
    {
        code: "VN",
        name: t("Vietnam")
    },
    {
        code: "VG",
        name: t("Virgin Islands, British")
    },
    {
        code: "VI",
        name: t("Virgin Islands, U.S.")
    },
    {
        code: "WF",
        name: t("Wallis and Futuna")
    },
    {
        code: "YE",
        name: t("Yemen")
    },
    {
        code: "ZM",
        name: t("Zambia")
    },
    {
        code: "ZW",
        name: t("Zimbabwe")
    }],
    r = function() {
        function t() {
            babelHelpers.classCallCheck(this, t)
        }
        return babelHelpers.createClass(t, [{
            key: "countries",
            get: function() {
                function t() {
                    return e.copy(n)
                }
                return t
            } ()
        }]),
        t
    } ();
    e.module("WVS").service("axGeo", r)
} (angular),
function(e) {
    "use strict";
    var t = e.isDefined,
    n = e.isFunction,
    r = function() {
        function e(r, i, a, o, s) {
            var c = this;
            babelHelpers.classCallCheck(this, e),
            this.$http = r,
            this.$log = i,
            this.$q = a,
            this.$timeout = o,
            this.axConstant = s,
            this.upload = function(e, r) {
                function i(e, t) {
                    var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                    o = arguments[3],
                    s = arguments[4];
                    return r = ~~r,
                    a(t, r).then(function(a) {
                        var c = {
                            timeout: o,
                            transformRequest: [],
                            headers: {
                                "Content-Disposition": 'attachment; filename="' + String(encodeURIComponent(t.name)) + '"',
                                "Content-Type": "application/octet-stream",
                                "Content-Range": "bytes " + String(a.from) + "-" + String(a.to) + "/" + String(a.totalLength)
                            }
                        };
                        return l.post(e, new Uint8Array(a.buffer), c).then(function() {
                            n(s) && s({
                                uploadedBytes: a.to + 1,
                                totalBytes: t.size,
                                from: a.from,
                                to: a.to,
                                uploadURL: e
                            })
                        }).then(function() {
                            var n = p.defer();
                            return a.to < t.size - 1 ? f(function() {
                                i(e, t, r + a.bufferLength, o, s).then(n.resolve, n.reject, n.notify)
                            },
                            100) : n.resolve(),
                            n.promise
                        })
                    })
                }
                function a(e, n) {
                    function r(r) {
                        var i = r.target.error;
                        if (i) return d.debug("Upload error: ", i),
                        void a.reject(i);
                        var o = r.target.result,
                        s = t(o.byteLength) ? o.byteLength: o.length;
                        a.resolve({
                            buffer: o,
                            bufferLength: s,
                            from: n,
                            to: n + s - 1,
                            totalLength: e.size
                        })
                    }
                    var i = new FileReader,
                    a = p.defer(),
                    o = e.slice(n, n + u);
                    return i.onload = r,
                    i.readAsArrayBuffer(o),
                    a.promise
                }
                var o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                s = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : c.axConstant.UPLOAD_TIMEOUT,
                u = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : c.axConstant.UPLOAD_CHUNK_SIZE,
                l = c.$http,
                d = c.$log,
                p = c.$q,
                f = c.$timeout,
                g = p.defer(),
                h = g.promise,
                m = p.defer(),
                v = f(m.resolve, 1e3 * s);
                return h.
                finally(function() {
                    f.cancel(v)
                }),
                h.cancel = function(e) {
                    g.reject.apply(g, t(e) ? [{
                        reason: e
                    }] : []),
                    m.resolve()
                },
                i(e, r, o, m.promise,
                function(e) {
                    return g.notify(e)
                }).then(g.resolve, g.reject),
                h
            }
        }
        return e.$inject = ["$http", "$log", "$q", "$timeout", "axConstant"],
        e
    } ();
    e.module("WVS").service("axFileUploadService", r)
} (angular),
function(e, t) {
    "use strict";
    var n = function() {
        function n(e, t) {
            babelHelpers.classCallCheck(this, n),
            this.$rootScope = e,
            this.axConstant = t,
            this._currentSession = null
        }
        return n.$inject = ["$rootScope", "axConstant"],
        babelHelpers.createClass(n, [{
            key: "get",
            value: function() {
                function n(n) {
                    return e.isString(n) ? t.get(this._currentSession, n, null) : this._currentSession
                }
                return n
            } ()
        },
        {
            key: "hasFeature",
            value: function() {
                function e(e) {
                    return !! this._currentSession && this._currentSession.features[e]
                }
                return e
            } ()
        },
        {
            key: "hasPermission",
            value: function() {
                function e(e) {
                    return !! this._currentSession && this._currentSession.permissions[e]
                }
                return e
            } ()
        },
        {
            key: "set",
            value: function() {
                function t(t) {
                    var n = this,
                    r = this.$rootScope,
                    i = this.axConstant;
                    if (this._currentSession = t ? e.copy(t) : null, this._currentSession) {
                        Object.defineProperty(this._currentSession, "isMasterAccount", {
                            value: !this._currentSession.isChildAccount,
                            writable: !1
                        }),
                        Object.defineProperty(this._currentSession, "isTechAdmin", {
                            value: "tech_admin" === this._currentSession.role,
                            writable: !1
                        }),
                        Object.defineProperty(this._currentSession, "isAuditor", {
                            value: "auditor" === this._currentSession.role,
                            writable: !1
                        }),
                        Object.defineProperty(this._currentSession, "isTester", {
                            value: "tester" === this._currentSession.role,
                            writable: !1
                        });
                        var a = (this._currentSession.isSysAccount, this._currentSession.isMasterAccount),
                        o = this._currentSession.isTechAdmin,
                        s = o && this._currentSession.accessAllGroups,
                        c = this._currentSession.isTester,
                        u = function() {
                            function e(e) {
                                return (n._currentSession && n._currentSession.license && n._currentSession.license.features ? n._currentSession.license.features.indexOf(e) : -1) > -1
                            }
                            return e
                        } (),
                        l = {
                            addTarget: a || s,
                            targetConfig: a || o,
                            addToGroup: a || s,
                            addGroup: a || s,
                            editGroup: a || s,
                            removeGroup: a || s,
                            changeGroupMembership: a || s,
                            removeTarget: a || o,
                            viewLicenseKey: a,
                            removeScan: a || o,
                            stopScan: a || o || c,
                            scheduleScan: a || o || c,
                            createIssue: a || o || c,
                            systemConfig: a,
                            childUsers: a,
                            viewIssueTrackers: a || o,
                            manageExcludedHours: a || s,
                            changeDefaultExcludedHoursProfile: a,
                            generateComplianceReport: u("compliance_reports"),
                            generateWafExport: u("export_waf"),
                            businessCriticality: u("target_business_criticality")
                        },
                        d = {
                            apikey: u("api_key"),
                            acumonitor: u("acumonitor"),
                            bug_tracking_integration: u("bug_tracking_integration"),
                            compliance_reports: u("compliance_reports"),
                            continuous_scans: u("continuous_scans"),
                            export_waf: u("export_waf"),
                            multi_user: u("multi_user"),
                            scanning_profiles: u("scanning_profiles"),
                            target_business_criticality: u("target_business_criticality"),
                            target_groups: u("target_groups"),
                            trending_graphs: u("trending_graphs"),
                            updates: u("updates"),
                            vuln_retest: u("vuln_retest")
                        };
                        Object.defineProperty(this._currentSession, "permissions", {
                            writable: !1,
                            value: l
                        }),
                        Object.defineProperty(this._currentSession, "features", {
                            writable: !1,
                            value: d
                        })
                    }
                    r.$emit(i.API_EVENTS.CURRENT_USER_IDENTITY_UPDATED, {
                        identity: this._currentSession ? e.copy(this._currentSession) : null
                    })
                }
                return t
            } ()
        }]),
        n
    } ();
    e.module("WVS").service("CurrentUser", n)
} (angular, _),
function(e) {
    "use strict";
    var t = e.identity,
    n = {
        API_BASE_PATH: "/api/v1",
        API_AUTH_HEADER: "X-Auth",
        API_CACHE_CAPACITY: 10,
        API_REQUEST_TIMEOUT: 3e4,
        BSID: "BSID",
        MIS: "MIS",
        PROMISE_TRACKER_ACTIVATION_DELAY: 0,
        ERROR_CODES: Object.freeze({
            AUTH_REQUIRED: "auth-required"
        }),
        SYI_ERROR_CODES: Object.freeze({
            FEATURE_NOT_ALLOWED: 1,
            AX_CHILD_USERS_REACHED: 2,
            /**
       * @name LICENSE_NOT_ACTIVATED
       * @memberOf axConstant#SYI_ERROR_CODES
       * @constant
       * @default 0x3
       */
            LICENSE_NOT_ACTIVATED: 3,
            /**
       * @name LICENSE_EXPIRED
       * @memberOf axConstant#SYI_ERROR_CODES
       * @constant
       * @default 0x4
       */
            LICENSE_EXPIRED: 4,
            INVALID_FILTER: 16,
            DB_CONNECTION_ERROR: 100,
            MI_NOT_FROM_LOCALHOST: 64,
            MI_NO_SESSION_ID: 65,
            MI_RECURRENT_SCANS_NOT_ALLOWED: 66,
            MI_ONLY_SCAN_NOW_ALLOWED: 67,
            MI_SCAN_NOW_NOT_POSSIBLE_TARGET_EXCLUDED_HOURS: 67,
            MI_SCAN_NOW_NOT_POSSIBLE_SYSTEM_EXCLUDED_HOURS: 68,
            MI_CONTINUOUS_MODE_NOT_SUPPORTED: 69
        }),
        BUSINESS_CRITICALITY: Object.freeze([{
            value: "30",
            text: t("重要的")
        },
        {
            value: "20",
            text: t("高危")
        },
        {
            value: "10",
            text: t("一般")
        },
        {
            value: "0",
            text: t("低危")
        }]),
        THREAT_LEVEL: Object.freeze([{
            value: "3",
            text: t("高危")
        },
        {
            value: "2",
            text: t("中危")
        },
        {
            value: "1",
            text: t("低危")
        },
        {
            value: "0",
            text: t("信息")
        }]),
        USER_ROLE: Object.freeze([{
            value: "tech_admin",
            text: t("科技管理员")
        },
        {
            value: "tester",
            text: t("测试员")
        },
        {
            value: "auditor",
            text: t("审计师")
        }]),
        VULN_SEVERITY_LEVEL: Object.freeze([{
            value: "3",
            text: t("高危")
        },
        {
            value: "2",
            text: t("中危")
        },
        {
            value: "1",
            text: t("低危")
        },
        {
            value: "0",
            text: t("警告")
        }]),
        VULN_STATUS: Object.freeze([{
            value: "open",
            text: t("开启的")
        },
        {
            value: "fixed",
            text: t("已修复")
        },
        {
            value: "ignored",
            text: t("忽略的")
        },
        {
            value: "rediscovered",
            text: t("重新发现")
        },
        {
            value: "false_positive",
            text: t("误报")
        }]),
        CVSS_SCORE: Object.freeze([{
            value: "7",
            text: t("7或更高")
        },
        {
            value: "4-7",
            text: t("4-7之间")
        },
        {
            value: "4",
            text: t("小于4")
        }]),
        SCAN_STATUS: Object.freeze([{
            value: "aborted",
            text: t("已中止")
        },
        {
            value: "aborting",
            text: t("中止")
        },
        {
            value: "completed",
            text: t("已完成")
        },
        {
            value: "continuous",
            text: t("连续")
        },
        {
            value: "failed",
            text: t("失败")
        },
        {
            value: "processing",
            text: t("处理中")
        },
        {
            value: "queued",
            text: t("已排队")
        },
        {
            value: "scheduled",
            text: t("计划")
        },
        {
            value: "starting",
            text: t("开始")
        }]),
        SCHEDULE_TYPE: Object.freeze([{
            value: "instant",
            text: t("瞬间")
        },
        {
            value: "future",
            text: t("未来扫描")
        },
        {
            value: "recurrent",
            text: t("反复扫描")
        },
        {
            value: "continuous",
            text: t("连续扫描")
        }]),
        REPORT_STATUS: Object.freeze([{
            value: "queued",
            text: t("已排队")
        },
        {
            value: "processing",
            text: t("处理中")
        },
        {
            value: "completed",
            text: t("已完成")
        },
        {
            value: "failed",
            text: t("失败")
        }]),
        REPORT_SOURCE: Object.freeze([{
            value: "all_vulnerabilities",
            text: t("所有漏洞报告")
        },
        {
            value: "targets",
            text: t("目标报告")
        },
        {
            value: "scans",
            text: t("扫描报告")
        },
        {
            value: "scan_result",
            text: t("扫描结果报告")
        },
        {
            value: "vulnerabilities",
            text: t("目标漏洞报告")
        },
        {
            value: "scan_vulnerabilities",
            text: t("扫描漏洞报告")
        }]),
        SCAN_SPEED: Object.freeze([{
            numericValue: 1,
            value: "sequential",
            text: t("最慢速")
        },
        {
            numericValue: 2,
            value: "slow",
            text: t("慢速")
        },
        {
            numericValue: 3,
            value: "moderate",
            text: t("中速")
        },
        {
            numericValue: 4,
            value: "fast",
            text: t("快速")
        }]),
        DEFAULT_UI_LANGUAGE: "en_GB",
        LIST_PAGE_SIZE: void 0,
        LIST_REFRESH_INTERVAL: 1e3,
        LOGIN_SEQUENCE_MAX_SIZE: 65535,
        NOTIFICATIONS_POLL_INTERVAL: 3e4,
        VERSION_CHECK_INTERVAL: 432e5,
        DASH_REFRESH_INTERVAL: 1e4,
        /**
     * @name LICENSE_CHECK_INTERVAL
     * @default 5 * 60 * 1000 (5 minutes in milliseconds)
     * @description
     * Interval upon which to refresh license information
     */
        LICENSE_CHECK_INTERVAL: 3e5,
        EVENT_TYPES_MAP: Object.freeze([{
            typeId: "0",
            typeName: t("Created"),
            groupKey: "account",
            groupName: t("Account")
        },
        {
            typeId: "1",
            typeName: t("Details Modified"),
            groupKey: "account",
            groupName: t("Account")
        },
        {
            typeId: "2",
            typeName: t("Email Change Asked"),
            groupKey: "account",
            groupName: t("Account")
        },
        {
            typeId: "3",
            typeName: t("Email Changed"),
            groupKey: "account",
            groupName: t("Account")
        },
        {
            typeId: "4",
            typeName: t("Password Reset Asked"),
            groupKey: "account",
            groupName: t("Account")
        },
        {
            typeId: "5",
            typeName: t("Password Reset"),
            groupKey: "account",
            groupName: t("Account")
        },
        {
            typeId: "6",
            typeName: t("Password Changed"),
            groupKey: "account",
            groupName: t("Account")
        },
        {
            typeId: "7",
            typeName: t("Account Verified"),
            groupKey: "account",
            groupName: t("Account")
        },
        {
            typeId: "8",
            typeName: t("Login"),
            groupKey: "account",
            groupName: t("Account")
        },
        {
            typeId: "9",
            typeName: t("Logout"),
            groupKey: "account",
            groupName: t("Account")
        },
        {
            typeId: "100",
            typeName: t("Created"),
            groupKey: "child_account",
            groupName: t("Child Account")
        },
        {
            typeId: "101",
            typeName: t("Deleted"),
            groupKey: "child_account",
            groupName: t("Child Account")
        },
        {
            typeId: "102",
            typeName: t("Modified"),
            groupKey: "child_account",
            groupName: t("Child Account")
        },
        {
            typeId: "103",
            typeName: t("Set Access"),
            groupKey: "child_account",
            groupName: t("Child Account")
        },
        {
            typeId: "200",
            typeName: t("Created"),
            groupKey: "target",
            groupName: t("Target")
        },
        {
            typeId: "201",
            typeName: t("Modified"),
            groupKey: "target",
            groupName: t("Target")
        },
        {
            typeId: "202",
            typeName: t("Deleted"),
            groupKey: "target",
            groupName: t("Target")
        },
        {
            typeId: "203",
            typeName: t("Add Allowed Host"),
            groupKey: "target",
            groupName: t("Target")
        },
        {
            typeId: "204",
            typeName: t("Remove Allowed Host"),
            groupKey: "target",
            groupName: t("Target")
        },
        {
            typeId: "205",
            typeName: t("Not Responsive"),
            groupKey: "target",
            groupName: t("Target")
        },
        {
            typeId: "206",
            typeName: t("Validated"),
            groupKey: "target",
            groupName: t("Target")
        },
        {
            typeId: "207",
            typeName: t("Verification Succeeded"),
            groupKey: "target",
            groupName: t("Target")
        },
        {
            typeId: "208",
            typeName: t("Verification Failed"),
            groupKey: "target",
            groupName: t("Target")
        },
        {
            typeId: "209",
            typeName: t("Continuous Mode Disabled"),
            groupKey: "target",
            groupName: t("Target"),
            notification: !0
        },
        {
            typeId: "300",
            typeName: t("Created"),
            groupKey: "group",
            groupName: t("Group")
        },
        {
            typeId: "301",
            typeName: t("Deleted"),
            groupKey: "group",
            groupName: t("Group")
        },
        {
            typeId: "302",
            typeName: t("Modified"),
            groupKey: "group",
            groupName: t("Group")
        },
        {
            typeId: "303",
            typeName: t("Targets Modified"),
            groupKey: "group",
            groupName: t("Group")
        },
        {
            typeId: "400",
            typeName: t("Scheduled"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "401",
            typeName: t("Modified"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "402",
            typeName: t("Deleted"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "403",
            typeName: t("Started"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "404",
            typeName: t("Done"),
            groupKey: "scan",
            groupName: t("Scan"),
            notification: !0
        },
        {
            typeId: "405",
            typeName: t("Failed"),
            groupKey: "scan",
            groupName: t("Scan"),
            notification: !0
        },
        {
            typeId: "406",
            typeName: t("User Aborted"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "407",
            typeName: t("Recurrence Suspended"),
            groupKey: "scan",
            groupName: t("Scan"),
            notification: !0
        },
        {
            typeId: "410",
            typeName: t("Job Starting"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "411",
            typeName: t("Job Completed"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "412",
            typeName: t("Job Failed"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "413",
            typeName: t("Job Aborted"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "420",
            typeName: t("Scanner Event"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "430",
            typeName: t("Crawler Memory Limit Reached"),
            groupKey: "scan",
            groupName: t("Scan"),
            notification: !0
        },
        {
            typeId: "431",
            typeName: t("Aborted by Scanner"),
            groupKey: "scan",
            groupName: t("Scan"),
            notification: !0
        },
        {
            typeId: "432",
            typeName: t("AcuSensor Found"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "433",
            typeName: t("AcuSensor Not Found"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "434",
            typeName: t("Automatic login failed"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "435",
            typeName: t("Invalid HTTP Credentials"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "436",
            typeName: t("Login Sequence Required"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "437",
            typeName: t("Crawling"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "438",
            typeName: t("Deep Scan"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "439",
            typeName: t("Scan Started"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "440",
            typeName: t("Scan Finished"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "441",
            typeName: t("Manual Intervention"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "442",
            typeName: t("Scan Resumed"),
            groupKey: "scan",
            groupName: t("Scan")
        },
        {
            typeId: "500",
            typeName: t("Marked As"),
            groupKey: "vulnerability",
            groupName: t("Vulnerability")
        },
        {
            typeId: "501",
            typeName: t("Rediscovered"),
            groupKey: "vulnerability",
            groupName: t("Vulnerability")
        },
        {
            typeId: "502",
            typeName: t("Discovered by AcuMonitor"),
            groupKey: "vulnerability",
            groupName: t("Vulnerability"),
            notification: !0
        },
        {
            typeId: "600",
            typeName: t("Asked"),
            groupKey: "report",
            groupName: t("Report")
        },
        {
            typeId: "601",
            typeName: t("Created"),
            groupKey: "report",
            groupName: t("Report"),
            notification: !0
        },
        {
            typeId: "602",
            typeName: t("Asked"),
            groupKey: "export",
            groupName: t("Export")
        },
        {
            typeId: "603",
            typeName: t("Created"),
            groupKey: "export",
            groupName: t("Export"),
            notification: !0
        },
        {
            typeId: "604",
            typeName: t("Failed"),
            groupKey: "report",
            groupName: t("Report"),
            notification: !0
        },
        {
            typeId: "605",
            typeName: t("Failed"),
            groupKey: "export",
            groupName: t("Export"),
            notification: !0
        },
        {
            typeId: "700",
            typeName: t("New Version"),
            groupKey: "application",
            groupName: t("Application"),
            notification: !0
        }]),
        EVENT_SEVERITY: Object.freeze([{
            text: t("信息性"),
            value: "0"
        },
        {
            text: t("警告"),
            value: "1"
        },
        {
            text: t("错误"),
            value: "2"
        },
        {
            text: t("危急"),
            value: "3"
        }]),
        EVENT_RESOURCE_TYPE: Object.freeze([{
            text: t("Child User"),
            value: "2"
        },
        {
            text: t("导出"),
            value: "10"
        },
        {
            text: t("组织"),
            value: "4"
        },
        {
            text: t("报告"),
            value: "7"
        },
        {
            text: t("扫描"),
            value: "5"
        },
        {
            text: t("扫描会话"),
            value: "6"
        },
        {
            text: t("目标"),
            value: "3"
        },
        {
            text: t("用户"),
            value: "1"
        },
        {
            text: t("漏洞"),
            value: "9"
        },
        {
            text: t("工作者"),
            value: "8"
        }]),
        API_EVENTS: Object.freeze({
            USER_LOGGED_IN: "ax/User/LoggedIn",
            USER_LOGGED_OUT: "ax/User/LoggedOut",
            CURRENT_USER_IDENTITY_UPDATED: "ax/CurrentUser/Identity/Updated",
            USER_PROFILE_UPDATED: "ax/User/Profile/Updated",
            TARGET_CREATED: "ax/Target/Created",
            TARGET_UPDATED: "ax/Target/Updated",
            TARGET_DELETED: "ax/Target/Deleted",
            TARGET_CONTINUOUS_SCAN_STATUS_CHANGED: "ax/Target/ContinuousScanStatusChanged",
            ISSUE_TRACKER_CREATED: "ax/IssueTracker/Created",
            ISSUE_TRACKER_DELETED: "ax/IssueTracker/Deleted",
            TARGET_GROUP_CREATED: "ax/TargetGroup/Created",
            TARGET_GROUP_UPDATED: "ax/TargetGroup/Updated",
            TARGET_GROUP_DELETED: "ax/TargetGroup/Deleted",
            SCAN_CREATED: "ax/Scans/Created",
            SYSTEM_INFO_LOADED: "ax/SystemInfo/Loaded"
        }),
        PRODUCT_ACTIVATION_REQUIRED: "ax/ProductActivation/Required",
        BUG_TRACKERS: Object.freeze([{
            text: t("GitHub"),
            value: "github"
        },
        {
            text: t("JIRA"),
            value: "jira"
        },
        {
            text: t("TFS"),
            value: "tfs"
        }]),
        JIRA_BUG_TRACKER_AUTH: Object.freeze([{
            text: t("Cookie-Based"),
            value: "cookie"
        },
        {
            text: t("HTTP基础认证"),
            value: "http_basic"
        }]),
        /**
     * @name axConstant#LICENSE_FEATURES
     */
        LICENSE_FEATURES: [{
            text: t("AcuMonitor"),
            value: "acumonitor"
        },
        {
            text: t("集成bug跟踪"),
            value: "bug_tracking_integration"
        },
        {
            text: t("合规报告"),
            value: "compliance_reports"
        },
        {
            text: t("连续扫描"),
            value: "continuous_scans"
        },
        {
            text: t("Export WAF"),
            value: "export_waf"
        },
        {
            text: t("多用户"),
            value: "multi_user"
        },
        {
            text: t("产品更新"),
            value: "updates"
        },
        {
            text: t("目标业务重要性"),
            value: "target_business_criticality"
        },
        {
            text: t("目标群体"),
            value: "target_groups"
        },
        {
            text: t("趋势图"),
            value: "trending_graphs"
        }],
        PRODUCT_EDITION: Object.freeze([{
            text: t("免费试用"),
            value: "TRIAL"
        },
        {
            text: t("标准版"),
            value: "WVSE"
        },
        {
            text: t("专业版"),
            value: "WVSC"
        },
        {
            text: t("企业版"),
            value: "WVSC10"
        },
        {
            text: t("企业版"),
            value: "WVSF05Q"
        },
        {
            text: t("企业版"),
            value: "WVSF10Q"
        },
        {
            text: t("概念证明"),
            value: "WVSPOC"
        },
        {
            text: t("服务提供商许可证"),
            value: "WVSSPL"
        }]),
        SMTP_SECURITY_OPTION: Object.freeze([{
            value: "none",
            text: t("None")
        },
        {
            value: "auto",
            text: t("自动")
        },
        {
            value: "ssl",
            text: t("SSL")
        },
        {
            value: "tls",
            text: t("TLS")
        }]),
        PROXY_PROTOCOL_OPTION: Object.freeze([{
            value: "none",
            text: t("None")
        },
        {
            value: "http",
            text: t("HTTP")
        }]),
        HELP_LINKS: Object.freeze({
            "targets.list": "https://www.acunetix.com/support/docs/wvs/configuring-targets",
            "target.general": "https://www.acunetix.com/support/docs/wvs/configuring-targets/#id.xel0jag02o81",
            "target.crawl": "https://www.acunetix.com/support/docs/wvs/configuring-targets/#id.tqnek5x7fof",
            "target.http": "https://www.acunetix.com/support/docs/wvs/configuring-targets/#id.tqnek5x7fof",
            "target.advanced": "https://www.acunetix.com/support/docs/wvs/configuring-targets/#id.tqnek5x7fof",
            "vulns.list": "https://www.acunetix.com/support/docs/wvs/managing-vulnerabilities/",
            "scans.list": "https://www.acunetix.com/support/docs/wvs/scanning-website/",
            "scan.stats": "https://www.acunetix.com/support/docs/wvs/analyzing-scan-results/#id.djrdugpogazq",
            "scan.vulns": "https://www.acunetix.com/support/docs/wvs/analyzing-scan-results/#id.q7r4wqfaiqrt",
            "scan.crawl": "https://www.acunetix.com/support/docs/wvs/analyzing-scan-results/#id.lbyyspbkedis",
            "scan.events": "https://www.acunetix.com/support/docs/wvs/analyzing-scan-results/#id.ru3cyx3k2ozx",
            "reports.generate": "https://www.acunetix.com/support/docs/wvs/generating-reports/",
            "reports.templates": "https://www.acunetix.com/support/docs/types-reports/",
            settings: "https://www.acunetix.com/support/docs/wvs/acunetix-settings/",
            "settings.updates": "https://www.acunetix.com/support/docs/wvs/acunetix-settings/#id.4ckpaipw8a0x",
            "settings.proxy": "https://www.acunetix.com/support/docs/wvs/acunetix-settings/#id.2ee9eekoaoyr",
            "settings.notifications": "https://www.acunetix.com/support/docs/wvs/acunetix-settings/#id.b2e5l899wu6p",
            "settings.users": "https://www.acunetix.com/support/docs/wvs/configuring-users/",
            "settings.groups": "https://www.acunetix.com/support/docs/wvs/acunetix-settings/#id.9sbqrtmj2h5"
        }),
        UPLOAD_CHUNK_SIZE: 1048576,
        UPLOAD_TIMEOUT: 30,
        TEST_WEBSITES: Object.freeze([{
            url: "http://testhtml5.vulnweb.com",
            sensor: !1
        },
        {
            url: "http://testphp.vulnweb.com",
            sensor: !0
        },
        {
            url: "http://testasp.vulnweb.com",
            sensor: !1
        },
        {
            url: "http://testaspnet.vulnweb.com",
            sensor: !0
        }])
    };
    e.module("WVS").constant("axConstant", n)
} (angular),
function(e) {
    "use strict";
    var t = function(e, t, n, r, i) {
        return Array.isArray(i) && i.length > 0 && i.forEach(function(n) {
            return t.$on(n,
            function() {
                e.get(r).removeAll()
            })
        }),
        e(r, {
            capacity: n.API_CACHE_CAPACITY
        })
    };
    t.$inject = ["$cacheFactory", "$rootScope", "axConstant", "cacheId", "events"];
    var n = function(e, n) {
        for (var r = arguments.length,
        i = Array(r > 2 ? r - 2 : 0), a = 2; a < r; a++) i[a - 2] = arguments[a];
        return e.invoke(t, void 0, {
            cacheId: n,
            events: i
        })
    };
    e.module("WVS").factory("axTargetsCache", ["$injector", "axConstant",
    function(e, t) {
        return n(e, "axTargets", t.API_EVENTS.TARGET_CREATED, t.API_EVENTS.TARGET_DELETED)
    }]).factory("axGroupsCache", ["$injector", "axConstant",
    function(e, t) {
        return n(e, "axGroups", t.API_EVENTS.TARGET_GROUP_CREATED, t.API_EVENTS.TARGET_GROUP_DELETED, t.API_EVENTS.TARGET_GROUP_UPDATED)
    }]).factory("axVulnTypesCache", ["$injector",
    function(e) {
        return n(e, "axVulnTypes")
    }]).factory("axLocationsCache", ["$injector",
    function(e) {
        return n(e, "axLocations")
    }]).factory("axReportTemplatesCache", ["$injector",
    function(e) {
        return n(e, "axReportTemplates")
    }]).factory("axExportTemplatesCache", ["$injector",
    function(e) {
        return n(e, "axExportTemplates")
    }])
} (angular),
function(e, t, n, r) {
    "use strict";
    function i(e, n, i, a, o, s, c, u, l) {
        function d(e) {
            return c.delete("/me/credentials/api-key", 204, e).then(r.constant(void 0))
        }
        function p(e) {
            return c.get("/me/credentials/api-key", 200, e).then(function(e) {
                return e.data ? e.data.api_key: null
            })
        }
        function f() {
            var e = o.BSID,
            n = s.get(e),
            r = u.get("userId");
            if (!n && r) {
                var i = String(r) + "|" + String((new Date).getTime()) + String(Math.random());
                n = t.MD5(i).toString().toLowerCase(),
                s.set(e, n)
            }
            return n
        }
        function g(e) {
            return n.when().then(f).then(function(t) {
                return t ? c.get("/me/manual_intervention/" + String(t), 200, e) : null
            }).then(function(e) {
                return r.get(e, "data.values", []).map(U)
            })
        }
        function h(t) {
            return c.get("/me", 200, t).then(function(e) {
                return F(e.data)
            }).then(function(n) {
                return l.getSystemInfo(We(t)).then(function(t) {
                    var s = t.license;
                    return n.license = s,
                    u.set(n),
                    r.get(n, "license.activated") === !1 && a(function() {
                        return i.$emit(o.PRODUCT_ACTIVATION_REQUIRED)
                    },
                    1e3),
                    null === C && (C = e(x, o.LICENSE_CHECK_INTERVAL)),
                    n
                })
            }).
            catch(function(e) {
                return _(),
                n.reject(e)
            })
        }
        function m() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "simple",
            t = arguments[1];
            return n.when({}).then(function(n) {
                return "simple" === e || "full" === e ? c.get("/me/stats", 200, t).then(function(e) {
                    return Me(n, $(e.data))
                }) : n
            }).then(function(n) {
                return "trends" === e || "full" === e ? c.get("/me/trends", 200, t).then(function(e) {
                    return Me(n, ae(e.data))
                }) : n
            })
        }
        function v(e) {
            return c.post("/me/credentials/api-key", {},
            201, e).then(function(e) {
                return r.get(e, "data.api_key", null)
            })
        }
        function y(e, t) {
            return c.post("/password_reset", {
                email: e
            },
            205, t).then(r.constant(void 0))
        }
        function S(e, n, r, a) {
            var s = {
                email: e,
                password: t.SHA256(n).toString(),
                remember_me: r
            },
            u = Me({
                noAuthToken: !0,
                noLoginRedirect: !0
            },
            a);
            return c.post("/me/login", s, 204, u).then(function() {
                return h(We(a))
            }).then(function(e) {
                return i.$emit(o.API_EVENTS.USER_LOGGED_IN, {
                    userProfile: Ve(e)
                }),
                e
            })
        }
        function b(e) {
            return c.post("/me/logout", {},
            204, Me({
                noLoginRedirect: !0
            },
            e)).
            catch(r.constant(void 0)).then(function() {
                var e = u.get();
                u.set(null),
                i.$emit(o.API_EVENTS.USER_LOGGED_OUT, {
                    previousIdentity: e ? Ve(e) : null
                })
            }).then(r.constant(void 0))
        }
        function T(e, t) {
            var n = we(e);
            return c.patch("/me", n, 204, t).then(function() {
                return h(We(t))
            }).then(function(e) {
                return i.$emit(o.API_EVENTS.USER_PROFILE_UPDATED, {
                    userProfile: Ve(e)
                }),
                e
            })
        }
        function x() {
            return h({
                noPublishError: !0,
                noLoadingTracker: !0
            }).then(function() {
                if (null === u.get()) return n.reject()
            }).
            catch(function() {
                null === u.get() && _()
            })
        }
        function _() {
            null !== C && (e.cancel(C), C = null)
        }
        this.deleteApiKey = d,
        this.getApiKey = p,
        this.getBSIDValue = f,
        this.getManualInterventionStatus = g,
        this.getProfile = h,
        this.getStats = m,
        this.resetApiKey = v,
        this.signIn = S,
        this.signOut = b,
        this.updateProfile = T,
        this.resetPassword = y;
        var C = null
    }
    function a(e, t, n, i) {
        function a(t, n) {
            return i.post("/users", he(t), 201, n).then(function(t) {
                return e.get(t.headers("Location"), We(n))
            }).then(y(200)).then(function(e) {
                return x(e.data)
            })
        }
        function o(e, t) {
            return i.get("/users/" + String(e) + "/access", 200, t).then(f()).then(function(e) {
                return se(e.data)
            })
        }
        function s(e, t) {
            return i.get("/users/" + String(e), [200, 404], t).then(function(e) {
                var t = e.status,
                n = e.data;
                return 404 === t ? null: x(n)
            })
        }
        function c(e, t, n) {
            return i.get("/users", 200, Me({
                params: Ie(void 0, e, t)
            },
            n)).then(function(e) {
                return {
                    users: r.get(e, "data.users", []).map(x),
                    pagination: M(r.get(e, "data.pagination", qe))
                }
            })
        }
        function u(e, t) {
            return i.delete("/users/" + String(e), 204, t).then(r.constant(null))
        }
        function l(e, t) {
            return i.post("/users/" + String(e) + "/confirmation_email", {},
            204, t).then(r.constant(null))
        }
        function d(e, t, n) {
            return i.post("/users/" + String(e) + "/access", Ne(t), 204, n).then(f()).then(r.constant(null))
        }
        function p(e, t) {
            return i.patch("/users/" + String(e.userId), ge(e), 204, t).then(f()).then(function() {
                return s(e.userId, We(t))
            })
        }
        function f() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Ge("The requested user information is not available");
            return function(r) {
                return 404 === r.status ? (r.errorMessage = e, r.config.noPublishError !== !0 && n.$emit("axError", r), t.reject(r)) : r
            }
        }
        this.addUser = a,
        this.getAccess = o,
        this.getUser = s,
        this.getUsers = c,
        this.removeUser = u,
        this.resendConfirmationEmail = l,
        this.setAccess = d,
        this.updateUser = p
    }
    function o(e, t, n, i) {
        function a(t, n) {
            return i.post("/excluded_hours_profiles", me(t), 201, n).then(function(t) {
                return e.get(t.headers("Location"), We(n))
            }).then(function(e) {
                return k(e.data)
            })
        }
        function o(e, t) {
            return i.get("/excluded_hours_profiles/" + String(e), 200, t).then(function(e) {
                var t = e.status,
                n = e.data;
                return 404 === t ? null: k(n)
            })
        }
        function s(e) {
            return i.get("/excluded_hours_profiles", 200, e).then(function(e) {
                return r.get(e, "data.values", []).map(k)
            })
        }
        function c(e, t) {
            return i.patch("/excluded_hours_profiles/" + String(e.excludedHoursId), me(e), 204, t).then(l()).then(function() {
                return o(e.excludedHoursId)
            })
        }
        function u(e, t) {
            return i.delete("/excluded_hours_profiles/" + String(e), 204, t).then(r.constant(null))
        }
        function l() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Ge("The requested excluded hours profile is not available");
            return function(r) {
                return 404 === r.status ? (r.errorMessage = e, r.config.noPublishError !== !0 && n.$emit("axError", r), t.reject(r)) : r
            }
        }
        this.createExcludedHoursProfile = a,
        this.getExcludedHoursProfile = o,
        this.getExcludedHoursProfiles = s,
        this.modifyExcludedHoursProfile = c,
        this.removeExcludedHoursProfile = u
    }
    function s(e, t, n, i) {
        function a(e, t) {
            return n.post("/issue_trackers/check_connection", ye(e), 200, t).then(function(e) {
                return {
                    success: r.get(e, "data.success", !1),
                    errorMessage: r.get(e, "data.message", "")
                }
            })
        }
        function o(e, t) {
            return n.get("/issue_trackers/" + String(e), 200, t).then(function(e) {
                var t = e.status,
                n = e.data;
                return 404 === t ? null: P(n)
            })
        }
        function s(r, a, o) {
            return n.post("/issue_trackers", Me(ve(a), {
                name: r
            }), 201, o).then(function(t) {
                return e.get(t.headers("Location"), We(o))
            }).then(y(200)).then(function(e) {
                var n = P(e.data);
                return t.$emit(i.API_EVENTS.ISSUE_TRACKER_CREATED, {
                    issueTracker: Ve(n)
                }),
                n
            })
        }
        function c(e, a) {
            return n.delete("/issue_trackers/" + String(e), 204, a).then(function() {
                t.$emit(i.API_EVENTS.TARGET_DELETED, {
                    issueTrackerId: e
                })
            }).then(r.constant(null))
        }
        function u(e, t) {
            return n.get("/issue_trackers/" + String(e), 200, t).then(function(e) {
                var t = e.status,
                n = e.data;
                return 404 === t ? null: P(n)
            })
        }
        function l(e) {
            return n.get("/issue_trackers", 200, e).then(function(e) {
                return r.get(e, "data.issue_trackers", []).map(P)
            })
        }
        function d(e, t, i) {
            var a = Me(ye(e), {
                project: Te(t)
            });
            return n.post("/issue_trackers/check_issue_types", a, 200, i).then(function(e) {
                return r.get(e, "data.issue_types", []).map(N)
            })
        }
        function p(e, t) {
            return n.post("/issue_trackers/check_projects", ye(e), 200, t).then(function(e) {
                return r.get(e, "data.projects", []).map(D)
            })
        }
        function f(e, t) {
            return n.patch("/issue_trackers/" + String(e.issueTrackerId), Se(e), 200, t).then(function() {
                return u(e.issueTrackerId, We(t))
            })
        }
        this.checkConnection = a,
        this.checkIssueTrackerEntry = o,
        this.createIssueTrackerEntry = s,
        this.deleteIssueTrackerEntry = c,
        this.getIssueTrackerEntry = u,
        this.getIssueTrackers = l,
        this.listIssueTypes = d,
        this.listProjects = p,
        this.updateIssueTrackerEntry = f
    }
    function c(t) {
        function n(e) {
            return t.post("/notifications/consume", {},
            204, e).then(r.constant(void 0))
        }
        function i(e, n) {
            return t.post("/notifications/" + String(e) + "/consume", {},
            204, n).then(r.constant(void 0))
        }
        function a(e, n) {
            return t.get("/events/" + String(e), 200, n).then(function(e) {
                return 404 === e.status || null == e.data ? null: V(e.data)
            })
        }
        function o(n, r, i, a) {
            return t.get("/events", 200, Me({
                params: Ie(n, r, i)
            },
            a)).then(function(t) {
                var n = e.isObject(t.data) ? t.data: null;
                return {
                    notifications: null !== n ? n.notifications.map(V) : [],
                    pagination: null !== n ? M(n.pagination) : {}
                }
            })
        }
        function s(n, r, i, a) {
            return t.get("/notifications", 200, Me({
                params: Ie(n, r, i)
            },
            a)).then(function(t) {
                var n = e.isObject(t.data) ? t.data: null;
                return {
                    notifications: null !== n ? n.notifications.map(V) : [],
                    pagination: null !== n ? M(n.pagination) : {}
                }
            })
        }
        function c(e) {
            return t.get("/notifications/count", 200, e).then(function(e) {
                return null != e.data ? e.data.count: 0
            })
        }
        this.consumeAll = n,
        this.consumeNotification = i,
        this.getEvent = a,
        this.getEvents = o,
        this.getNotifications = s,
        this.getUnconsumedNotificationCount = c
    }
    function u(e, t, n, i, a, o, s) {
        function c(e, n, r) {
            return a.post("/exports", xe(e, n), 201, r).then(function(e) {
                return t.get(e.headers("Location"), We(r))
            }).then(y(200)).then(function(e) {
                return A(e.data)
            })
        }
        function u(e, n, r) {
            return a.post("/reports", _e(e, n), 201, r).then(function(e) {
                return t.get(e.headers("Location"), We(r))
            }).then(y(200)).then(function(e) {
                return H(e.data)
            })
        }
        function l(e, t) {
            return a.get("/exports/" + String(e), 200, t).then(function(e) {
                var t = e.status,
                n = e.data;
                return 404 === t ? null: A(n)
            })
        }
        function d(e, t) {
            return a.get("/export_types", 200, Me({
                cache: o
            },
            t)).then(function(e) {
                return r.get(e, "data.templates", []).map(L)
            }).then(function(t) {
                return t.length > 0 && (He(e) ? t = t.filter(function(t) {
                    return t.acceptedSources.indexOf(e) > -1
                }) : Array.isArray(e) && (t = r.takeWhile(t,
                function(t) {
                    return r.intersection(t.acceptedSources, e).length > 0
                }))),
                i(t, "name")
            })
        }
        function p(e, t) {
            return a.get("/reports/" + String(e), 200, t).then(function(e) {
                var t = e.status,
                n = e.data;
                return 404 === t ? null: H(n)
            })
        }
        function f(e) {
            return a.get("/report_templates", 200, Me({
                cache: s
            },
            e)).then(function(e) {
                return i(r.get(e, "data.templates", []).map(G), "name")
            })
        }
        function g(e, t, n, i) {
            return a.get("/reports", 200, Me({
                params: Ie(e, t, n)
            },
            i)).then(function(e) {
                return {
                    reports: r.get(e, "data.reports", []).map(H),
                    pagination: M(r.get(e, "data.pagination", qe))
                }
            })
        }
        function h(e, n) {
            return a.post("/reports/" + String(e) + "/repeat", {},
            201, n).then(v()).then(function(e) {
                return t.get(e.headers("Location"), We(n))
            }).then(y(200)).then(function(e) {
                return H(e.data)
            })
        }
        function m(e, t) {
            return a.delete("/reports/" + String(e), 204, t).then(r.constant(null))
        }
        function v() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Ge("The requested report information is not available");
            return function(r) {
                return 404 === r.status ? (r.errorMessage = t, r.config.noPublishError !== !0 && n.$emit("axError", r), e.reject(r)) : r
            }
        }
        this.generateNewExport = c,
        this.generateNewReport = u,
        this.getExport = l,
        this.getExportTypes = d,
        this.getReport = p,
        this.getReportTemplates = f,
        this.getReports = g,
        this.repeatReport = h,
        this.removeReport = m
    }
    function l(e, t, n, i, a) {
        function o(e, t, n, i, o, s) {
            var c = Me({
                params: Ie(void 0, i, o)
            },
            s);
            return a.get("/scans/" + String(t) + "/results/" + String(e) + "/crawldata/" + String(n) + "/children", 200, c).then(h()).then(function(e) {
                return {
                    locations: e.data.locations.map(_),
                    pagination: M(r.get(e, "data.pagination", qe))
                }
            })
        }
        function s(e, t, n, r) {
            return a.get("/scans/" + String(t) + "/results/" + String(e) + "/crawldata/" + String(n), 200, r).then(h()).then(function(e) {
                return C(e.data)
            })
        }
        function c(e, t, n, i, o, s) {
            var c = Ie(void 0, i, o);
            return a.get("/scans/" + String(t) + "/results/" + String(e) + "/crawldata/" + String(n) + "/vulnerabilities", 200, Me({
                params: c
            },
            s)).then(h()).then(function(e) {
                return {
                    vulnerabilities: e.data.vulnerabilities.map(pe),
                    pagination: M(r.get(e, "data.pagination", qe))
                }
            })
        }
        function u(e, t, n, i, o, s) {
            var c = Ie(n, i, o);
            return a.get("/scans/" + String(t) + "/results/" + String(e) + "/vulnerabilities", 200, Me({
                params: c
            },
            s)).then(h()).then(function(e) {
                return {
                    vulnerabilities: e.data.vulnerabilities.map(pe),
                    pagination: M(r.get(e, "data.pagination", qe))
                }
            })
        }
        function l(t, n, r, i) {
            return a.get("/scans/" + String(n) + "/results/" + String(t) + "/vulnerabilities/" + String(r), 200, i).then(h()).then(function(t) {
                var n = t.data;
                return e.invoke(de, void 0, {
                    dto: n
                })
            })
        }
        function d(e, t, n, i, o, s) {
            var c = Ie(n, i, o);
            return a.get("/scans/" + String(t) + "/results/" + String(e) + "/vulnerability_types", 200, Me({
                params: c
            },
            s)).then(function(e) {
                return {
                    vulnerabilityTypes: r.get(e, "data.vulnerability_types", []).map(Y),
                    pagination: M(r.get(e, "data.pagination", qe))
                }
            })
        }
        function p(e, t, n) {
            return a.get("/scans/" + String(e) + "/results/" + String(t) + "/statistics", [200, 404], n).then(function(e) {
                return 404 === e.status ? null: z(e.data)
            })
        }
        function f(e, n, r, i) {
            return a.put("/scans/" + String(n) + "/results/" + String(e) + "/vulnerabilities/" + String(r) + "/recheck", {},
            201, i).then(h()).then(function(e) {
                return t.get(e.headers("Location"), We(i))
            }).then(y(200)).then(function(e) {
                return q(e.data)
            })
        }
        function g(e, t, n, i, o, s) {
            var c = Ie(n, i, o);
            return a.get("/scans/" + String(t) + "/results/" + String(e) + "/crawldata", 200, Me({
                params: c
            },
            s)).then(h()).then(function(e) {
                return {
                    locations: e.data.locations.map(_),
                    pagination: M(r.get(e, "data.pagination", qe))
                }
            })
        }
        function h() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Ge("The requested scan information is not available");
            return function(t) {
                return 404 === t.status ? (t.errorMessage = e, t.config.noPublishError !== !0 && i.$emit("axError", t), n.reject(t)) : t
            }
        }
        this.getLocationChildren = o,
        this.getLocationDetails = s,
        this.getLocationVulnerabilities = c,
        this.getScanVulnerabilities = u,
        this.getScanVulnerabilityDetails = l,
        this.getScanVulnerabilityTypes = d,
        this.getStatistics = p,
        this.recheckVulnerability = f,
        this.searchCrawlData = g
    }
    function d(e, t, n, i, a) {
        function o(e, n) {
            return a.post("/scanning_profiles", Le(e), 200, n).then(function(e) {
                return t.get(e.headers("Location"), We(n))
            }).then(y(200)).then(function(e) {
                return K(e.data)
            })
        }
        function s(e, t) {
            return a.delete("/scanning_profiles/" + String(e), 204, t).then(r.constant(null))
        }
        function c(e, t) {
            return a.get("/scanning_profiles/" + String(e), [200, 404], t).then(p()).then(function(e) {
                var t = e.status,
                n = e.data;
                return 404 === t ? null: K(n)
            }).then(function(e) {
                return e && (e.checks.sort(), e.checks.reverse()),
                e
            })
        }
        function u(e) {
            return a.get("/scanning_profiles", 200, Me(e)).then(function(e) {
                return i(r.get(e, "data.scanning_profiles", []).map(K), "sortOrder")
            })
        }
        function l(e, t) {
            return a.patch("/scanning_profiles/" + String(e.profileId), Le(e), [204, 404], t).then(p()).then(function() {
                return c(e.profileId, We(t))
            })
        }
        function d(e) {
            return t.get("/checks.json", Me({
                timeout: 5e3,
                cache: !0
            },
            e)).then(p("The requested scan type information is not available")).then(function(e) {
                var t = e.data;
                return function e(t) {
                    if (t.checkType = "wvs", t.keyPath = "/" === t.parentKeyPath ? "" + String(t.parentKeyPath) + String(t.key) : String(t.parentKeyPath || "") + "/" + String(t.key), t.isChecked = !0, t.checks) {
                        t.checks = r.sortBy(t.checks, r.property("title"));
                        for (var n = 0; n < t.checks.length; n++) t.checks[n].checkType = "wvs",
                        t.checks[n].parentKeyPath = t.keyPath,
                        t.checks[n].keyPath = String(t.keyPath) + "/" + String(t.key),
                        e(t.checks[n])
                    }
                } (t),
                {
                    checks: [t]
                }
            })
        }
        function p() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Ge("The requested scan type is not available");
            return function(r) {
                return 404 === r.status ? (r.errorMessage = t, r.config.noPublishError !== !0 && n.$emit("axError", r), e.reject(r)) : r
            }
        }
        this.createScanningProfile = o,
        this.deleteScanningProfile = s,
        this.getScanningProfile = c,
        this.getScanningProfiles = u,
        this.getWebScanningChecks = d,
        this.updateScanningProfile = l
    }
    function p(e, t, n, i, a, o, s) {
        function c(e, t) {
            return o.post("/scans/" + String(e) + "/abort", {},
            [204, 404], t).then(function(t) {
                return 404 === t.status ? null: u(e)
            })
        }
        function u(e, t) {
            return o.get("/scans/" + String(e), [200, 404], t).then(function(e) {
                var t = e.status,
                n = e.data;
                return 404 === t ? null: q(n)
            }).then(function(n) {
                return n && "failed" === r.get(n, "status") ? s.getEvents("type_id:411;resource_type:5;resource_id:" + String(e), void 0, 5, We(t)).then(function(e) {
                    var t = e.notifications;
                    if (t.length > 0) {
                        var i = t.find(function(e) {
                            return !! r.get(e, "eventData.extendedStatus.failReason")
                        });
                        i && (n.failReason = i.eventData.extendedStatus.failReason)
                    }
                    return n
                }) : n
            })
        }
        function l(e) {
            var t = e.status,
            n = e.nextRun,
            r = e.schedule,
            i = new Date,
            a = null;
            if ("continuous" === t) a = 6e4;
            else if ("processing" === t || "aborting" === t) a = 3e3;
            else if ("queued" === t) a = 5e3;
            else if ("starting" === t) a = 1e3;
            else if ("scheduled" === t) if (null === r.scheduleDate) a = 3e3;
            else {
                var o = Date.now(),
                s = r.recurrence && n ? n.getTime() : r.scheduleDate.getTime();
                a = s - o < 6e4 ? 3e3: ze(n, i) ? s - o > 36e5 ? 6e5: s - o <= 18e5 ? 5e3: 3e5: 18e5
            }
            return a
        }
        function d(e, t, n, i) {
            return o.get("/scans/" + String(e) + "/results", 200, Me({
                params: Ie(void 0, t, n)
            },
            i)).then(v()).then(function(e) {
                var t = M(r.get(e, "data.pagination", qe));
                return {
                    results: e.data.results.map(W),
                    pagination: t
                }
            })
        }
        function p(e, t, n, i) {
            return o.get("/scans", 200, Me({
                params: Ie(e, t, n)
            },
            i)).then(function(e) {
                return {
                    scans: r.get(e, "data.scans", []).map(q),
                    pagination: M(r.get(e, "data.pagination", qe))
                }
            })
        }
        function f(e, t) {
            t = Me({
                noLoadingTracker: !0,
                noPublishError: !0
            },
            t);
            var i = r.chain(e).map(function(e) {
                return {
                    scan: e,
                    nextRefreshIn: l(e)
                }
            }).filter(function(e) {
                var t = e.scan,
                n = e.nextRefreshIn;
                if (n) {
                    var r = t.$$lastRefreshTime;
                    if (r) {
                        return r + n < +new Date
                    }
                    return ! 0
                }
                return ! 1
            }).value();
            if (i.length > 0) {
                i.length > Ke && i.splice(Ke);
                var a = i.map(r.property("scan.scanId"));
                return p("scan_id:" + String(a.join(",")), void 0, void 0, t).then(function(t) {
                    var n = t.scans;
                    return n.forEach(function(t) {
                        var n = e.find(r.matchesProperty("scanId", t.scanId));
                        n && (je(n, t), n.$$lastRefreshTime = +new Date)
                    }),
                    n
                })
            }
            return n.when([])
        }
        function g(e, t) {
            return o.delete("/scans/" + String(e), 204, t).then(r.constant(null))
        }
        function h(n, s) {
            return o.post("/scans", e.invoke(Ce, void 0, {
                scanRequest: n
            }), 201, s).then(function(e) {
                var n = !!r.get(e, "data.ui_session_id", void 0);
                return t.get(e.headers("Location"), We(s)).then(y(200)).then(function(e) {
                    var t = q(e.data);
                    return i.$emit(a.API_EVENTS.SCAN_CREATED, {
                        scan: Ve(t),
                        actionRequired: n
                    }),
                    t
                })
            })
        }
        function m(t, n, r) {
            var i = n.schedule,
            a = {
                schedule: e.invoke(Ae, void 0, {
                    schedule: i
                })
            };
            return o.patch("/scans/" + String(t), a, 204, r).then(v()).then(function() {
                return u(t, We(r))
            })
        }
        function v() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Ge("The requested scan information is not available");
            return function(t) {
                return 404 === t.status ? (t.errorMessage = e, t.config.noPublishError !== !0 && i.$emit("axError", t), n.reject(t)) : t
            }
        }
        this.abortScan = c,
        this.getScan = u,
        this.getScanNextRefresh = l,
        this.getScanResultHistory = d,
        this.getScans = p,
        this.refreshScans = f,
        this.removeScan = g,
        this.scheduleScan = h,
        this.updateScan = m
    }
    function f(e, t, n) {
        function i(e) {
            return n.post("/enable_system_upgrade", {},
            204, e).then(function() {
                return o(We(e))
            }).then(function(e) {
                return e.updateInfo
            })
        }
        function a(e) {
            return n.get("/config", 200, e).then(function(e) {
                return ee(e.data)
            })
        }
        function o(r) {
            return n.get("/info", 200, r).then(function(e) {
                return te(e.data)
            }).then(function(n) {
                return e.$emit(t.API_EVENTS.SYSTEM_INFO_LOADED, {
                    sysInfo: n
                }),
                n
            })
        }
        function s(e, t) {
            return n.patch("/config", Re(e), 204, t).then(r.constant(null))
        }
        this.enableSystemUpgrade = i,
        this.getSystemConfig = a,
        this.getSystemInfo = o,
        this.updateConfiguration = s
    }
    function g(e, t, n, i, a) {
        function o(t, r, o) {
            return a.post("/target_groups", {
                name: t,
                description: r
            },
            201, o).then(function(t) {
                return e.get(t.headers("Location"), We(o))
            }).then(y(200)).then(function(e) {
                var t = re(e.data);
                return n.$emit(i.API_EVENTS.TARGET_GROUP_CREATED, {
                    group: Ve(t)
                }),
                t
            })
        }
        function s(e, t, n) {
            var i = t.add,
            o = void 0 === i ? [] : i,
            s = t.remove,
            c = void 0 === s ? [] : s;
            return a.patch("/target_groups/" + String(e) + "/targets", {
                add: o,
                remove: c
            },
            204, n).then(r.constant(null))
        }
        function c(e, t) {
            return a.delete("/target_groups/" + String(e), 204, t).then(function() {
                n.$emit(i.API_EVENTS.TARGET_GROUP_DELETED, {
                    groupId: e
                })
            }).then(r.constant(null))
        }
        function u(e, t) {
            return a.get("/target_groups/" + String(e), [200, 404], t).then(function(e) {
                var t = e.status,
                n = e.data;
                return 404 === t ? null: re(n)
            })
        }
        function l(e, t, n, i) {
            return a.get("/target_groups", 200, Me({
                params: Ie(e, t, n)
            },
            i)).then(function(e) {
                return {
                    groups: r.get(e, "data.groups", []).map(re),
                    pagination: M(r.get(e, "data.pagination", qe))
                }
            })
        }
        function d(e, t) {
            return a.get("/target_groups/" + String(e) + "/targets", 200, t).then(function(e) {
                return r.get(e, "data.target_id_list", [])
            })
        }
        function p(e, t, n) {
            return a.post("/target_groups/" + String(e) + "/targets", {
                target_id_list: t
            },
            204, n).then(r.constant(null))
        }
        function f(e, t) {
            var r = e.groupId,
            o = e.name,
            s = e.description;
            return a.patch("/target_groups/" + String(r), {
                name: o,
                description: s
            },
            204, t).then(g()).then(function() {
                return u(r, We(t))
            }).then(function(e) {
                return n.$emit(i.API_EVENTS.TARGET_GROUP_UPDATED, {
                    group: Ve(e)
                }),
                e
            })
        }
        function g() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Ge("The requested target information is not available");
            return function(r) {
                return 404 === r.status ? (r.errorMessage = e, r.config.noPublishError !== !0 && n.$emit("axError", r), t.reject(r)) : r
            }
        }
        this.addGroup = o,
        this.changeTargets = s,
        this.deleteGroup = c,
        this.getGroup = u,
        this.getGroups = l,
        this.listTargets = d,
        this.setTargets = p,
        this.updateGroup = f
    }
    function h(e, n, i, a, o, s) {
        function c(e, t, n) {
            return o.post("/targets/" + String(e) + "/allowed_hosts", {
                target_id: t
            },
            201, n).then(r.constant(null))
        }
        function u(t, n, r, c) {
            return s.hasFeature("target_business_criticality") !== !0 && (r = void 0),
            o.post("/targets", {
                address: t,
                description: n,
                criticality: r
            },
            201, c).then(function(t) {
                return e.get(t.headers("Location"), We(c))
            }).then(y(200)).then(function(e) {
                var t = ie(e.data);
                return i.$emit(a.API_EVENTS.TARGET_CREATED, {
                    target: Ve(t)
                }),
                t
            })
        }
        function l(e, t, n) {
            return o.patch("/targets/" + String(e) + "/configuration", Pe(t), 204, n).then(N()).then(function() {
                return _(e, We(n))
            })
        }
        function d(e, t) {
            return o.delete("/targets/" + String(e) + "/configuration/client_certificate", 204, t).then(r.constant(null))
        }
        function p(e, t, n) {
            return o.delete("/targets/" + String(e) + "/configuration/imports/" + String(t), 204, n).then(r.constant(null))
        }
        function f(e, t) {
            return o.delete("/targets/" + String(e) + "/configuration/login_sequence", 204, t).then(r.constant(null))
        }
        function g(e, n, i) {
            var a = Me({},
            {
                noAuthToken: !0
            },
            i);
            return He(n) && n.length > 0 && (n = t.MD5(n)),
            o.get("/targets/sensors/" + String(e) + "/" + String(n), 200, a).then(r.constant(null))
        }
        function h(e, t) {
            return o.get("/targets/" + String(e) + "/allowed_hosts", 200, t).then(function(e) {
                return {
                    hosts: r.get(e, "data.hosts", []).map(T)
                }
            })
        }
        function m(e, t) {
            return o.get("/targets/" + String(e) + "/configuration/client_certificate", [200, 404], t).then(function(e) {
                return 404 === e.status ? null: E(e.data)
            })
        }
        function v(e, t) {
            return o.get("/targets/" + String(e) + "/continuous_scan", 200, t).then(N()).then(function(e) {
                return e.data.enabled
            })
        }
        function S(e, t) {
            return o.get("/targets/" + String(e) + "/configuration/imports", [200, 404], t).then(function(e) {
                return 404 === e.status ? null: r.get(e, "data.files", []).map(E)
            })
        }
        function b(e, t) {
            return o.get("/targets/" + String(e) + "/configuration/login_sequence", [200, 404], t).then(function(e) {
                var t = e.status,
                n = e.data;
                return 404 === t ? null: E(n)
            })
        }
        function x(e, t) {
            return o.get("/targets/" + String(e), [200, 404], t).then(function(e) {
                var t = e.status,
                n = e.data;
                return 404 === t ? null: ie(n)
            })
        }
        function _(e, t) {
            return o.get("/targets/" + String(e) + "/configuration", 200, t).then(N()).then(function(e) {
                return ne(e.data)
            })
        }
        function C(e, t, n, i) {
            return o.get("/targets", 200, Me({
                params: Ie(e, t, n)
            },
            i)).then(function(e) {
                return {
                    targets: r.get(e, "data.targets", []).map(ie),
                    pagination: M(r.get(e, "data.pagination", qe))
                }
            })
        }
        function I(e, t, n, r) {
            return o.post("/targets/" + String(e) + "/configuration/imports", {
                name: t,
                size: n
            },
            201, r).then(N()).then(function(e) {
                return e.data.upload_url
            })
        }
        function w(e, t, n) {
            return o.delete("/targets/" + String(e) + "/allowed_hosts/" + String(t), 204, n).then(r.constant(null))
        }
        function k(e, t) {
            return o.delete("/targets/" + String(e), 204, t).then(function() {
                i.$emit(a.API_EVENTS.TARGET_DELETED, {
                    targetId: e
                })
            }).then(r.constant(null))
        }
        function A(e, t, n) {
            return o.post("/targets/" + String(e) + "/sensor/reset", {
                secret: t
            },
            200, n).then(N()).then(function(e) {
                return e.data.secret
            })
        }
        function L(e, t, n, r) {
            return o.post("/targets/" + String(e) + "/configuration/client_certificate", {
                name: t,
                size: n
            },
            200, r).then(N()).then(function(e) {
                return e.data.upload_url
            })
        }
        function $(e, t, n) {
            return o.post("/targets/" + String(e) + "/continuous_scan", {
                enabled: t
            },
            200, n).then(N()).then(function(t) {
                return i.$emit(a.API_EVENTS.TARGET_CONTINUOUS_SCAN_STATUS_CHANGED, {
                    targetId: e,
                    enabled: t
                }),
                t
            })
        }
        function R(e, t, n, r) {
            return o.post("/targets/" + String(e) + "/configuration/login_sequence", {
                name: t,
                size: n
            },
            200, r).then(N()).then(function(e) {
                return e.data.upload_url
            })
        }
        function P(e, t, n) {
            var r = t.description,
            c = t.criticality;
            return s.hasFeature("target_business_criticality") !== !0 && (c = void 0),
            o.patch("/targets/" + String(e), {
                description: r,
                criticality: c
            },
            204, n).then(N()).then(function() {
                return x(e, We(n))
            }).then(function(e) {
                return i.$emit(a.API_EVENTS.TARGET_UPDATED, {
                    target: Ve(e)
                }),
                e
            })
        }
        function N() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Ge("The requested target information is not available");
            return function(t) {
                return 404 === t.status ? (t.errorMessage = e, t.config.noPublishError !== !0 && i.$emit("axError", t), n.reject(t)) : t
            }
        }
        this.addAllowedHost = c,
        this.addTarget = u,
        this.configureTarget = l,
        this.deleteClientCertificate = d,
        this.deleteImportedFile = p,
        this.deleteLoginSequence = f,
        this.downloadSensor = g,
        this.getAllowedHosts = h,
        this.getClientCertificate = m,
        this.getContinuousScanStatus = v,
        this.getImportedFiles = S,
        this.getLoginSequence = b,
        this.getTarget = x,
        this.getTargetConfiguration = _,
        this.getTargets = C,
        this.importFile = I,
        this.removeAllowedHost = w,
        this.removeTarget = k,
        this.resetSensorSecret = A,
        this.setClientCertificate = L,
        this.setContinuousScanStatus = $,
        this.setLoginSequence = R,
        this.updateTarget = P
    }
    function m(e, t, n, i, a) {
        function o(e, t) {
            return a.put("/vulnerabilities/" + String(e) + "/issue", {},
            204, t).then(f()).then(r.constant(null))
        }
        function s(e, t, n, i) {
            return a.get("/vulnerabilities", 200, Me({
                params: Me(Ie(e, t, n))
            },
            i)).then(function(e) {
                return {
                    vulnerabilities: r.get(e, "data.vulnerabilities", []).map(pe),
                    pagination: M(r.get(e, "data.pagination", qe))
                }
            })
        }
        function c(t, n) {
            return a.get("/vulnerabilities/" + String(t), 200, n).then(f()).then(function(t) {
                var n = t.data;
                return e.invoke(de, void 0, {
                    dto: n
                })
            })
        }
        function u(e, t, n) {
            return a.put("/vulnerabilities/" + String(e) + "/status", {
                status: t
            },
            204, n).then(f()).then(r.constant(null))
        }
        function l(e, t) {
            return a.get("/vulnerability_types/" + String(e), 200, t).then(function(e) {
                var t = e.status,
                n = e.data;
                return 404 === t ? null: fe(n)
            })
        }
        function d() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "default",
            t = arguments[1],
            n = arguments[2],
            i = arguments[3],
            o = arguments[4],
            s = Me(Ie(t, n, i), {
                v: e
            });
            return a.get("/vulnerability_types", 200, Me({
                params: s
            },
            o)).then(function(e) {
                return {
                    vulnerabilityTypes: r.get(e, "data.vulnerability_types", []).map(le),
                    pagination: M(r.get(e, "data.pagination", qe))
                }
            })
        }
        function p(e, n) {
            return a.put("/vulnerabilities/" + String(e) + "/recheck", {},
            201, n).then(f()).then(function(e) {
                return t.get(e.headers("Location"), We(n))
            }).then(y(200)).then(function(e) {
                return q(e.data)
            })
        }
        function f() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Ge("The requested vulnerability information is not available");
            return function(t) {
                return 404 === t.status ? (t.errorMessage = e, t.config.noPublishError !== !0 && i.$emit("axError", t), n.reject(t)) : t
            }
        }
        this.createIssue = o,
        this.getVulnerabilities = s,
        this.getVulnerabilityDetails = c,
        this.setVulnerabilityStatus = u,
        this.getVulnerabilityType = l,
        this.getVulnerabilityTypes = d,
        this.recheckVulnerability = p
    }
    function v(e, t) {
        var n = this,
        r = function(n, r, i, a, o) {
            return e(Me({},
            o || {},
            {
                method: n,
                url: "" + String(t.API_BASE_PATH) + String(r),
                data: i
            })).then(y(a))
        }; ["get", "delete"].forEach(function(e) {
            return n[e] = function(t, n, i) {
                return r(e, t, void 0, n, i)
            }
        }),
        ["post", "put", "patch"].forEach(function(e) {
            return n[e] = function(t, n, i, a) {
                return r(e, t, n, i, a)
            }
        })
    }
    function y(e) {
        return function(t) {
            return Array.isArray(e) && e.indexOf(t.status) < 0 || Oe(e) && t.status,
            t
        }
    }
    function S(e) {
        if (Oe(e) && (e = e.toString()), /^[0-9]+$/.test(e)) {
            var t = parseInt("20" + e.substr(0, 2), 10),
            n = parseInt(e.substr(2, 3), 10),
            r = new Date(t, 0);
            return r = new Date(r.setDate(n))
        }
        return ""
    }
    function b(e, t, n) {
        var r = [e];
        return "-" !== t && r.push(t),
        "-" !== n && r.push(n),
        r.join(".")
    }
    function T(e) {
        return {
            targetId: e.target_id,
            address: e.address,
            description: e.description
        }
    }
    function x(e) {
        var t = {};
        return t.userId = e.user_id,
        t.accessAllGroups = e.access_all_groups,
        t.confirmationToken = e.confirmation_token,
        t.confirmed = e.confirmed,
        t.email = e.email,
        t.enabled = e.enabled,
        t.firstName = e.first_name,
        t.lastName = e.last_name,
        t.fullName = r.trim(String(e.first_name) + " " + String(e.last_name)),
        t.password = e.password === Qe ? Ze: "",
        t.role = e.role,
        t
    }
    function _(e) {
        var t = {};
        return t.locId = e.loc_id,
        t.name = Ye(e.name),
        t.path = Ye(e.path),
        t.isFile = "file" === e.loc_type,
        t.isFolder = "folder" === e.loc_type,
        t.isPort = "port" === e.loc_type,
        t.isIP = "ip" === e.loc_type,
        t.sourceId = e.source_id,
        t.parentId = e.parent_id,
        t.tags = Array.isArray(e.tags) ? e.tags: [],
        t
    }
    function C(e) {
        var t = {};
        return t.locId = e.loc_id,
        t.parentId = e.parent_id,
        t.sourceId = e.source_id,
        t.url = Ye(e.url),
        t.severityCounts = Z(e.severity_counts),
        t.threat = e.threat,
        t
    }
    function I(e) {
        var t = {};
        return t.cookie = e.cookie,
        t.url = e.url,
        t
    }
    function w(e) {
        var t = {};
        return e && (Object.keys(e).forEach(function(n) {
            var i = r.camelCase(n),
            a = e[n];
            t[i] = a && r.isPlainObject(a) ? w(a) : a
        }), Array.isArray(t.targetDesc) && 2 === t.targetDesc.length && (t.targetDesc = {
            address: t.targetDesc[0],
            description: t.targetDesc[1]
        })),
        t
    }
    function k(e) {
        var t = {};
        return t.name = e.name,
        t.excludedHoursId = e.excluded_hours_id ? e.excluded_hours_id: "",
        t.timeOffset = e.time_offset,
        t.exclusions = e.exclusion_matrix,
        t
    }
    function A(e) {
        var t = {};
        return t.reportId = e.report_id,
        t.source = {},
        e.source && (t.source.listType = e.source.list_type, t.source.idList = e.source.id_list),
        t.templateId = e.template_id,
        t.templateName = e.template_name,
        t.created = e.generation_date ? new Date(e.generation_date) : null,
        t.status = e.status,
        Array.isArray(e.download) && e.download.forEach(function(e) {
            r.endsWith(e, ".pdf") ? t.downloadLinkPDF = e: r.endsWith(e, ".pdf") ? t.downloadLinkHTML = e: r.endsWith(e, ".xml") && (t.downloadLinkXML = e)
        }),
        t
    }
    function L(e) {
        var t = {};
        return t.exportTypeId = e.export_id,
        t.name = e.name,
        t.contentType = e.content_type,
        t.acceptedSources = e.accepted_sources,
        t
    }
    function E(e) {
        var t = {};
        return t.uploadId = e.upload_id,
        t.name = e.name,
        t.totalBytes = e.size,
        t.uploadedBytes = e.current_size,
        t.status = e.status,
        t
    }
    function $(e) {
        var t = {};
        return t.waitingScans = e.scans_waiting_count,
        t.openVulns = e.vulnerabilities_open_count,
        t.runningScans = e.scans_running_count,
        t.totalScans = e.scans_conducted_count,
        t.totalTargets = e.targets_count,
        t.mostVulnerableTargets = e.most_vulnerable_targets.map(function(e) {
            return {
                address: e.address,
                targetId: e.target_id,
                criticality: e.criticality,
                highVulns: e.high_vuln_count,
                mediumVulns: e.med_vuln_count
            }
        }).slice(0, 5),
        t.vulnCount = function(e) {
            return {
                high: e.high,
                medium: e.med,
                low: e.low
            }
        } (e.vuln_count),
        t.topVulns = e.top_vulnerabilities.map(function(e) {
            return {
                name: e.name,
                vulnTypeId: e.vt_id,
                severity: e.severity,
                count: e.count
            }
        }).slice(0, 5),
        t.vulnCountByCriticality = function(e) {
            return ["critical", "high", "normal", "low"].reduce(function(t, n) {
                return t[n] = {
                    high: 0,
                    medium: 0,
                    low: 0
                },
                null != e[n] && [{
                    source: "high",
                    dest: "high"
                },
                {
                    source: "med",
                    dest: "medium"
                },
                {
                    source: "low",
                    dest: "low"
                }].forEach(function(r) {
                    t[n][r.dest] = 0,
                    Oe(e[n][r.source]) && (t[n][r.dest] = e[n][r.source])
                }),
                t
            },
            {})
        } (e.vuln_count_by_criticality),
        t
    }
    function R(e) {
        var t = {};
        return t.bugTracker = e.bug_tracker,
        t.url = e.url,
        t.project = e.project ? D(e.project) : null,
        t.issueType = e.issue_type ? N(e.issue_type) : null,
        e.auth && (t.auth = {},
        t.auth.kind = e.auth.kind, t.auth.username = e.auth.user, t.auth.password = e.auth.password),
        t
    }
    function P(e) {
        var t = {};
        return t.issueTrackerId = e.issue_tracker_id,
        t.name = e.name,
        Me(t, R(e)),
        t
    }
    function N(e) {
        var t = {};
        return t.issueTypeId = e.issue_id,
        t.issueTypeName = e.issue_name,
        t
    }
    function D(e) {
        var t = {};
        return t.projectId = e.project_id,
        t.projectName = e.project_name,
        t
    }
    function U(e) {
        var t = {};
        return t.uniqueKey = String(e.index) + ":" + String(e.scanning_app) + ":" + String(e.scan_session_id),
        t.targetId = e.target_id,
        t.targetAddress = r.get(e.target_desc, "[0]", ""),
        t.targetDescription = r.get(e.target_desc, "[1]", ""),
        t.scanId = e.scan_id,
        t.scanSessionId = e.scan_session_id,
        t.scanningApp = e.scanning_app,
        t.data = e.data,
        t.index = e.index,
        t.old = e.old,
        t
    }
    function V(e) {
        return {
            eventId: e.notification_id,
            consumed: e.consumed,
            resourceId: e.resource_id,
            resourceType: e.resource_type,
            eventTypeId: e.type_id,
            userId: e.user_id,
            email: e.email,
            eventData: w(e.data),
            created: new Date(e.created),
            severity: e.severity
        }
    }
    function M(e) {
        var t = {};
        return t.nextCursor = null !== e.next_cursor && void 0 !== e.next_cursor ? e.next_cursor: void 0,
        t.prevCursor = null !== e.previous_cursor && void 0 !== e.previous_cursor ? e.previous_cursor: void 0,
        t
    }
    function F(e) {
        return {
            userId: e.user_id,
            licenseType: e.license_type,
            isChildAccount: e.child_account,
            isSysAccount: e.su,
            email: e.email,
            companyName: e.company,
            companyWebsite: e.website,
            contactPhone: e.phone,
            countryCode: e.country,
            notifications: ue(e.notifications),
            firstName: e.first_name,
            lastName: e.last_name,
            role: e.role,
            accessAllGroups: e.access_all_groups,
            enabled: e.enabled
        }
    }
    function O(e) {
        var t = {};
        return t.enabled = !!e.enabled,
        t.enabled && (t.protocol = e.protocol, t.address = e.address, t.port = e.port, t.username = e.username, t.password = e.password),
        t
    }
    function H(e) {
        var t = {};
        return t.reportId = e.report_id,
        t.source = j(e.source),
        t.templateId = e.template_id,
        t.templateName = e.template_name,
        t.templateType = e.template_type,
        t.created = e.generation_date ? new Date(e.generation_date) : null,
        t.status = e.status,
        Array.isArray(e.download) && e.download.forEach(function(e) {
            r.endsWith(e, ".pdf") ? t.downloadLinkPDF = e: r.endsWith(e, ".html") && (t.downloadLinkHTML = e)
        }),
        t
    }
    function j(e) {
        var t = {};
        if (t.idList = e.id_list, t.listType = e.list_type, t.target = {
            address: Ge("N/A"),
            description: ""
        },
        e.description) {
            var n = e.description.indexOf(";");
            n > -1 ? (t.target = {},
            t.target.address = e.description.substr(0, n), t.target.description = e.description.substr(n + 1)) : "Multiple targets" === e.description && (t.target.address = Ge("Multiple Targets"))
        }
        if (e.description && (1 === t.idList.length && ("targets" === t.listType || "scans" === t.listType || "scan_result" === t.listType) || "vulnerabilities" === t.listType && "Multiple targets" !== e.description)) {
            var r = e.description.indexOf(";");
            r > -1 && (t.target = {},
            t.target.address = e.description.substr(0, r), t.target.description = e.description.substr(r + 1))
        }
        return t
    }
    function G(e) {
        var t = {};
        return t.templateId = e.template_id,
        t.name = e.name,
        t.group = e.group,
        t.comparison = "11111111-1111-1111-1111-111111111124" === e.template_id,
        t
    }
    function q(e) {
        var t = null;
        return e && (t = {},
        t.scanId = e.scan_id, t.schedule = B(e.schedule), t.status = "scheduled", t.resultId = null, t.severityCounts = null, t.lastRun = null, e.current_session && (t.status = e.current_session.status, t.running = Be.indexOf(e.current_session.status) > -1, t.resultId = e.current_session.scan_session_id, t.lastRun = e.current_session.start_date ? new Date(e.current_session.start_date) : null, t.severityCounts = Z(e.current_session.severity_counts), t.eventLevel = e.current_session.event_level), t.nextRun = !t.schedule.disabled && e.next_run ? new Date(e.next_run) : null, t.profile = {
            profileId: e.profile_id,
            name: e.profile_name
        },
        t.target = {},
        t.target.targetId = e.target_id, t.target.address = e.target.address, t.target.description = e.target.description, t.target.criticality = e.target.criticality, !t.schedule.disabled && t.schedule.recurrence && t.nextRun && "completed" === t.status && (t.originalStatus = "completed", t.status = "scheduled")),
        t
    }
    function B(e) {
        var t = n.axConversions.pyToRRULE(e.recurrence),
        r = {};
        return r.recurrence = e.recurrence,
        r.scheduleDate = t ? t.options.dtstart: e.start_date ? new Date(e.start_date) : null,
        r.timeSensitive = e.time_sensitive,
        r.disabled = e.disable,
        r
    }
    function K(e) {
        var t = {};
        return t.profileId = e.profile_id,
        t.name = e.name,
        t.sortOrder = e.sort_order,
        t.isCustom = e.custom,
        t.checks = Array.isArray(e.checks) ? e.checks: [],
        t
    }
    function W(e) {
        var t = {};
        return t.scanId = e.scan_id,
        t.resultId = e.result_id,
        t.startDate = e.start_date ? new Date(e.start_date) : null,
        t.endDate = e.end_date ? new Date(e.end_date) : null,
        t.status = e.status,
        t
    }
    function z(t) {
        var n = {};
        if (n.status = t.status, n.threatLevel = "-1", n.severityCounts = null, "failed" === n.status || "aborted" === n.status ? t.severity_counts && Oe(t.severity_counts.medium) && t.severity_counts.medium > 0 ? n.threatLevel = "2": t.severity_counts && Oe(t.severity_counts.high) && t.severity_counts.high > 0 ? n.threatLevel = "3": n.threatLevel = "-1": "completed" === n.status && (n.threatLevel = "0"), t.severity_counts && (n.severityCounts = function(e) {
            var t = e.high,
            r = e.medium,
            i = e.low,
            a = e.info;
            return null != t || null !== r && null != i || null != a ? (n.threatLevel = "0", i > 0 && (n.threatLevel = "1"), r > 0 && (n.threatLevel = "2"), t > 0 && (n.threatLevel = "3"), {
                high: ~~t,
                medium: ~~r,
                low: ~~i,
                info: ~~a
            }) : null
        } (t.severity_counts)), t.scanning_app && t.scanning_app.wvs) {
            var r = t.scanning_app.wvs;
            if (n.wvsScanStats = {
                status: r.status,
                abortRequested: r.abort_requested,
                startDate: r.start_date ? new Date(r.start_date) : null,
                endDate: r.end_date ? new Date(r.end_date) : null,
                hosts: [],
                vulns: [],
                activity: [],
                allowedHosts: []
            },
            r.hosts && (e.forEach(r.hosts,
            function(e, t) {
                var r = {
                    targetId: t,
                    address: e.host,
                    isStartingHost: e.is_starting_host
                };
                e.target_info && (r.osName = e.target_info.os, r.technologies = e.target_info.technologies, r.responsive = e.target_info.responsive, r.serverName = e.target_info.server, r.sensorDetected = "boolean" == typeof e.target_info.sensor_detected ? e.target_info.sensor_detected: null),
                e.web_scan_status && (r.locations = e.web_scan_status.locations, r.avgResponseTime = e.web_scan_status.avg_response_time, r.maxResponseTime = e.web_scan_status.max_response_time, r.requestCount = e.web_scan_status.request_count),
                e.external_hosts && (r.externalHosts = e.external_hosts.sort(function(e, t) {
                    var n = e.replace(/^https?:\/\//i, ""),
                    r = t.replace(/^https?:\/\//i, "");
                    return n.localeCompare(r)
                })),
                n.wvsScanStats.hosts.push(r),
                r.isStartingHost && (n.wvsScanStats.startingHost = r)
            }), n.wvsScanStats.hosts.sort(function(e) {
                return e.is_starting_host ? -1 : 1
            })), r.main) {
                var i = r.main;
                if (i) {
                    if (n.wvsScanStats.duration = i.duration, n.wvsScanStats.progress = i.progress, i.web_scan_status) {
                        var a = i.web_scan_status;
                        n.wvsScanStats.locations = a.locations,
                        n.wvsScanStats.avgResponseTime = a.avg_response_time,
                        n.wvsScanStats.maxResponseTime = a.max_response_time,
                        n.wvsScanStats.requestCount = a.request_count
                    }
                    Array.isArray(i.vulns) && (n.wvsScanStats.vulns = i.vulns.map(function(e) {
                        return {
                            vulnId: e.vuln_id,
                            severity: e.severity,
                            name: e.name,
                            timestamp: new Date(e.time),
                            target: {
                                targetId: e.target_info.target_id,
                                address: e.target_info.host
                            }
                        }
                    }), n.wvsScanStats.vulns.sort(function(e, t) {
                        return e.timestamp.getTime() - t.timestamp.getTime()
                    })),
                    Array.isArray(i.messages) && (n.wvsScanStats.activity = i.messages.map(function(t) {
                        var n = "";
                        if (t.target_info.host) switch (t.kind) {
                        case "scanning":
                            n = "Scanning of " + String(t.target_info.host) + " started";
                            break;
                        case "finished":
                            n = "Scanning of " + String(t.target_info.host) + " completed";
                            break;
                        case "aborted":
                            n = "Scanning of " + String(t.target_info.host) + " was aborted",
                            "nonresponsive" === t.data ? n += " (target was not responsive)": "network" === t.data && (n += " (network error)");
                            break;
                        case "deep_scan":
                            n = "Deep scan of " + String(t.target_info.host) + " started";
                            break;
                        case "crawling":
                            n = "Crawling of " + String(t.target_info.host) + " started";
                            break;
                        case "crawl_memlimit":
                            n = "Crawler memory limit reached for " + String(t.target_info.host);
                            break;
                        case "al_error":
                            n = "Automatic login failed for " + String(t.target_info.host);
                            break;
                        case "au_error":
                            n = "HTTP Authentication error for " + String(t.target_info.host);
                            break;
                        case "ls_error":
                            n = "The login sequence for " + String(t.target_info.host) + " is invalid";
                            break;
                        case "no_sensor":
                            n = "AcuSensor was not detected on " + String(t.target_info.host);
                            break;
                        case "sensor":
                            n = "AcuSensor detected on " + String(t.target_info.host);
                            break;
                        case "manual_browsing":
                            n = "Manual intervention required for " + String(t.target_info.host);
                            break;
                        case "scan_resumed":
                            n = "Scanning has resumed"
                        }
                        return "" === n && (n = e.uppercase(t.kind[0]) + t.kind.substr(1)),
                        {
                            timestamp: new Date(t.time),
                            message: n,
                            target: {
                                targetId: t.target_id,
                                address: t.host
                            },
                            level: t.level,
                            data: t.data
                        }
                    }), n.wvsScanStats.activity.sort(function(e, t) {
                        return e.timestamp.getTime() - t.timestamp.getTime()
                    }))
                }
            }
        }
        return n
    }
    function Y(e) {
        var t = {};
        return Me(t, fe(e)),
        t.count = e.count,
        t
    }
    function Z(e) {
        var t = null;
        return e && (t = {},
        t.high = e.high, t.medium = e.medium, t.low = e.low, t.info = e.info),
        t
    }
    function Q(e) {
        var t = {};
        return t.kind = e.kind,
        "automatic" === t.kind && (t.credentials = ce(e.credentials)),
        t
    }
    function X(e) {
        var t = {};
        return t.address = e.address,
        t.port = e.port,
        t.security = e.security,
        t.username = e.username,
        t.password = e.password,
        t.fromAddress = e.from_address,
        t
    }
    function J(e) {
        var t = {};
        return t.kind = e.kind,
        "none" !== t.kind && (t.port = e.port, t.username = e.username, t.sshKey = e.ssh_key, t.keyPassword = e.key_password),
        t
    }
    function ee(e) {
        var t = {};
        return t.updateMode = e.updates,
        t.notifications = e.notifications ? X(e.notifications) : null,
        t.proxy = e.proxy ? O(e.proxy) : null,
        t.excludedHoursId = e.excluded_hours_id,
        t
    }
    function te(e) {
        return {
            buildNumber: e.build_number,
            minorVersion: e.minor_version,
            majorVersion: e.major_version,
            versionFull: b(e.major_version, e.minor_version, e.build_number),
            buildDate: S(e.build_number),
            // TODO: Return null for this key if license_key is not set (no license entered)
            license: {
                activated: e.license.activated,
                email: e.license.email,
                licenseKey: e.license.license_key,
                productCode: e.license.product_code,
                expired: e.license.expired,
                features: Array.isArray(e.license.features) ? e.license.features.sort() : [],
                limits: {
                    maxEngines: null == e.license.limits.max_engines ? void 0 : e.license.limits.max_engines,
                    maxScansPerEngine: null == e.license.limits.max_scans_per_engine ? void 0 : e.license.limits.max_scans_per_engine,
                    maxUsers: null == e.license.limits.max_users ? void 0 : e.license.limits.max_users
                },
                status: Ge(e.license.expired ? "License Expired": e.license.activated ? "已激活": "没有激活"),
                expires: e.license.expires ? new Date(e.license.expires) : null,
                maintenance: {
                    expired: e.license.maintenance_expired,
                    expires: He(e.license.maintenance_expires) ? new Date(e.license.maintenance_expires) : null
                }
            },
            updateInfo: oe(e.update_info)
        }
    }
    function ne(e) {
        var t = {};
        return t.issueTrackerId = r.defaultTo(e.issue_tracker_id, ""),
        t.limitCrawlerScope = e.limit_crawler_scope,
        t.login = Q(e.login),
        t.sensor = e.sensor,
        t.sensorSecret = e.sensor_secret,
        t.sshCredentials = J(e.ssh_credentials),
        t.proxy = e.proxy ? O(e.proxy) : null,
        t.authentication = ce(e.authentication),
        t.clientCertificatePassword = e.client_certificate_password,
        t.scanSpeed = e.scan_speed,
        t.caseSensitive = e.case_sensitive,
        t.technologies = Array.isArray(e.technologies) ? e.technologies: [],
        t.customHeaders = Array.isArray(e.custom_headers) ? e.custom_headers: [],
        t.customCookies = Array.isArray(e.custom_cookies) ? e.custom_cookies.map(I) : [],
        t.excludedPaths = Array.isArray(e.excluded_paths) ? e.excluded_paths: [],
        t.userAgent = e.user_agent,
        t.debug = e.debug,
        t.excludedHoursId = e.excluded_hours_id ? e.excluded_hours_id: "",
        t
    }
    function re(e) {
        var t = {};
        return t.groupId = e.group_id,
        t.name = e.name,
        t.description = e.description,
        t.targetCount = e.target_count,
        t
    }
    function ie(e) {
        var t = {};
        return t.targetId = e.target_id,
        t.address = e.address,
        t.criticality = e.criticality,
        t.description = e.description,
        t.threat = e.threat,
        t.continuousMode = e.continuous_mode,
        t.lastScanId = e.last_scan_id,
        t.lastScanDate = e.last_scan_date ? new Date(e.last_scan_date) : null,
        t.lastScanStatus = e.last_scan_session_status,
        t.lastScanResultId = e.last_scan_session_id,
        t.severityCounts = Z(e.severity_counts),
        t.scansRequireMI = e.manual_intervention,
        e.scan_authorization && (t.scanAuthorization = {},
        t.scanAuthorization.content = e.scan_authorization.url, t.scanAuthorization.url = e.scan_authorization.url),
        Array.isArray(e.links) && (t.links = e.links.map(function(e) {
            var t = e.href,
            n = e.rel;
            return {
                href: t,
                rel: n
            }
        })),
        t
    }
    function ae(e) {
        var t = {};
        return t.trendOpenVulns = e.open_vulns_trending.map(function(e) {
            return {
                highVulns: e.high_vulns,
                mediumVulns: e.med_vulns,
                startDate: new Date(e.start_date),
                endDate: new Date(e.end_date)
            }
        }),
        t.trendAverageVulnAge = e.average_vuln_age_trending.map(function(e) {
            return {
                averageDays: e.average_days,
                daysHighVulns: e.high_vuln_days,
                daysMediumVulns: e.med_vuln_days,
                startDate: new Date(e.start_date),
                endDate: new Date(e.end_date)
            }
        }),
        t.trendNewVulns = e.new_vulns_trending.map(function(e) {
            return {
                highVulns: e.high_vulns,
                mediumVulns: e.med_vulns,
                weightedVulns: e.weighted_vulns,
                startDate: new Date(e.start_date),
                endDate: new Date(e.end_date)
            }
        }),
        t.trendAverageRemediationTime = e.average_remediation_time.map(function(e) {
            return {
                fixedHighVulns: e.vuln_fixed_high,
                fixedMediumVulns: e.vuln_fixed_med,
                daysHighVulns: e.high_vuln_days,
                daysMediumVulns: e.med_vuln_days,
                startDate: new Date(e.start_date),
                endDate: new Date(e.end_date),
                averageDays: e.average_days
            }
        }),
        t
    }
    function oe(e) {
        var t = {};
        return t.buildNumber = e.build_number.toString(),
        t.minorVersion = e.minor_version,
        t.majorVersion = e.major_version,
        t.available = e.new_update,
        t.status = e.update_status,
        t.versionFull = b(e.major_version, e.minor_version, e.build_number),
        t.buildDate = S(e.build_number.toString()),
        t
    }
    function se(e) {
        var t = {};
        return t.accessAllGroups = e.access_all_groups,
        t.groups = e.group_id_list,
        t
    }
    function ce(e) {
        var t = {};
        return t.enabled = e.enabled,
        t.enabled && (t.username = e.username, t.password = e.password),
        t
    }
    function ue(e) {
        var t = {};
        return t.monthlyStatus = r.get(e, "monthly_status", !1),
        t.scans = r.get(e, "scans", !1),
        t.updates = r.get(e, "updates", !1),
        t
    }
    function le(e) {
        var t = {};
        return Me(t, fe(e)),
        t.count = e.count,
        t.criticality = e.criticality,
        t
    }
    function de(e, t, n) {
        var r = {};
        return Me(r, pe(n)),
        r.description = n.description,
        r.cvss2 = n.cvss2,
        r.cvss3 = n.cvss3,
        r.cvssScore = n.cvss_score,
        r.impact = n.impact,
        r.recommendation = n.recommendation,
        r.longDescription = n.long_description,
        r.references = Array.isArray(n.references) ? n.references: [],
        r.details = n.details,
        r.request = n.request ? n.request.replace(/\r\n/g, "\n") : "",
        r.classification = function(r) {
            var i = r.getCVSSLink,
            a = r.getCVSSMetrics,
            o = {
                cve: e(t.extractCVE(n.tags),
                function(e) {
                    return 1e7 * parseInt(e.substr(0, 4), 10) + parseInt(e.substr(5))
                },
                !0),
                cwe: e(t.extractCWE(n.tags),
                function(e) {
                    return parseInt(e, 10)
                })
            };
            return n.cvss3 ? o.cvss = {
                version: 3,
                vector: n.cvss3,
                vectorLink: i(n.cvss3, "3"),
                score: n.cvss_score,
                metrics: a(n.cvss3, "3")
            }: n.cvss2 && (o.cvss = {
                version: 2,
                vector: n.cvss2,
                vectorLink: i(n.cvss2, "2"),
                score: n.cvss_score,
                metrics: a(n.cvss2, "2")
            }),
            o
        } (t),
        r
    }
    function pe(e) {
        var t = {};
        return t.status = e.status,
        t.targetDescription = e.target_description,
        t.vulnId = e.vuln_id,
        t.issueId = e.issue_id,
        t.name = e.vt_name,
        t.criticality = e.criticality,
        t.vtId = e.vt_id,
        t.parameter = e.affects_detail,
        t.url = Ye(e.affects_url),
        t.source = e.source,
        t.locId = e.loc_id,
        t.targetId = e.target_id,
        t.firstSeen = e.first_seen ? new Date(e.first_seen) : null,
        t.lastSeen = e.last_seen ? new Date(e.last_seen) : null,
        t.severity = e.severity,
        t.tags = Array.isArray(e.tags) ? e.tags: [],
        t.continuous = e.continuous,
        t
    }
    function fe(e) {
        var t = {};
        return t.vulnTypeId = e.vt_id,
        t.name = e.name,
        t.severity = e.severity,
        t.tags = Array.isArray(e.tags) ? e.tags: [],
        t.cvss2 = e.cvss2,
        t.cvss3 = e.cvss3,
        t
    }
    function ge(e) {
        var n = {};
        return n.email = e.email,
        n.first_name = e.firstName,
        n.last_name = e.lastName,
        n.role = e.role,
        n.enabled = e.enabled,
        n.access_all_groups = e.accessAllGroups,
        e.password === Qe || (n.password = e.password && e.password !== Ze ? t.SHA256(e.password).toString() : void 0),
        n
    }
    function he(e) {
        var n = {};
        return n.email = e.email,
        n.password = t.SHA256(e.password).toString(),
        n.access_all_groups = e.accessAllGroups,
        n.first_name = e.firstName,
        n.last_name = e.lastName,
        n.role = e.role,
        n
    }
    function me(e) {
        var t = {};
        return t.excluded_hours_id = e.excludedHoursId,
        t.name = e.name,
        t.time_offset = e.timeOffset,
        t.exclusion_matrix = e.exclusions,
        t
    }
    function ve(e) {
        var t = {},
        n = ye(e),
        r = Te(e.project),
        i = null != e.issueType ? be(e.issueType) : void 0;
        return Me(t, n),
        t.project = r,
        t.issue_type = i,
        t
    }
    function ye(e) {
        var t = {};
        return e && (t.bug_tracker = e.bugTracker, t.url = e.url, e.auth && (t.auth = {},
        t.auth.kind = e.auth.kind, t.auth.user = e.auth.username, t.auth.password = e.auth.password)),
        t
    }
    function Se(e) {
        var t = {};
        return t.name = e.name,
        Me(t, ve(e)),
        t
    }
    function be(e) {
        var t = {};
        return t.issue_id = e.issueTypeId,
        t.issue_name = e.issueTypeName,
        t
    }
    function Te(e) {
        var t = {};
        return t.project_id = e.projectId,
        t.project_name = e.projectName,
        t
    }
    function xe(e, t) {
        var n = {};
        return n.export_id = e,
        n.source = {},
        n.source.list_type = t.listType,
        Array.isArray(t.idList) && t.idList.length > 0 && (n.source.id_list = t.idList),
        n
    }
    function _e(e, t) {
        var n = {};
        return n.template_id = e,
        n.source = {},
        n.source.list_type = t.listType,
        Array.isArray(t.idList) && t.idList.length > 0 && (n.source.id_list = t.idList),
        n
    }
    function Ce(e, t) {
        var n = e.get("AccountApi"),
        r = {};
        return r.target_id = t.targetId,
        r.profile_id = t.profileId,
        r.report_template_id = t.reportTemplateId,
        r.schedule = e.invoke(Ae, void 0, {
            schedule: t.schedule
        }),
        r.ui_session_id = n.getBSIDValue(),
        r
    }
    function Ie(e, t, n) {
        var r = {};
        return He(e) && e.length > 0 && (r.q = e),
        null !== n && void 0 !== n && (r.l = n),
        null !== t && void 0 !== t && (r.c = t),
        r
    }
    function we(e) {
        var t = {};
        return t.email = e.email,
        t.first_name = e.firstName,
        t.last_name = e.lastName,
        t.company = e.companyName,
        t.website = e.companyWebsite,
        t.phone = e.contactPhone,
        t.country = e.countryCode,
        t.notifications = e.notifications ? Ue(e.notifications) : void 0,
        t
    }
    function ke(e) {
        var t = {
            enabled: r.get(e, "enabled", !1)
        };
        return t.enabled && (t.address = e.address, t.protocol = e.protocol, t.port = parseInt(e.port, 10), e.username && (t.username = e.username, t.password = e.password)),
        t
    }
    function Ae(e, t) {
        var n = {};
        return n.disable = t.disabled,
        n.recurrence = t.recurrence,
        n.start_date = t.recurrence ? void 0 : e(t.scheduleDate, "yyyyMMddTHHmmssZ"),
        n.time_sensitive = t.timeSensitive,
        n
    }
    function Le(e) {
        var t = {};
        return t.profile_id = e.profileId,
        t.name = e.name,
        t.sort_order = e.sortOrder,
        t.custom = e.isCustom,
        t.checks = e.checks,
        t
    }
    function Ee(e) {
        var t = {};
        return t.kind = e.kind,
        "automatic" === e.kind && (t.credentials = De(e.credentials)),
        t
    }
    function $e(e) {
        var t = {};
        return t.kind = e.kind,
        "key" === e.kind && (t.port = e.port, t.username = e.username, t.ssh_key = e.sshKey, t.key_password = e.keyPassword),
        t
    }
    function Re(e) {
        var t = {};
        return Fe(e.notifications) && (null !== e.notifications ? (t.notifications = {
            address: e.notifications.address,
            port: e.notifications.port,
            security: e.notifications.security,
            from_address: e.notifications.fromAddress
        },
        e.notifications.username && (t.notifications.username = e.notifications.username, t.notifications.password = e.notifications.password)) : t.notifications = null),
        Fe(e.proxy) && (null !== e.proxy ? (t.proxy = {
            protocol: e.proxy.protocol,
            enabled: !1
        },
        "none" !== e.proxy.protocol && (t.proxy.enabled = !0, t.proxy.address = e.proxy.address, t.proxy.port = e.proxy.port, e.proxy.username && (t.proxy.username = e.proxy.username, t.proxy.password = e.proxy.password))) : t.proxy = null),
        Fe(e.updates) && (t.updates = e.updates),
        Fe(e.excludedHoursId) && (t.excluded_hours_id = e.excludedHoursId),
        t
    }
    function Pe(e) {
        var t = {},
        n = e.issueTrackerId,
        r = e.limitCrawlerScope,
        i = e.login,
        a = e.sensor,
        o = e.sensorSecret,
        s = e.sshCredentials,
        c = e.proxy,
        u = e.authentication,
        l = e.clientCertificatePassword,
        d = e.scanSpeed,
        p = e.caseSensitive,
        f = e.technologies,
        g = e.customHeaders,
        h = e.customCookies,
        m = e.excludedPaths,
        v = e.userAgent,
        y = e.debug,
        S = e.excludedHoursId;
        return Fe(n) && (t.issue_tracker_id = n),
        Fe(r) && (t.limit_crawler_scope = r),
        Fe(i) && (t.login = Ee(i)),
        Fe(a) && (t.sensor = a),
        Fe(o) && (t.sensor_secret = o),
        Fe(s) && (t.ssh_credentials = $e(s)),
        Fe(c) && (t.proxy = ke(c)),
        Fe(e.authentication) && (t.authentication = De(u)),
        Fe(l) && (t.client_certificate_password = l),
        Fe(d) && (t.scan_speed = d),
        Fe(p) && (t.case_sensitive = p),
        Fe(f) && (t.technologies = f),
        Fe(g) && (t.custom_headers = g),
        Fe(h) && (t.custom_cookies = h),
        Fe(m) && (t.excluded_paths = m),
        Fe(v) && (t.user_agent = v),
        Fe(y) && (t.debug = y),
        Fe(S) && (t.excluded_hours_id = null === S ? "": S),
        t
    }
    function Ne(e) {
        var t = {};
        return t.access_all_groups = e.accessAllGroups,
        t.group_id_list = e.groups,
        t
    }
    function De(e) {
        var t = {};
        return t.enabled = e.enabled,
        e.enabled && (t.username = e.username, t.password = e.password),
        t
    }
    function Ue(e) {
        var t = {};
        return t.monthly_status = e.monthlyStatus,
        t.scans = e.scans,
        t.updates = e.updates,
        t
    }
    i.$inject = ["$interval", "$q", "$rootScope", "$timeout", "axConstant", "axUserPreferences", "ApiHttp", "CurrentUser", "SystemConfigApi"],
    a.$inject = ["$http", "$q", "$rootScope", "ApiHttp"],
    o.$inject = ["$http", "$q", "$rootScope", "ApiHttp"],
    s.$inject = ["$http", "$rootScope", "ApiHttp", "axConstant"],
    c.$inject = ["ApiHttp"],
    u.$inject = ["$q", "$http", "$rootScope", "orderByFilter", "ApiHttp", "axExportTemplatesCache", "axReportTemplatesCache"],
    l.$inject = ["$injector", "$http", "$q", "$rootScope", "ApiHttp"],
    d.$inject = ["$q", "$http", "$rootScope", "orderByFilter", "ApiHttp"],
    p.$inject = ["$injector", "$http", "$q", "$rootScope", "axConstant", "ApiHttp", "NotificationsApi"],
    f.$inject = ["$rootScope", "axConstant", "ApiHttp"],
    g.$inject = ["$http", "$q", "$rootScope", "axConstant", "ApiHttp"],
    h.$inject = ["$http", "$q", "$rootScope", "axConstant", "ApiHttp", "CurrentUser"],
    m.$inject = ["$injector", "$http", "$q", "$rootScope", "ApiHttp"],
    v.$inject = ["$http", "axConstant"],
    de.$inject = ["orderByFilter", "axVulnClassification", "dto"],
    Ce.$inject = ["$injector", "scanRequest"],
    Ae.$inject = ["dateFilter", "schedule"];
    var Ve = e.copy,
    Me = e.extend,
    Fe = e.isDefined,
    Oe = e.isNumber,
    He = e.isString,
    je = e.merge,
    Ge = e.identity,
    qe = Object.freeze({
        next_cursor: null,
        previous_cursor: null
    }),
    Be = ["processing", "aborting"],
    Ke = 25,
    We = function(e) {
        return e ? r.pick(e, ["noPublishError", "noLoadingTracker", "formatError"]) : {}
    },
    ze = function(e, t) {
        return e.toDateString() === t.toDateString()
    },
    Ye = function(e) {
        try {
            return decodeURIComponent(e)
        } catch(t) {
            return e
        }
    },
    Ze = "hIpA2ksAW30abA!",
    Qe = "password set";
    e.module("WVS").service({
        AccountApi: i,
        ApiHttp: v,
        ChildUsersApi: a,
        ExcludedHoursApi: o,
        IssueTrackersApi: s,
        NotificationsApi: c,
        ReportsApi: u,
        ResultsApi: l,
        ScannerApi: d,
        ScansApi: p,
        SystemConfigApi: f,
        TargetGroupsApi: g,
        TargetsApi: h,
        VulnerabilitiesApi: m
    })
} (angular, CryptoJS, RRule, _),
/**
 * @name LicenseInfoDTO
 *
 * @property {string} license_key
 * @property {string} email
 * @property {string} product_code
 * @property {string} expires
 * @property {boolean} expired
 * @property {boolean} activated
 * @property {Array.<string>} features See {@link LicenseInfo.FeaturesEnum}
 * @property {LicenseInfoLimitsDTO} limits
 * @property {boolean} maintenance_expired
 * @property {string} maintenance_expires
 */
/**
 * @name LicenseInfoDTO.FeaturesEnum
 * @enum
 *
 * @property {string} target_groups
 * @property {string} export_waf
 * @property {string} target_business_criticality
 * @property {string} multi_user
 * @property {string} continuous_scans
 * @property {string} trending_graphs
 * @property {string} bug_tracking_integration
 */
/**
 * @name LicenseInfoLimitsDTO
 *
 * @property {number} max_engines
 * @property {number} max_scans_per_engine
 * @property {number} max_users
 */
/**
 * @name SystemInfoDTO
 *
 * @property {LicenseInfoDTO} license
 * @property {UpdateInfoDTO} update_info
 * @property {string} build_number
 * @property {string} minor_version
 * @property {string} major_version
 */
/**
 * @name UserProfileDTO
 *
 * @property {string} user_id
 * @property {string} license_type See {@link UserProfileDTO.LicenseTypeEnum}
 * @property {boolean} child_account
 * @property {boolean} su Whether or not the user is a system account
 * @property {string} email
 * @property {string} company
 * @property {string} website
 * @property {string} phone
 * @property {string} country See {@link UserProfileDTO.CountryEnum}
 * @property {UserEmailNotificationsDTO} notifications
 * @property {string} first_name
 * @property {string} last_name
 * @property {string} role See {@link UserProfileDTO.RoleEnum}
 * @property {boolean} access_all_groups
 * @property {boolean} enabled
 */
/**
 * @name UserProfileDTO.LicenseTypeEnum
 * @enum
 *
 * @property {string} trial
 * @property {string} customer
 * @property {string} demo
 */
/**
 * @name LicenseInfo
 *
 * @property {boolean} activated
 * @property {string} email
 * @property {boolean} expired
 * @property {string} licenseKey
 * @property {boolean} expires
 * @property {string} productCode
 * @property {Array.<string>} features
 * @property {LicenseInfoLimits} limits
 * @property {boolean} noLimits
 * @property {string} status
 * @property {LicenseMaintenaceInfo} maintenance
 */
/**
 * @name LicenseInfoLimits
 *
 * @property {number} maxEngines
 * @property {number} maxScansPerEngine
 * @property {number} maxUsers
 */
/**
 * @name LicenseMaintenaceInfo
 *
 * @property {boolean} expired
 * @property {Date} expires
 */
/**
 * @name SystemInfo
 *
 * @property {LicenseInfo} license
 * @property {UpdateInfo} updateInfo
 * @property {string} buildNumber
 * @property {Date} buildDate
 * @property {string} minorVersion
 * @property {string} majorVersion
 * @property {string} versionFull
 */
/**
 * @name UserProfile
 *
 * @property {string} userId
 * @property {string} licenseType See {@link UserProfileDTO.LicenseTypeEnum}
 * @property {boolean} isChildAccount
 * @property {boolean} isSysAccount
 * @property {string} email
 * @property {string} companyName
 * @property {string} companyWebsite
 * @property {string} contactPhone
 * @property {string} countryCode See {@link UserProfileDTO.CountryEnum}
 * @property {UserEmailNotifications} notifications
 * @property {string} firstName
 * @property {string} lastName
 * @property {string} role See {@link UserProfileDTO.RoleEnum}
 * @property {boolean} accessAllGroups
 * @property {boolean} enabled
 */
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u, l, d, p, f, g, h, m, v, y, S, b, T, x, _) {
        function C() {
            var e = n.reportList.gridApi && n.reportList.gridApi.selection;
            return e ? e.getSelectedRows() : []
        }
        function I() {
            var e = n.reportList.gridApi && n.reportList.gridApi.selection;
            return e ? e.getSelectedCount() : 0
        }
        function w() {
            n.filterAsideVisible = !n.filterAsideVisible
        }
        function k(e) {
            var t = n.searchFilters;
            switch (t.filterTags.splice(t.filterTags.indexOf(e), 1), e.key) {
            case "status":
                t.status = [];
                break;
            case "created":
            case "created_start":
            case "created_end":
                t.createdStartDate = null,
                t.createdEndDate = null;
                break;
            case "source":
                t.reportSource = null;
                break;
            case "template":
                t.reportTemplate = null
            }
            G()
        }
        function A(e) {
            "all_vulnerabilities" === e && n.pageState.noTargetsInSystem || y.chooseReportOptions().then(function(t) {
                return L(t.templateId, e)
            })
        }
        function L(e, t) {
            return v.generateNewReport(e, {
                listType: t
            },
            {
                tracker: n.loadingTracker,
                onRetry: function() {
                    function n() {
                        return L(e, t)
                    }
                    return n
                } ()
            }).then(function() {
                f.success(d.getString("您的报告已生成"))
            }).then(W)
        }
        function E() {
            var t = e.extend(n.$new(), {
                message: d.getPlural(I(), l("您确定要删除所选报告吗？"), l("您确定要删除所选报告吗？"))
            });
            return _.confirm({
                scope: t
            }).then($).then(z).
            finally(function() {
                return t.$destroy()
            })
        }
        function $() {
            var e = n.loadingTracker.createPromise(),
            t = 0;
            return C().reduce(function(e, r) {
                return e.then(function() {
                    return v.removeReport(r.reportId)
                }).then(function() {
                    n.reportList.gridApi.selection.unSelectRow(r),
                    n.reportList.items.splice(n.reportList.items.indexOf(r), 1),
                    t++
                })
            },
            o.when()).then(function() {
                if (void 0 !== n.reportList.nextCursor && t > 0) return D({
                    limit: t
                })
            }).
            finally(e.resolve)
        }
        function R() {
            return g.currentUrlEncoded()
        }
        function P() {
            return S.addTarget().then(function(e) {
                s.go("app.target_config", {
                    returnUrl: R(),
                    targetId: e.targetId
                },
                {
                    inherit: !1
                })
            })
        }
        function N() {
            if (Y) try {
                a.cancel(Y)
            } finally {
                Y = null
            }
            n.loadingTracker.cancel()
        }
        function D(t) {
            var r = n.loadingTracker.createPromise();
            return o.when().then(function() {
                n.reportList.gridApi.infiniteScroll.saveScrollPercentage()
            }).then(function() {
                var e = t ? t.limit: m.LIST_PAGE_SIZE;
                return v.getReports(O(), n.reportList.nextCursor, e, {
                    onRetry: function() {
                        function e() {
                            return D(t)
                        }
                        return e
                    } ()
                })
            }).then(function(t) {
                var r = t.reports,
                i = t.pagination;
                r.forEach(function(e) {
                    n.reportList.items.find(function(t) {
                        return t.reportId === e.reportId
                    }) || n.reportList.items.push(e)
                }),
                n.reportList.nextCursor = i.nextCursor,
                n.reportList.gridApi.infiniteScroll.dataLoaded(!1, e.isDefined(i.nextCursor))
            }).
            catch(function(e) {
                return n.reportList.gridApi.infiniteScroll.dataLoaded(!1, !1),
                o.reject(e)
            }).
            finally(r.resolve)
        }
        function U() {
            var e = n.loadingTracker.createPromise();
            return v.getReportTemplates({
                onRetry: function() {
                    function e() {
                        return U()
                    }
                    return e
                } ()
            }).then(function(e) {
                n.searchFilters.reportTemplateList = e,
                n.searchFilters.reportTemplate = h.getStateParam("template", !1, t.map(e, t.property("templateId"))),
                j()
            }).
            finally(e.resolve)
        }
        function V(e, t) {
            t !== e && (W(), j(), G())
        }
        function M(e, t) {
            e === t || Q || s.reload(s.current)
        }
        function F() {
            return Z ? o.when() : (Z = !0, o.when().then(function() {
                var t = o.defer(),
                r = n.$on("$destroy",
                function() {
                    return t.resolve()
                }),
                a = n.reportList.gridApi.grid.renderContainers.body.renderedRows.map(function(e) {
                    return e.entity
                });
                return i(a, [], !1,
                function(t, n) {
                    return t = t.value,
                    n = n.value,
                    e.isDefined(t.$$refreshed) && e.isDefined(n.$$refreshed) ? t.$$refreshed < n.$$refreshed ? -1 : 1 : e.isDefined(t.$$refreshed) ? 1 : -1
                }).filter(function(e) {
                    return "processing" === e.status || "queued" === e.status
                }).slice(0, 5).reduce(function(r, i) {
                    return r.then(function() {
                        if (null === Y) return o.reject();
                        var r = {
                            timeout: t.promise,
                            noPublishError: !0,
                            noLoadingTracker: !0
                        };
                        return v.getReport(i.reportId, r).then(function(t) {
                            if (e.extend(i, t, {
                                $$refreshed: +new Date
                            }), ("processing" === i.status || "queued" === i.status) && n.reportList.items.indexOf(i) > 0) for (var r = 0; r < n.reportList.items.length; r++) {
                                var a = n.reportList.items[r];
                                if ("processing" === i.status && a.status !== i.status || "processing" === i.status && a.status === i.status && i.created > a.created) {
                                    n.reportList.items.splice(r, 0, i),
                                    n.reportList.items.splice(n.reportList.items.lastIndexOf(i), 1);
                                    break
                                }
                                if (a.status === i.status && i.created > a.created) {
                                    n.reportList.items.splice(r, 0, i),
                                    n.reportList.items.splice(n.reportList.items.lastIndexOf(i), 1);
                                    break
                                }
                            }
                        })
                    })
                },
                o.when()).
                finally(r)
            }).
            finally(function() {
                Z = !1
            }))
        }
        function O() {
            var e = [],
            t = n.searchFilters;
            return t.status.length > 0 && e.push("status:" + t.status.join(",")),
            t.reportSource && ("targets" === t.reportSource ? e.push("source:targets,vulnerabilities") : "scans" === t.reportSource ? e.push("source:scans,scan_result,scan_vulnerabilities") : e.push("source:" + t.reportSource)),
            t.reportTemplate && e.push("template_id:" + t.reportTemplate),
            t.createdStartDate && e.push("created:>=" + encodeURIComponent(r(t.createdStartDate, "yyyy-MM-ddTHH:mm:ss.sssZ"))),
            t.createdEndDate && e.push("created:<=" + encodeURIComponent(r(t.createdEndDate, "yyyy-MM-ddTHH:mm:ss.sssZ"))),
            e.join(";")
        }
        function H() {
            n.reportList.gridApi && n.reportList.gridApi.infiniteScroll.resetScroll(!1, void 0 !== n.reportList.nextCursor)
        }
        function j() {
            var e = n.searchFilters,
            t = [];
            if (e.status.length > 0 && t.push({
                key: "status",
                label: l("状态:"),
                value: e.status.map(function(t) {
                    var n = e.statusList.find(function(e) {
                        return e.value === t
                    });
                    return d.getString(n.text)
                }).join(", ")
            }), e.reportSource && t.push({
                key: "source",
                label: l("报告选项:"),
                value: e.reportSourceList.find(function(t) {
                    return t.value === e.reportSource
                }).text
            }), e.reportTemplate) {
                var i = e.reportTemplateList.find(function(t) {
                    return t.templateId === e.reportTemplate
                });
                t.push({
                    key: "template",
                    label: l("报告模板:"),
                    value: i ? i.name: "N/A"
                })
            }
            e.createdEndDate && e.createdStartDate ? t.push({
                key: "created",
                label: l("创建于某两个时间之间:"),
                value: r(e.createdStartDate) + " and " + r(e.createdEndDate)
            }) : e.createdEndDate ? t.push({
                key: "created_end",
                label: l("在此之前:"),
                value: r(e.createdEndDate)
            }) : e.createdStartDate && t.push({
                key: "created_start",
                label: l("在此之后:"),
                value: r(e.createdStartDate)
            }),
            n.searchFilters.filterTags = t
        }
        function G() {
            Q = !0;
            var e = n.searchFilters,
            t = {};
            e.status.length > 0 && (t.status = e.status.join(",")),
            e.reportSource && (t.source = e.reportSource),
            e.reportTemplate && (t.template = e.reportTemplate),
            e.createdStartDate && (t.created_start = r(e.createdStartDate, "yyyy-MM-ddTHH:mm:ss.sssZ")),
            e.createdEndDate && (t.created_end = r(e.createdEndDate, "yyyy-MM-ddTHH:mm:ss.sssZ")),
            s.go(s.current.name, t, {
                inherit: !1
            }).
            finally(function() {
                Q = !1
            })
        }
        function q() {
            x.set("list-reports", n.reportList.gridApi.saveState.save())
        }
        function B() {
            var e = x.get("list-reports");
            e && n.reportList.gridApi.saveState.restore(n, e)
        }
        function K() {
            x.remove("list-reports"),
            s.reload(s.current)
        }
        function W() {
            n.reportList.items.splice(0),
            n.reportList.nextCursor = void 0,
            n.reportList.gridApi && n.reportList.gridApi.selection && n.reportList.gridApi.selection.clearSelectedRows(),
            H();
            var e = o.defer();
            return u(function() {
                X.promise.then(D).then(e.resolve, e.reject)
            }),
            e.promise
        }
        function z() {
            return o.when().then(function() {
                return T.getTargets(void 0, void 0, 1, {
                    noPublishError: !0
                }).then(function(e) {
                    var t = e.targets;
                    if (n.pageState.noTargetsInSystem = 0 === t.length, !n.pageState.noTargetsInSystem) return b.getScans(void 0, void 0, 1, {
                        noPublishError: !0
                    }).then(function(e) {
                        var t = e.scans;
                        n.pageState.noScansInSystem = 0 === t.length
                    });
                    n.pageState.noScansInSystem = !0
                })
            }).then(function() {
                return v.getReports(void 0, void 0, 1, {
                    noPublishError: !0
                }).then(function(e) {
                    var t = e.reports;
                    n.pageState.noReportsInSystem = 0 === t.length
                })
            })
        }
        var Y, Z, Q = !1,
        X = o.defer(),
        J = Object.freeze([{
            value: "all_vulnerabilities",
            text: l("所有漏洞报告")
        },
        {
            value: "targets",
            text: l("目标报告")
        },
        {
            value: "scans",
            text: l("扫描报告")
        }]);
        n.loadingTracker = p({
            activationDelay: m.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        n.reportList = {
            items: [],
            nextCursor: void 0
        },
        n.reportList.gridOptions = {
            data: n.reportList.items,
            appScopeProvider: n,
            enableColumnMenus: !1,
            enableColumnResizing: !0,
            enableGridMenu: !0,
            enableSelectAll: !1,
            enableSelectionBatchEvent: !1,
            enableSorting: !1,
            useExternalSorting: !0,
            enableFiltering: !1,
            useExternalFiltering: !0,
            saveFilter: !1,
            saveFocus: !1,
            saveGrouping: !1,
            savePinning: !1,
            saveSelection: !1,
            saveSort: !1,
            saveTreeView: !1,
            columnDefs: [{
                displayName: d.getString("报告模板"),
                field: "templateName",
                width: 200
            },
            {
                cellFilter: "axReportSource:true",
                displayName: d.getString("报告类型"),
                field: "source",
                width: 200
            },
            {
                displayName: d.getString("目标"),
                field: "source.target.address",
                width: 320
            },
            {
                cellFilter: "date:'medium'",
                displayName: d.getString("创建于"),
                field: "created",
                width: 180
            },
            {
                cellTemplate: __axtr("/templates/reports/cell/status.html"),
                displayName: d.getString("状态"),
                field: "status",
                width: 130
            },
            {
                cellTemplate: __axtr("/templates/reports/cell/actions.html"),
                displayName: "",
                name: "actions",
                width: 120
            }],
            gridMenuCustomItems: [{
                title: d.getString("重置布局"),
                action: K
            }],
            getRowIdentity: function() {
                function e(e) {
                    return e.reportId
                }
                return e
            } (),
            rowIdentity: function() {
                function e(e) {
                    return e.reportId
                }
                return e
            } (),
            infiniteScrollRowsFromEnd: 20,
            infiniteScrollUp: !1,
            infiniteScrollDown: !0,
            onRegisterApi: function() {
                function e(e) {
                    n.reportList.gridApi = e,
                    e.infiniteScroll.on.needLoadMoreData(n, D),
                    e.colResizable.on.columnSizeChanged(n, q),
                    e.core.on.columnVisibilityChanged(n, q),
                    e.core.on.sortChanged(n, q),
                    X.resolve(e)
                }
                return e
            } ()
        },
        n.searchFilters = {
            status: h.getStateParam("status", !0, t.map(m.REPORT_STATUS, t.property("value"))),
            statusList: m.REPORT_STATUS,
            reportSource: h.getStateParam("source", !1, t.map(J, t.property("value"))),
            reportSourceList: J,
            reportTemplate: h.getStateParam("template", !1),
            reportTemplateList: [],
            createdStartDate: c.created_start ? new Date(h.getStateParam("created_start")) : null,
            createdEndDate: c.created_end ? new Date(h.getStateParam("created_end")) : null,
            createdCalendarVisible: !1,
            filterTags: []
        },
        n.filterAsideVisible = !1,
        n.createdStartDateDatePickerOptions = {
            showWeeks: !1
        },
        n.createdEndDateDatePickerOptions = {
            showWeeks: !1
        },
        n.pageState = {
            noTargetsInSystem: !1,
            noScansInSystem: !1,
            noReportsInSystem: !1
        },
        n.toggleFilter = w,
        n.selectedItems = C,
        n.selectedItemsCount = I,
        n.removeFilterTag = k,
        n.onGenerateReport = A,
        n.onDeleteSelectedReports = E,
        n.deleteSelectedReports = $,
        n.currentUrl = R,
        n.addTargetModal = P,
        n.$watch("searchFilters.status", V),
        n.$watch("searchFilters.reportSource", V),
        n.$watch("searchFilters.reportTemplate", V),
        n.$watch("searchFilters.createdStartDate", V),
        n.$watch("searchFilters.createdEndDate", V),
        n.$watchCollection(function() {
            return c
        },
        M),
        n.$on("$destroy", N),
        n.$on("axScrollTop", H),
        function() {
            j(),
            X.promise.then(function() {
                return z().
                catch(function() {
                    return null
                })
            }).then(function() {
                return U().
                catch(function() {
                    return null
                })
            }).then(D).
            finally(function() {
                B(),
                Y = a(F, m.LIST_REFRESH_INTERVAL)
            })
        } ()
    }
    n.$inject = ["$scope", "dateFilter", "orderByFilter", "$interval", "$q", "$state", "$stateParams", "$timeout", "gettext", "gettextCatalog", "promiseTracker", "toastr", "axPage", "axStateHelpers", "axConstant", "ReportsApi", "axReportOptionsModal", "axTargetModal", "ScansApi", "TargetsApi", "axUserPreferences", "axGeneralModal"],
    e.module("WVS").controller("axListReportsCtrl", n)
} (angular, _),
function(e) {
    "use strict";
    function t(e, t) {
        this.addTarget = e.addTarget,
        this.configureGroups = t.configureGroups
    }
    t.$inject = ["axAddTargetModal", "axTargetConfigureGroupsModal"],
    e.module("WVS").service("axTargetModal", t)
} (angular),
function(e) {
    "use strict";
    var t = function() {
        function e(t, n, r) {
            babelHelpers.classCallCheck(this, e),
            this.$q = t,
            this.axScanningOptionsModal = n,
            this.ScansApi = r
        }
        return e.$inject = ["$q", "axScanningOptionsModal", "ScansApi"],
        babelHelpers.createClass(e, [{
            key: "createScansWizard",
            value: function() {
                function e(e, t) {
                    var n = this.axScanningOptionsModal,
                    r = this.$q,
                    i = this.ScansApi;
                    return n.chooseScanningOptions({
                        targetCount: e.length
                    }).then(function(n) {
                        function a(n) {
                            var o = r.defer();
                            return e.reduce(function(e, r) {
                                return e.then(function() {
                                    var e = void 0,
                                    s = void 0;
                                    switch (n.scheduleType) {
                                    case "instant":
                                        e = null;
                                        break;
                                    case "future":
                                        e = n.scheduleDate;
                                        break;
                                    case "recurrent":
                                        s = n.recurrence
                                    }
                                    var c = {};
                                    return c.targetId = r.targetId,
                                    c.profileId = n.scanProfile,
                                    c.reportTemplateId = n.reportType ? n.reportType: void 0,
                                    c.schedule = {},
                                    c.schedule.disabled = !1,
                                    c.schedule.timeSensitive = n.timeSensitive,
                                    c.schedule.recurrence = s,
                                    c.schedule.scheduleDate = e,
                                    i.scheduleScan(c, {
                                        tracker: t,
                                        onRetry: function() {
                                            function e() {
                                                return a(n)
                                            }
                                            return e
                                        } ()
                                    }).then(function(e) {
                                        o.notify({
                                            target: r,
                                            scanId: e.scanId,
                                            scanningOptions: n
                                        })
                                    })
                                })
                            },
                            r.when()).then(o.resolve, o.reject, o.notify),
                            o.promise
                        }
                        return 0 === e.length ? n: a(n)
                    })
                }
                return e
            } ()
        }]),
        e
    } ();
    e.module("WVS").service("axScansModal", t)
} (angular),
function(e) {
    "use strict";
    function t(t) {
        function n(n) {
            return n = e.extend({},
            n, {
                templateUrl: __axtr("/templates/modals/general/confirm-action.modal.html")
            }),
            t.open(n).result
        }
        function r(n) {
            return n = e.extend({},
            n, {
                templateUrl: __axtr("/templates/modals/general/alert.modal.html")
            }),
            t.open(n).result
        }
        this.confirm = n,
        this.alert = r
    }
    t.$inject = ["$uibModal"],
    e.module("WVS").service("axGeneralModal", t)
} (angular),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u, l, d, p, f, g, h, m, v, y) {
        function S() {
            return h.signOut({
                noLoginRedirect: !0,
                noPublishError: !0
            }).
            finally(function() {
                n.authUser = {}
            })
        }
        function b() {
            n.$applyAsync(function() {
                return e.element(".cell.scrollable").scrollTop(0)
            }),
            n.$broadcast("axScrollTop")
        }
        function T(e, n) {
            return s.go(e, n, {
                inherit: !1,
                reload: t.get(s, "current.name", !0)
            })
        }
        function x() {
            n.app.asideFolded = !n.app.asideFolded,
            g.set("aside_folded", n.app.asideFolded)
        }
        function _(e) {
            if (n.app.locale.value !== e.value) {
                var t = n.loadingTracker.createPromise();
                return f.changeLanguage(e.value).then(function() {
                    n.app.locale = e,
                    r.$emit("axLocaleChanged", {
                        locale: e
                    })
                }).
                finally(t.resolve)
            }
            return a.when()
        }
        function C(e) {
            return v.consumeNotification(e.eventId).then(E)
        }
        function I() {
            return v.consumeAll().then(E)
        }
        function w() {
            var e = n.loadingTracker.createPromise();
            y.enableSystemUpgrade().then(function(e) {
                n.updateInfo = e
            }).
            finally(e.resolve)
        }
        function k(e) {
            var r = g.get(p.MIS);
            Array.isArray(r) || (r = []);
            var i = r.findIndex(function(t) {
                return t.scanningApp === e.scanningApp && t.scanSessionId === e.scanSessionId
            });
            i > -1 ? r[i] = e: r.push(e),
            g.set(p.MIS, r),
            t.remove(n.manualIntervention.items, e)
        }
        function A() {
            M && (i.cancel(M), M = null),
            n.loadingTracker.cancel()
        }
        function L(e) {
            return e ? e.firstName || e.lastName ? [e.firstName, e.lastName].join(" ").trim() : e.email: {
                firstName: ""
            }
        }
        function E() {
            if (F) return a.when();
            var e = [v.getUnconsumedNotificationCount({
                noPublishError: !0,
                noLoadingTracker: !0
            }), v.getNotifications(void 0, void 0, void 0, {
                noPublishError: !0,
                noLoadingTracker: !0
            }), y.getSystemInfo({
                noPublishError: !0,
                noLoadingTracker: !0
            })];
            return F = !0,
            a.all(e).then(function(e) {
                var t = babelHelpers.slicedToArray(e, 3),
                r = t[0],
                i = t[1].notifications,
                a = t[2].updateInfo;
                n.notifications.count = r,
                n.notifications.items = i,
                n.updateInfo = a,
                "none" !== n.updateInfo.status && n.notifications.count++
            }).
            finally(function() {
                F = !1,
                M = i(E, p.NOTIFICATIONS_POLL_INTERVAL)
            })
        }
        function $() {
            return a.when().then(function() {
                return H ? a.reject() : (H = !0, h.getManualInterventionStatus({
                    noPublishError: !0,
                    noLoadingTracker: !0
                }))
            }).then(function(e) {
                if (e = e.filter(function(e) {
                    return !! e.data
                }), !n.$$destroyed) {
                    var r = n.manualIntervention.items.length;
                    n.manualIntervention.items = [];
                    var i = g.get(p.MIS),
                    a = function(e) {
                        return !! (Array.isArray(i) && i.length > 0) && !!i.find(function(t) {
                            return t.uniqueKey === e.uniqueKey
                        })
                    };
                    e.forEach(function(e) {
                        a(e) || n.manualIntervention.items.push(e)
                    }),
                    Array.isArray(i) && i.length > 0 &&
                    function() {
                        for (var n = 0; n < i.length;) { (function() {
                                var r = i[n];
                                if (t.findIndex(e,
                                function(e) {
                                    return r.scanningApp === e.scanningApp && r.scanSessionId === e.scanSessionId
                                }) < 0 || e[n].old > 300) return i.splice(n, 1),
                                "continue";
                                n++
                            })()
                        }
                    } (),
                    Array.isArray(i) && g.set(p.MIS, i),
                    null == O && n.manualIntervention.items.length > r && (O = d.warning("一些扫描需要手动干预。请检查通知.", {
                        timeOut: 0,
                        extendedTimeOut: 0,
                        preventOpenDuplicates: !0,
                        closeButton: !1,
                        tapToDismiss: !0,
                        autoDismiss: !1
                    })),
                    0 === n.manualIntervention.items.length && null !== O && (d.clear(O, !1), O = null)
                }
            }).
            finally(function() {
                H = !1,
                n.$$destroyed || i($, p.NOTIFICATIONS_POLL_INTERVAL)
            })
        }
        function R(t, r) {
            var i = r.identity || {};
            n.authUser = e.copy(i),
            n.authUser.displayName = L(i)
        }
        function P() {
            var e = n.app.locales.find(function(e) {
                return e.value === u.getCurrentLanguage()
            });
            e && (n.app.locale = e, r.currentLocaleId = e.value)
        }
        function N() {
            n.notifications.tooltip = c(0 === n.notifications.count ? "你没有未读通知": "有新通知")
        }
        function D() {
            var e = ["Acunetix"];
            if (s.current && s.current.data && s.current.data.page) {
                var t = s.current.data.page;
                t.title && e.push(u.getString(t.title)),
                t.subtitle && e.push(u.getString(t.subtitle))
            }
            r.documentTitle = e.join(" - ")
        }
        function U(e, r) {
            var i = r.eventId;
            v.consumeNotification(i).then(function() {
                1 === t.remove(n.notifications.items,
                function(e) {
                    return e.eventId === i
                }).length && n.notifications.count--
            })
        }
        function V(e, t) {
            var n = t.scan;
            t.actionRequired && d.warning(u.getString("关于" + String(n.target.address) + "的扫描将需要手动干预"), {
                timeOut: 1e4,
                preventOpenDuplicates: !0,
                closeButton: !1,
                tapToDismiss: !0,
                autoDismiss: !0
            })
        }
        var M = void 0,
        F = void 0,
        O = null,
        H = !1;
        n.loadingTracker = l({
            activationDelay: p.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        n.authUser = e.extend({},
        o, {
            displayName: L(o)
        }),
        n.notifications = {
            count: 0,
            items: [],
            tooltip: ""
        },
        n.app = {
            asideFolded: !!g.get("aside_folded"),
            locales: [{
                value: "en_GB",
                text: "English (United Kingdom)",
                flag: "gb"
            }],
            sections: Object.freeze([{
                name: "dashboard",
                title: c("仪表盘"),
                state: "app.dash",
                icon: "fa-dashboard"
            },
            {
                name: "targets",
                title: c("目标"),
                state: "app.list_targets",
                icon: "fa-dot-circle-o"
            },
            {
                name: "vulns",
                title: c("漏洞"),
                state: "app.list_vulns",
                icon: "fa-bug",
                stateParams: {
                    status: "open"
                }
            },
            {
                name: "scans",
                title: c("扫描"),
                state: "app.list_scans",
                icon: "fa-area-chart"
            },
            {
                name: "reports",
                title: c("报告"),
                state: "app.list_reports",
                icon: "fa-file-text"
            },
            {
                name: "settings",
                title: c("设置"),
                state: "app.edit_settings",
                icon: "fa-cog"
            }])
        },
        n.app.locale = n.app.locales[0],
        r.currentLocaleId = n.app.locale.value,
        n.$state = s,
        n.updateInfo = null,
        n.currentUser = m.get(),
        n.manualIntervention = {
            items: []
        },
        r.documentTitle = "Acunetix",
        n.signOut = S,
        n.scrollTop = b,
        n.changeLocale = _,
        n.navigateTo = T,
        n.toggleAside = x,
        n.consumeNotification = C,
        n.consumeAllNotifications = I,
        n.onEnableSystemUpdate = w,
        n.onMarkManualInterventionItem = k,
        n.$on("gettextLanguageChanged", P),
        n.$on("$destroy", r.$on(p.API_EVENTS.CURRENT_USER_IDENTITY_UPDATED, R)),
        n.$on("$destroy", r.$on("$viewContentLoaded", D)),
        n.$on("$destroy", A),
        n.$on("$destroy", r.$on("axConsumeNotification", U)),
        n.$on("$destroy", r.$on(p.API_EVENTS.SCAN_CREATED, V)),
        n.$watch("notifications.count", N),
        n.$watch(function() {
            return m.get()
        },
        function(e) {
            return n.currentUser = e
        }),
        function() {
            E(),
            P(),
            $()
        } (),
        jQuery(window).one("beforeunload",
        function() {
            if (n.manualIntervention.items.length > 0) return "一些扫描需要手动干预。 您确定要关闭/重新加载此页面?"
        }),
        n.$on("destroy",
        function() {
            return jQuery(window).off("beforeunload")
        })
    }
    n.$inject = ["$scope", "$rootScope", "$timeout", "$q", "authUser", "$state", "gettext", "gettextCatalog", "promiseTracker", "toastr", "axConstant", "axLocale", "axUserPreferences", "AccountApi", "CurrentUser", "NotificationsApi", "SystemConfigApi"],
    e.module("WVS").controller("axShellCtrl", n)
} (angular, _),
function(e) {
    "use strict";
    function t() {
        return {
            restrict: "A",
            scope: !1,
            compile: function() {
                function t(t) {
                    t.addClass("text-muted").attr("href", t.attr("href") || "http://www.acunetix.com/support").attr("target", "_blank").prepend(e.element('<i class="fa fa-fw fa-question-circle"></i>'))
                }
                return t
            } ()
        }
    }
    e.module("WVS").directive("axSupportLink", t)
} (angular),
function(e) {
    "use strict";
    function t(e) {
        return {
            restrict: "A",
            link: function() {
                function t(t, n) {
                    function r(e) {
                        e ? n.removeClass("hidden") : n.addClass("hidden")
                    }
                    n.addClass("fa fa-spinner fa-spin");
                    var i = t.$watch(function() {
                        return e.globalPromiseTracker.active()
                    },
                    r);
                    t.$on("$destroy", i),
                    r(!1)
                }
                return t
            } ()
        }
    }
    t.$inject = ["$rootScope"],
    e.module("WVS").directive("axSpinner", t)
} (angular),
function(e) {
    "use strict";
    function t() {
        return {
            require: "ngModel",
            link: function() {
                function e(e, t, i, a) {
                    a.$validators[n] = function(e) {
                        return !! e && r.test(e)
                    }
                }
                return e
            } ()
        }
    }
    var n = "passwordPolicy",
    r = /(?=^.{8,}$)((?=.*?\d)(?=.*?[A-Z])(?=.*?[a-z])|(?=.*?\d)(?=.*?[^\w\d\s])(?=.*?[a-z])|(?=.*?[^\w\d\s])(?=.*?[A-Z])(?=.*?[a-z])|(?=.*?\d)(?=.*?[A-Z])(?=.*?[^\w\d\s]))^.*/;
    e.module("WVS").directive(n, t)
} (angular),
function(e) {
    "use strict";
    function t() {
        return {
            restrict: "A",
            link: function() {
                function t(t, n, r) {
                    var i = e.element('<div class="ax-overlay hidden" tabindex="1"></div>').appendTo(n).on("keyup keydown keypress input click dblclick mousedown mouseup",
                    function(e) {
                        e.preventDefault(),
                        e.stopPropagation()
                    }),
                    a = t.$watch(r.axOverlay,
                    function(e) {
                        e ? i.removeClass("hidden") : i.addClass("hidden")
                    });
                    t.$on("$destroy", a),
                    n.on("$destroy",
                    function() {
                        return i.remove()
                    })
                }
                return t
            } ()
        }
    }
    e.module("WVS").directive("axOverlay", t)
} (angular),
function(e, t) {
    "use strict";
    function n(n, r, i, a, o, s, c, u, l) {
        function d(e) {
            return function() {
                n.$applyAsync(e)
            }
        }
        function p(t, i, a) {
            return r.when().then(function() {
                return a ? l.getExport(i, null, {
                    noLoadingTracker: !0,
                    noPublishError: !0
                }) : l.getReport(i, null, {
                    noLoadingTracker: !0,
                    noPublishError: !0
                })
            }).
            catch(function() {
                var e = {
                    errorMessage: c("你的" + (a ? "导出": "报告") + "无法被下载[" + (a ? "导出": "报告") + "已被删除]")
                };
                n.$emit("axError", e)
            }).then(function(t) {
                e.element("#download-helper").attr("src", t.downloadLinkXML || t.downloadLinkPDF || t.downloadLinkHTML)
            }).then(function() {
                n.$emit("axConsumeNotification", {
                    eventId: t
                })
            })
        }
        return {
            restrict: "A",
            link: function() {
                function s(s, c, l) {
                    function f(e) {
                        c.one("click", ".ax-notification-event-name", d(function() {
                            r.when().then(e).then(function() {
                                n.$emit("axConsumeNotification", {
                                    eventId: h.eventId
                                })
                            }).
                            catch(function(e) {
                                n.$emit("axError", e)
                            })
                        }))
                    }
                    var g = a(l.axEventResourceLink),
                    h = g(s);
                    switch (h.resourceType) {
                    case 5:
                        if (h.resourceId) {
                            var m = h.eventData ? h.eventData.scanSessionId: null;
                            if (m) {
                                var v = {
                                    scanId: h.resourceId,
                                    resultId: m,
                                    view: "stats",
                                    returnUrl: u.currentUrlEncoded()
                                };
                                f(function() {
                                    o.go("app.scan_details", v, {
                                        inherit: !1
                                    })
                                })
                            }
                        }
                        break;
                    case 6:
                        if (h.resourceId) {
                            var y = {
                                scanId: h.eventData.scanId,
                                resultId: h.resourceId,
                                view: "stats",
                                returnUrl: u.currentUrlEncoded()
                            };
                            f(function() {
                                o.go("app.scan_details", y, {
                                    inherit: !1
                                })
                            })
                        }
                        break;
                    case 7:
                        if (h.resourceId && (c.css({
                            color: "#3a3f51",
                            cursor: "default"
                        }), 601 === h.eventTypeId)) {
                            var S = e.element('<button class="btn btn-danger btn-xs pull-right m-t-n-sm m-r-lg">下载</button>');
                            c.append(i(S)(s)),
                            S.on("click", d(function() {
                                return p(h.eventId, h.resourceId, !1)
                            }))
                        }
                        break;
                    case 9:
                        if (h.resourceId) {
                            var b = h.resourceId;
                            e.isString(b) && (b = t.trim(b, "(),")),
                            f(function() {
                                o.go("app.vuln_details", {
                                    vulnId: b
                                },
                                {
                                    inherit: !1
                                })
                            })
                        }
                        break;
                    case 10:
                        if (h.resourceId && (c.css({
                            color: "#3a3f51",
                            cursor: "default"
                        }), 603 === h.eventTypeId)) {
                            var T = e.element('<button class="btn btn-danger btn-xs pull-right m-t-n-sm m-r-lg">下载</button>');
                            c.append(i(T)(s)),
                            T.on("click", d(function() {
                                return p(h.eventId, h.resourceId, !0)
                            }))
                        }
                    }
                }
                return s
            } ()
        }
    }
    n.$inject = ["$rootScope", "$q", "$compile", "$parse", "$state", "$stateParams", "gettext", "axPage", "ReportsApi"],
    e.module("WVS").directive("axEventResourceLink", n)
} (angular, _),
function(e) {
    "use strict";
    function t() {
        return {
            require: "ngModel",
            scope: {
                equalTo: "="
            },
            link: function() {
                function e(e, t, r, i) {
                    i.$validators.equalTo = function(t) {
                        return t == e.equalTo
                    },
                    e.$watch(n,
                    function() {
                        return i.$validate()
                    })
                }
                return e
            } ()
        }
    }
    var n = "equalTo";
    e.module("WVS").directive(n, t)
} (angular),
function(e) {
    "use strict";
    function t(t, n, r, i, a, o, s, c, u, l, d, p, f, g, h) {
        function m() {
            t.stats.showTrends = !t.stats.showTrends,
            t.stats.showTrends && !_ && S("trends").
            catch(function(e) {
                return t.stats.showTrends = !1,
                n.reject(e)
            }).then(function() {
                _ = !0
            })
        }
        function v() {
            return f.addTarget().then(function(e) {
                i.go("app.target_config", {
                    returnUrl: b(),
                    targetId: e.targetId
                },
                {
                    inherit: !1
                })
            })
        }
        function y() {
            t.loadingTracker.cancel(),
            C && (r.cancel(C), C = null)
        }
        function S() {
            var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "simple",
            r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            return g.getStats(n, e.extend({
                tracker: t.loadingTracker,
                onRetry: function() {
                    function e() {
                        return S(n, r)
                    }
                    return e
                } ()
            },
            r)).then(function(e) {
                "simple" !== n && "full" !== n || (t.stats.general.forEach(function(t) {
                    t.value = e[t.key]
                }), t.stats.noTargets = 0 === e.totalTargets, t.stats.noOpenVulns = 0 === e.openVulns, t.stats.vulnsBySeverity.data = function(e) {
                    return [{
                        value: e.high,
                        label: u.getString("高危"),
                        color: "#f05050",
                        severity: "3"
                    },
                    {
                        value: e.medium,
                        label: u.getString("中危"),
                        color: "#faa732",
                        severity: "2"
                    },
                    {
                        value: e.low,
                        label: u.getString("低危"),
                        color: "#23b7e5",
                        severity: "1"
                    }]
                } (e.vulnCount), t.stats.mostVulnTargets.data = e.mostVulnerableTargets.map(function(e) {
                    return {
                        targetId: e.targetId,
                        address: e.address,
                        criticality: e.criticality,
                        vulns: {
                            high: e.highVulns,
                            medium: e.mediumVulns
                        }
                    }
                }), t.stats.topVulns.data = e.topVulns, t.stats.vulnsByCriticality.data = function(e) {
                    var t = {
                        high: {
                            critical: "#ec2121",
                            high: "#f26767",
                            normal: "#f69696",
                            low: "#fac5c5"
                        },
                        medium: {
                            critical: "#f39106",
                            high: "#fbb24b",
                            normal: "#fcc77d",
                            low: "#fddcae"
                        },
                        low: {
                            critical: "#1797be",
                            high: "#3abee8",
                            normal: "#67cded",
                            low: "#95dcf2"
                        }
                    },
                    n = {
                        high: {
                            value: "3",
                            label: u.getString("高危")
                        },
                        medium: {
                            value: "2",
                            label: u.getString("中危")
                        },
                        low: {
                            value: "1",
                            label: u.getString("低危")
                        }
                    },
                    r = {
                        critical: {
                            value: "30",
                            label: u.getString("紧急")
                        },
                        high: {
                            value: "20",
                            label: u.getString("高危")
                        },
                        normal: {
                            value: "10",
                            label: u.getString("一般")
                        },
                        low: {
                            value: "0",
                            label: u.getString("低危")
                        }
                    };
                    return h.hasFeature("target_business_criticality") !== !0 && (["high", "medium", "low"].forEach(function(e) {
                        Object.keys(t[e]).forEach(function(n) {
                            "normal" !== n && delete t[e][n]
                        })
                    }), Object.keys(r).forEach(function(e) {
                        "normal" !== e && delete r[e]
                    }), t.high.normal = "#ec2121", t.medium.normal = "#f39106", t.low.normal = "#1797be"),
                    ["high", "medium", "low"].reduce(function(i, a) {
                        return i[a] = [],
                        Object.keys(e).forEach(function(o) {
                            r.hasOwnProperty(o) && i[a].push({
                                severity: n[a].value,
                                criticality: r[o].value,
                                color: t[a][o],
                                value: e[o][a],
                                label: r[o].label
                            })
                        }),
                        i
                    },
                    {})
                } (e.vulnCountByCriticality), t.stats.vulnsByCriticality.options.high.chart.title = t.stats.vulnsByCriticality.data.high.reduce(function(e, t) {
                    return e + t.value
                },
                0).toString(), t.stats.vulnsByCriticality.options.medium.chart.title = t.stats.vulnsByCriticality.data.medium.reduce(function(e, t) {
                    return e + t.value
                },
                0).toString(), t.stats.vulnsByCriticality.options.low.chart.title = t.stats.vulnsByCriticality.data.low.reduce(function(e, t) {
                    return e + t.value
                },
                0).toString()),
                "full" !== n && "trends" !== n || (t.stats.openVulnsTrend.data = e.trendOpenVulns.reduce(function(e, t) {
                    return e[0].values.push([t.startDate, t.highVulns]),
                    e[1].values.push([t.startDate, t.mediumVulns]),
                    e
                },
                [{
                    key: "High Vulnerabilities",
                    values: []
                },
                {
                    key: "Medium Vulnerabilities",
                    values: []
                }]), t.stats.avgRemediationTime.data = e.trendAverageRemediationTime.reduce(function(e, t) {
                    return e[0].values.push([t.startDate, t.averageDays]),
                    e[1].values.push([t.startDate, t.fixedHighVulns]),
                    e[2].values.push([t.startDate, t.fixedMediumVulns]),
                    e
                },
                [{
                    key: "Avg days to remediate",
                    values: []
                },
                {
                    key: "High Vulnerabilities Fixed",
                    values: []
                },
                {
                    key: "Medium Vulnerabilities Fixed",
                    values: []
                }]), t.stats.avgVulnAgeTrend.data = e.trendAverageVulnAge.reduce(function(e, t) {
                    var n = t.startDate,
                    r = t.averageDays;
                    return e[0].values.push([n, r]),
                    e
                },
                [{
                    key: u.getString("Average Days"),
                    values: []
                }]), t.stats.newVulnsTrending.data = e.trendNewVulns.reduce(function(e, t) {
                    return e[0].values.push([t.startDate, t.weightedVulns]),
                    e
                },
                [{
                    key: "Value",
                    values: []
                }]))
            })
        }
        function b() {
            return p.currentUrlEncoded()
        }
        function T() {
            C = r(x, d.DASH_REFRESH_INTERVAL)
        }
        function x() {
            return n.when().then(function() {
                if (I) return n.reject();
                I = !0
            }).then(function() {
                return S(t.stats.showTrends ? "full": "simple", {
                    noLoadingTracker: !0,
                    noPublishError: !0
                })
            }).
            finally(function() {
                I = !1
            })
        }
        t.loadingTracker = l({
            activationDelay: d.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        t.stats = {
            showTrends: !1,
            general: [{
                key: "runningScans",
                name: u.getString("进行中的扫描"),
                value: 0,
                state: "app.list_scans({status: ['processing', 'aborting']})"
            },
            {
                key: "waitingScans",
                name: u.getString("等待中的扫描"),
                value: 0,
                state: "app.list_scans({status: ['queued','starting']})"
            },
            {
                key: "totalScans",
                name: u.getString("总扫描次数"),
                value: 0,
                state: "app.list_scans({status: ['completed', 'failed', 'aborted']})"
            },
            {
                key: "openVulns",
                name: u.getString("开放的漏洞"),
                value: 0,
                state: "app.list_vulns({status: 'open'})"
            },
            {
                key: "totalTargets",
                name: u.getString("目标总数"),
                value: 0,
                state: "app.list_targets"
            }],
            noTargets: !1,
            noOpenVulns: !1,
            vulnsBySeverity: {
                data: null,
                options: {
                    chart: {
                        type: "pieChart",
                        height: 300,
                        showLabels: !0,
                        duration: 500,
                        x: function() {
                            function e(e) {
                                return e.label
                            }
                            return e
                        } (),
                        y: function() {
                            function e(e) {
                                return e.value
                            }
                            return e
                        } (),
                        labelSunbeamLayout: !1,
                        showLegend: !0,
                        labelType: "value",
                        margin: {
                            left: 0,
                            top: 0,
                            right: 0,
                            bottom: 0
                        },
                        tooltip: {
                            enabled: !1
                        },
                        pie: {
                            color: function() {
                                function e(e) {
                                    return e.color
                                }
                                return e
                            } (),
                            valueFormat: function() {
                                function e(e) {
                                    var n = t.stats.vulnsBySeverity.data.reduce(function(e, t) {
                                        return e + t.value
                                    },
                                    0);
                                    return c(e / n * 100, 2) + "%"
                                }
                                return e
                            } (),
                            dispatch: {
                                elementClick: function() {
                                    function e(e) {
                                        var t = e.data;
                                        i.go("app.list_vulns", {
                                            severity: t.severity
                                        })
                                    }
                                    return e
                                } (),
                                elementMouseover: function() {
                                    function e() {
                                        o.event && (o.event.currentTarget.style.cursor = "pointer")
                                    }
                                    return e
                                } (),
                                elementMouseout: function() {
                                    function e() {
                                        o.event && (o.event.currentTarget.style.cursor = "")
                                    }
                                    return e
                                } ()
                            }
                        }
                    }
                }
            },
            vulnsByCriticality: {
                data: null,
                options: {
                    high: {
                        chart: {
                            type: "pieChart",
                            height: 180,
                            showLabels: !1,
                            showLegend: !1,
                            margin: {
                                left: 0,
                                top: 0,
                                right: 0,
                                bottom: 0
                            },
                            tooltip: {
                                enabled: h.hasFeature("target_business_criticality") === !0,
                                keyFormatter: function() {
                                    function e(e) {
                                        return "<span>业务关键性&nbsp;</span><br><strong>" + String(e[0].toUpperCase()) + String(e.substr(1)) + "</strong>"
                                    }
                                    return e
                                } (),
                                valueFormatter: function() {
                                    function e(e) {
                                        return c(e, 0)
                                    }
                                    return e
                                } ()
                            },
                            donut: !0,
                            donutRatio: .72,
                            x: function() {
                                function e(e) {
                                    return e.label
                                }
                                return e
                            } (),
                            y: function() {
                                function e(e) {
                                    return e.value
                                }
                                return e
                            } (),
                            color: function() {
                                function e(e) {
                                    return e.color
                                }
                                return e
                            } (),
                            pie: {
                                color: function() {
                                    function e(e) {
                                        return e.color
                                    }
                                    return e
                                } (),
                                valueFormat: function() {
                                    function e(e) {
                                        return c(e, 0)
                                    }
                                    return e
                                } (),
                                dispatch: {
                                    elementClick: function() {
                                        function e(e) {
                                            var t = e.data,
                                            n = h.hasFeature("target_business_criticality") === !0 ? t.criticality: void 0;
                                            i.go("app.list_vulns", {
                                                severity: t.severity,
                                                criticality: n
                                            })
                                        }
                                        return e
                                    } (),
                                    elementMouseover: function() {
                                        function e() {
                                            o.event && (o.event.currentTarget.style.cursor = "pointer")
                                        }
                                        return e
                                    } (),
                                    elementMouseout: function() {
                                        function e() {
                                            o.event && (o.event.currentTarget.style.cursor = "")
                                        }
                                        return e
                                    } ()
                                }
                            },
                            growOnHover: h.hasFeature("target_business_criticality") === !0,
                            title: ""
                        },
                        caption: {
                            enable: !0,
                            text: u.getString("高危漏洞"),
                            css: {
                                fontSize: "18px",
                                color: "#999999"
                            }
                        }
                    },
                    medium: {
                        chart: {
                            type: "pieChart",
                            height: 180,
                            showLabels: !1,
                            showLegend: !1,
                            margin: {
                                left: 0,
                                top: 0,
                                right: 0,
                                bottom: 0
                            },
                            tooltip: {
                                enabled: h.hasFeature("target_business_criticality") === !0,
                                keyFormatter: function() {
                                    function e(e) {
                                        return "<span>业务关键性&nbsp;</span><br><strong>" + String(e[0].toUpperCase()) + String(e.substr(1)) + "</strong>"
                                    }
                                    return e
                                } (),
                                valueFormatter: function() {
                                    function e(e) {
                                        return c(e, 0)
                                    }
                                    return e
                                } ()
                            },
                            donut: !0,
                            donutRatio: .72,
                            x: function() {
                                function e(e) {
                                    return e.label
                                }
                                return e
                            } (),
                            y: function() {
                                function e(e) {
                                    return e.value
                                }
                                return e
                            } (),
                            color: function() {
                                function e(e) {
                                    return e.color
                                }
                                return e
                            } (),
                            pie: {
                                color: function() {
                                    function e(e) {
                                        return e.color
                                    }
                                    return e
                                } (),
                                valueFormat: function() {
                                    function e(e) {
                                        return c(e, 0)
                                    }
                                    return e
                                } (),
                                dispatch: {
                                    elementClick: function() {
                                        function e(e) {
                                            var t = e.data,
                                            n = h.hasFeature("target_business_criticality") === !0 ? t.criticality: void 0;
                                            i.go("app.list_vulns", {
                                                severity: t.severity,
                                                criticality: n
                                            })
                                        }
                                        return e
                                    } (),
                                    elementMouseover: function() {
                                        function e() {
                                            o.event && (o.event.currentTarget.style.cursor = "pointer")
                                        }
                                        return e
                                    } (),
                                    elementMouseout: function() {
                                        function e() {
                                            o.event && (o.event.currentTarget.style.cursor = "")
                                        }
                                        return e
                                    } ()
                                }
                            },
                            growOnHover: h.hasFeature("target_business_criticality") === !0,
                            title: ""
                        },
                        caption: {
                            enable: !0,
                            text: u.getString("中危漏洞"),
                            css: {
                                fontSize: "18px",
                                color: "#999999"
                            }
                        }
                    },
                    low: {
                        chart: {
                            type: "pieChart",
                            height: 180,
                            showLabels: !1,
                            showLegend: !1,
                            margin: {
                                left: 0,
                                top: 0,
                                right: 0,
                                bottom: 0
                            },
                            tooltip: {
                                enabled: h.hasFeature("target_business_criticality") === !0,
                                keyFormatter: function() {
                                    function e(e) {
                                        return "<span>业务关键性&nbsp;</span><br><strong>" + String(e[0].toUpperCase()) + String(e.substr(1)) + "</strong>"
                                    }
                                    return e
                                } (),
                                valueFormatter: function() {
                                    function e(e) {
                                        return c(e, 0)
                                    }
                                    return e
                                } ()
                            },
                            donut: !0,
                            donutRatio: .72,
                            x: function() {
                                function e(e) {
                                    return e.label
                                }
                                return e
                            } (),
                            y: function() {
                                function e(e) {
                                    return e.value
                                }
                                return e
                            } (),
                            color: function() {
                                function e(e) {
                                    return e.color
                                }
                                return e
                            } (),
                            pie: {
                                color: function() {
                                    function e(e) {
                                        return e.color
                                    }
                                    return e
                                } (),
                                valueFormat: function() {
                                    function e(e) {
                                        return c(e, 0)
                                    }
                                    return e
                                } (),
                                dispatch: {
                                    elementClick: function() {
                                        function e(e) {
                                            var t = e.data,
                                            n = h.hasFeature("target_business_criticality") === !0 ? t.criticality: void 0;
                                            i.go("app.list_vulns", {
                                                severity: t.severity,
                                                criticality: n
                                            })
                                        }
                                        return e
                                    } (),
                                    elementMouseover: function() {
                                        function e() {
                                            o.event && (o.event.currentTarget.style.cursor = "pointer")
                                        }
                                        return e
                                    } (),
                                    elementMouseout: function() {
                                        function e() {
                                            o.event && (o.event.currentTarget.style.cursor = "")
                                        }
                                        return e
                                    } ()
                                }
                            },
                            growOnHover: h.hasFeature("target_business_criticality") === !0,
                            title: ""
                        },
                        caption: {
                            enable: !0,
                            text: u.getString("低危漏洞"),
                            css: {
                                fontSize: "18px",
                                color: "#999999"
                            }
                        }
                    }
                }
            },
            newVulnsTrending: {
                data: null,
                options: {
                    chart: {
                        type: "lineChart",
                        interpolate: "cardinal",
                        height: 300,
                        showLabels: !0,
                        showLegend: !1,
                        duration: 500,
                        x: function() {
                            function e(e) {
                                return e[0]
                            }
                            return e
                        } (),
                        y: function() {
                            function e(e) {
                                return e[1]
                            }
                            return e
                        } (),
                        useInteractiveGuideline: !0,
                        xAxis: {
                            showMaxMin: !1,
                            tickFormat: function() {
                                function e(e) {
                                    return s(e, "MMM-yyyy")
                                }
                                return e
                            } ()
                        },
                        yAxis: {
                            showMaxMin: !1,
                            tickFormat: function() {
                                function e(e) {
                                    return c(e, 0)
                                }
                                return e
                            } ()
                        },
                        zoom: {
                            enabled: !1,
                            scaleExtent: [1, 10],
                            useFixedDomain: !1,
                            useNiceScale: !1,
                            horizontalOff: !1,
                            verticalOff: !0,
                            unzoomEventType: "dblclick.zoom"
                        }
                    }
                }
            },
            mostVulnTargets: {
                data: null
            },
            topVulns: {
                data: null
            },
            openVulnsTrend: {
                data: null,
                options: {
                    chart: {
                        type: "stackedAreaChart",
                        height: 300,
                        showLabels: !0,
                        duration: 100,
                        showControls: !1,
                        margin: {
                            top: 20,
                            right: 20,
                            bottom: 30,
                            left: 40
                        },
                        x: function() {
                            function e(e) {
                                return e[0]
                            }
                            return e
                        } (),
                        y: function() {
                            function e(e) {
                                return e[1]
                            }
                            return e
                        } (),
                        useVoronoi: !1,
                        clipEdge: !0,
                        useInteractiveGuideline: !0,
                        xAxis: {
                            showMaxMin: !1,
                            tickFormat: function() {
                                function e(e) {
                                    return s(e, "MMM-yyyy")
                                }
                                return e
                            } ()
                        },
                        yAxis: {
                            showMaxMin: !1,
                            tickFormat: function() {
                                function e(e) {
                                    return c(e, 0)
                                }
                                return e
                            } ()
                        },
                        zoom: {
                            enabled: !1,
                            scaleExtent: [1, 10],
                            useFixedDomain: !1,
                            useNiceScale: !1,
                            horizontalOff: !1,
                            verticalOff: !0,
                            unzoomEventType: "dblclick.zoom"
                        },
                        color: function() {
                            function e(e, t) {
                                return 0 === t ? "#f05050": "#faa732"
                            }
                            return e
                        } ()
                    }
                }
            },
            fixedVulnsTrend: {
                data: null
            },
            avgRemediationTime: {
                data: null,
                options: {
                    chart: {
                        type: "lineChart",
                        interpolate: "cardinal",
                        height: 300,
                        showLabels: !0,
                        duration: 500,
                        x: function() {
                            function e(e) {
                                return e[0]
                            }
                            return e
                        } (),
                        y: function() {
                            function e(e) {
                                return e[1]
                            }
                            return e
                        } (),
                        useInteractiveGuideline: !0,
                        xAxis: {
                            showMaxMin: !1,
                            tickFormat: function() {
                                function e(e) {
                                    return s(e, "MMM-yyyy")
                                }
                                return e
                            } ()
                        },
                        yAxis: {
                            showMaxMin: !1,
                            tickFormat: function() {
                                function e(e) {
                                    return c(e, 2)
                                }
                                return e
                            } ()
                        },
                        margin: {
                            top: 20,
                            right: 20,
                            bottom: 30,
                            left: 40
                        },
                        zoom: {
                            enabled: !1,
                            scaleExtent: [1, 10],
                            useFixedDomain: !1,
                            useNiceScale: !1,
                            horizontalOff: !1,
                            verticalOff: !0,
                            unzoomEventType: "dblclick.zoom"
                        },
                        color: function() {
                            function e(e, t) {
                                return 0 === t ? "#f05050": "#faa732"
                            }
                            return e
                        } ()
                    }
                }
            },
            avgVulnAgeTrend: {
                data: null,
                options: {
                    chart: {
                        type: "lineChart",
                        interpolate: "cardinal",
                        height: 300,
                        showLabels: !0,
                        showLegend: !1,
                        duration: 500,
                        x: function() {
                            function e(e) {
                                return e[0]
                            }
                            return e
                        } (),
                        y: function() {
                            function e(e) {
                                return e[1]
                            }
                            return e
                        } (),
                        useInteractiveGuideline: !0,
                        xAxis: {
                            tickFormat: function() {
                                function e(e) {
                                    return s(e, "MMM-yyyy")
                                }
                                return e
                            } ()
                        },
                        yAxis: {
                            tickFormat: function() {
                                function e(e) {
                                    return c(e, 2)
                                }
                                return e
                            } ()
                        },
                        zoom: {
                            enabled: !1,
                            scaleExtent: [1, 10],
                            useFixedDomain: !1,
                            useNiceScale: !1,
                            horizontalOff: !1,
                            verticalOff: !0,
                            unzoomEventType: "dblclick.zoom"
                        }
                    }
                }
            }
        };
        var _ = !1,
        C = null,
        I = !1;
        t.currentUrl = b,
        t.toggleTrends = m,
        t.onCreateTarget = v,
        t.$on("$destroy", y),
        function() {
            S().
            finally(T)
        } ()
    }
    t.$inject = ["$scope", "$q", "$interval", "$state", "$stateParams", "$window", "dateFilter", "numberFilter", "gettextCatalog", "promiseTracker", "axConstant", "axPage", "axTargetModal", "AccountApi", "CurrentUser"],
    e.module("WVS").controller("axDashCrl", t)
} (angular),
function(e) {
    "use strict";
    function t(e, t, n, r, i, a, o, s) {
        function c() {
            e.filterAsideVisible = !e.filterAsideVisible
        }
        function u(t) {
            var n = e.searchFilters;
            switch (n.filterTags.splice(n.filterTags.indexOf(t), 1), t.key) {
            case "severity":
                n.severity = [];
                break;
            case "type":
                n.eventType = [];
                break;
            case "resType":
                n.resourceType = null;
                break;
            case "resId":
                n.resourceId = null
            }
            h()
        }
        function l() {
            e.loadingTracker.cancel()
        }
        function d(e, t) {
            e !== t && (f(), g(), h())
        }
        function p(e, n) {
            e === n || m || t.reload(t.current)
        }
        function f() {
            var t = e.searchFilters,
            n = [];
            t.severity.length > 0 && n.push("severity:" + t.severity.join(",")),
            t.eventType.length > 0 && n.push("type_id:" + t.eventType.join(",")),
            t.resourceType && n.push("resource_type:" + t.resourceType),
            t.resourceId && n.push("resource_id:" + t.resourceId),
            t.searchQuery = n.join(";")
        }
        function g() {
            var t = e.searchFilters,
            n = [];
            if (t.severity.length > 0 && n.push({
                key: "severity",
                label: r("严重程度:"),
                value: t.severity.map(function(e) {
                    var n = t.severityList.find(function(t) {
                        return t.value === e
                    });
                    return i.getString(n.text)
                }).join(", ")
            }), t.eventType.length > 0 && n.push({
                key: "type",
                label: r("事件:"),
                value: t.eventType.map(function(e) {
                    var n = t.eventTypeList.find(function(t) {
                        return t.typeId === e
                    });
                    return i.getString(String(n.groupName) + " " + String(n.typeName))
                }).join(", ")
            }), t.resourceType && n.push({
                key: "resType",
                label: r("资源类型:"),
                value: i.getString(t.resourceTypeList.find(function(t) {
                    return t.value === e.searchFilters.resourceType
                }).text)
            }), t.resourceId) {
                var a = r("资源ID");
                t.resourceType && (a = i.getString(t.resourceTypeList.find(function(t) {
                    return t.value === e.searchFilters.resourceType
                }).text)),
                n.push({
                    key: "resId",
                    label: String(a) + ":",
                    value: t.resourceId
                })
            }
            e.searchFilters.filterTags = n
        }
        function h() {
            var n = e.searchFilters,
            r = {};
            n.severity.length > 0 && (r.severity = n.severity.join(",")),
            n.eventType.length > 0 && (r.type = n.eventType.join(",")),
            n.resourceType && (r.resType = n.resourceType),
            n.resourceId && (r.resId = n.resourceId),
            m = !0,
            t.go(t.current.name, r, {
                inherit: !1
            }).
            finally(function() {
                m = !1
            })
        }
        var m = !1;
        e.loadingTracker = a({
            activationDelay: o.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        e.searchFilters = {
            searchQuery: "",
            severity: s.getStateParam("severity", !0, o.EVENT_SEVERITY.map(function(e) {
                return e.value
            })),
            severityList: o.EVENT_SEVERITY,
            eventType: s.getStateParam("type", !0, o.EVENT_TYPES_MAP.map(function(e) {
                return e.typeId
            })),
            eventTypeList: o.EVENT_TYPES_MAP,
            resourceType: s.getStateParam("resType", !1, o.EVENT_RESOURCE_TYPE.map(function(e) {
                return e.value
            })),
            resourceTypeList: o.EVENT_RESOURCE_TYPE,
            resourceId: s.getStateParam("resId", !1),
            filterTags: []
        },
        e.filterAsideVisible = !1,
        e.toggleFilter = c,
        e.removeFilterTag = u,
        e.$on("$destroy", l),
        e.$watch("searchFilters.severity", d),
        e.$watch("searchFilters.eventType", d),
        e.$watch("searchFilters.resourceType", d),
        e.$watch("searchFilters.resourceId", d),
        e.$watchCollection(function() {
            return n
        },
        p),
        function() {
            g(),
            f()
        } ()
    }
    t.$inject = ["$scope", "$state", "$stateParams", "gettext", "gettextCatalog", "promiseTracker", "axConstant", "axStateHelpers"],
    e.module("WVS").controller("axActivityLogCtrl", t)
} (angular),
function(e) {
    "use strict";
    function t(t, a, o, s, c, u, l, d, p, f, g) {
        function h() {
            return u.updateProfile(t.userProfile, {
                onRetry: function() {
                    function e() {
                        return h()
                    }
                    return e
                } ()
            }).then(function(e) {
                n(t.userProfile, e),
                c.success(o.getString("配置文件已更新")),
                A = k(e)
            })
        }
        function m() {
            return ! i(A, k(t.userProfile))
        }
        function v() {
            return t.profileForm && t.profileForm.$invalid ? a("表单无效") : m() ? "": a("无修改需要保存")
        }
        function y() {
            var e = r(t.$new(), {
                message: a("你确定要移除你的API密钥？?")
            });
            return p.confirm({
                scope: e
            }).then(function() {
                return u.deleteApiKey()
            }).then(function(e) {
                t.apiKeyInfo.apiKey = e
            }).
            finally(function() {
                return e.$destroy()
            })
        }
        function S() {
            var e = r(t.$new(), {
                message: a(t.apiKeyInfo.apiKey ? "你确定要生成一个新的API密钥吗？旧的API密钥将失效.": "你确定你想生成一个新的API密匙吗?")
            });
            p.confirm({
                scope: e
            }).then(function() {
                return u.resetApiKey()
            }).then(function(e) {
                t.apiKeyInfo.apiKey = e,
                t.apiKeyInfo.visible = !1
            }).
            finally(function() {
                return e.$destroy()
            })
        }
        function b() {
            t.apiKeyInfo.visible = !t.apiKeyInfo.visible
        }
        function T(e) {
            e.clearSelection(),
            t.apiKeyInfo.clipboardTooltipEnabled = !0,
            t.apiKeyInfo.clipboardTooltipText = a("已复制")
        }
        function x() {
            t.apiKeyInfo.clipboardTooltipEnabled = !0,
            t.apiKeyInfo.clipboardTooltipText = a("按Ctrl+c来复制")
        }
        function _() {
            t.apiKeyInfo.clipboardTooltipEnabled = !1
        }
        function C() {
            u.getProfile({
                tracker: t.loadingTracker,
                onRetry: function() {
                    function e() {
                        return C()
                    }
                    return e
                } ()
            }).then(function(e) {
                n(t.userProfile, e),
                A = k(e)
            })
        }
        function I() {
            return g.getSystemInfo({
                tracker: t.loadingTracker,
                onRetry: function() {
                    function e() {
                        return I()
                    }
                    return e
                } ()
            }).then(function(e) {
                var n = e.license;
                t.licenseInfo = n
            })
        }
        function w() {
            l.hasFeature("apikey") && u.getApiKey({
                tracker: t.loadingTracker,
                onRetry: function() {
                    function e() {
                        return w()
                    }
                    return e
                } ()
            }).then(function(e) {
                t.apiKeyInfo.apiKey = e
            })
        }
        function k(e) {
            return {
                email: e.email,
                firstName: e.firstName,
                lastName: e.lastName,
                companyName: e.companyName,
                companyWebsite: e.companyWebsite,
                contactPhone: e.contactPhone,
                countryCode: e.countryCode,
                notifications: e.notifications
            }
        }
        var A = void 0;
        t.loadingTracker = s({
            activationDelay: d.PROMISE_TRACKER_ACTIVATION_DELAY
        }),
        t.userProfile = {
            userId: "",
            email: "",
            firstName: "",
            lastName: "",
            companyName: "",
            companyWebsite: "",
            contactPhone: "",
            countryCode: "",
            notifications: {
                monthlyStatus: !1,
                scans: !1,
                updates: !1
            },
            accessAllGroups: !1,
            role: "",
            isChildAccount: !1
        },
        t.countries = f.countries,
        t.licenseInfo = null,
        t.apiKeyInfo = {
            apiKey: null,
            visible: !1,
            clipboardTooltipEnabled: !1,
            clipboardTooltipText: ""
        },
        t.accountVerification = {
            confirmations: {
                validContactInformation: !1,
                authorizedToScan: !1
            },
            canAskVerification: function() {
                function e() {
                    var e = t.accountVerification.confirmations,
                    n = e.validContactInformation,
                    r = e.authorizedToScan;
                    return n && r
                }
                return e
            } ()
        },
        e.extend(t, {
            updateProfile: h,
            hasChanges: m,
            saveActionStatusMessage: v,
            onDeleteApiKey: y,
            onGenerateApiKey: S,
            onToggleApiKeyVisibility: b,
            onClipboardSuccess: T,
            onClipboardError: x,
            disableClipboardToolTip: _
        }),
        function() {
            C(),
            I(),
            w()
        } ()
    }
    t.$inject = ["$scope", "gettext", "gettextCatalog", "promiseTracker", "toastr", "AccountApi", "CurrentUser", "axConstant", "axGeneralModal", "axGeo", "SystemConfigApi"],
    e.module("WVS").controller("acunetix.controllers.profile", t);
    var n = e.merge,
    r = e.extend,
    i = e.equals
} (angular),
function(e) {
    "use strict";
    function t(t, n, r, i, a, o, s, c, u, l, d, p, f, g, h, m, v, y) {
        function S(e) {
            w(e.name),
            p.remove(h.API_AUTH_HEADER),
            v.set(null),
            g.clear(),
            c.dismissAll(),
            o.go("login", {},
            {
                inherit: !1
            })
        }
        function b(e) {
            w(e.name),
            g.clear(),
            y.getScans("status:completed", void 0, 1, {
                noPublishError: !0,
                noLoadingTracker: !0
            }).then(function(e) {
                if (! (e.scans.length > 0)) return a.reject();
                r.url("/dashboard/").replace()
            }).
            catch(function() {
                r.url("/").replace()
            })
        }
        function T(e) {
            w(e.name),
            p.remove(h.API_AUTH_HEADER),
            v.set(null),
            g.clear(),
            o.go("login", {},
            {
                inherit: !1
            })
        }
        function x(e, n) {
            e.preventDefault(),
            t.$emit("axError", new Error(d("请求的页面不可用"))),
            i.warn("State " + String(n.to) + " is not defined")
        }
        function C(e, n, r, a, s, c) {
            e.preventDefault(),
            t.$emit("axError", new Error(d("请求的页面不可用"))),
            i.warn("Cannot transition to state " + String(n.name) + ": " + String(c.message)),
            a && !a.abstract || u(function() {
                return o.go("app.list_targets", {},
                {
                    inherit: !1
                })
            },
            100)
        }
        function I() {
            s.location.reload(!0)
        }
        function w(t) {
            e.forEach(n.info(),
            function(e, t) {
                0 === t.indexOf("ax") && n.get(t).removeAll()
            })
        }
        t.$on("axAuthRequired", S),
        t.$on(h.API_EVENTS.USER_LOGGED_IN, b),
        t.$on(h.API_EVENTS.USER_LOGGED_OUT, T),
        t.$on("$stateNotFound", x),
        t.$on("$stateChangeError", C),
        t.$on("axLocaleChanged", I),
        m.init(),
        t.globalPromiseTracker = f({
            activationDelay: 300
        }),
        t.globalHelpLink = "",
        t.scrollTopActionVisible = !0,
        t.appConfig = {
            showBusinessCriticality: !1
        },
        function() {
            var t = function(t, n) {
                var r = p.get(t);
                if (e.isNumber(r) && r !== h[n]) {
                    var a = h[n],
                    o = r;
                    _.endsWith(n, "_INTERVAL") && (a = l(a / 1e3), o = l(o / 1e3)),
                    i.warn("Overriding " + String(n) + " from " + String(a) + " to " + String(o)),
                    h[n] = r
                }
            };
            t("DRI", "DASH_REFRESH_INTERVAL"),
            t("LCI", "LICENSE_CHECK_INTERVAL"),
            t("LRI", "LIST_REFRESH_INTERVAL"),
            t("NPI", "NOTIFICATIONS_POLL_INTERVAL"),
            t("VCI", "VERSION_CHECK_INTERVAL"),
            t("LPS", "LIST_PAGE_SIZE"),
            t("UCS", "UPLOAD_CHUNK_SIZE")
        } ()
    }
    function n(e) {
        return function(t) {
            e.get("$log").error(t)
        }
    }
    t.$inject = ["$rootScope", "$cacheFactory", "$location", "$log", "$q", "$state", "$window", "$uibModalStack", "$timeout", "axFormatDurationFilter", "gettext", "localStorageService", "promiseTracker", "toastr", "axConstant", "axLocale", "CurrentUser", "ScansApi"],
    n.$inject = ["$injector"],
    e.module("WVS").factory("$exceptionHandler", n).run(t)
} (angular),
function(e, t, n) {
    "use strict";
    var r = function(t) {
        return t ? e.element("<div></div>").text(t).html() : ""
    };
    e.module("WVS").filter("axBusinessCriticality", ["axConstant",
    function(e) {
        return function(t) {
            return n.get(n.find(e.BUSINESS_CRITICALITY, n.matchesProperty("value", String(t))), "text", "")
        }
    }]).filter("axVulnSeverityLevel", ["axConstant",
    function(e) {
        return function(t) {
            return n.get(n.find(e.VULN_SEVERITY_LEVEL, n.matchesProperty("value", String(t))), "text", "")
        }
    }]).filter("axVulnStatus", ["axConstant",
    function(e) {
        return function(t) {
            return n.get(n.find(e.VULN_STATUS, n.matchesProperty("value", String(t))), "text", "")
        }
    }]).filter("axMaxDigits", ["numberFilter",
    function(t) {
        return function(n, r) {
            return n = e.isNumber(n) ? n: parseInt(String(n), 10),
            isNaN(n) ? "": e.isNumber(r) && r > 0 && (r = Math.min(r, 5), n > Math.pow(10, r)) ? (Math.pow(10, r) - 1).toString() + "+": t(n)
        }
    }]).filter("axUserRoleName", ["axConstant",
    function(e) {
        return function(t) {
            return n.get(n.find(e.USER_ROLE, n.matchesProperty("value", String(t))), "text", "")
        }
    }]).filter("axScanStatus", ["axConstant",
    function(e) {
        return function(t) {
            return n.get(n.find(e.SCAN_STATUS, n.matchesProperty("value", String(t))), "text", "")
        }
    }]).filter("axThreatLevel", ["axConstant",
    function(e) {
        return function(t) {
            return n.get(n.find(e.THREAT_LEVEL, n.matchesProperty("value", String(t))), "text", "")
        }
    }]).filter("axReportStatus", ["axConstant",
    function(e) {
        return function(t) {
            return n.get(n.find(e.REPORT_STATUS, n.matchesProperty("value", String(t))), "text", "")
        }
    }]).filter("axReportSource", ["axConstant", "gettext",
    function(t, r) {
        return function(i) {
            var a = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
            o = n.get(i, "listType", null);
            if (e.isString(o)) {
                var s = t.REPORT_SOURCE.find(function(e) {
                    return e.value === o
                });
                if (s) {
                    if (a) {
                        if ("scan_result" === s.value || "scan_vulnerabilities" === s.value) return r("Scan Report");
                        if ("vulnerabilities" === s.value) return r("Target Report")
                    }
                    return s.text
                }
            }
            return ""
        }
    }]).filter("axSmtpSecurityOption", ["axConstant",
    function(e) {
        return function(t) {
            return n.get(n.find(e.SMTP_SECURITY_OPTION, n.matchesProperty("value", String(t))), "text", "")
        }
    }]).filter("axProxyProtocolOption", ["axConstant",
    function(e) {
        return function(t) {
            return n.get(n.find(e.PROXY_PROTOCOL_OPTION, n.matchesProperty("value", String(t))), "text", "")
        }
    }]).filter("axJoin",
    function() {
        return function(e, t) {
            return n.join(e, n.defaultTo(t, ","))
        }
    }).filter("axEventName", ["axConstant",
    function(e) {
        return function(t) {
            t = String(t);
            var r = n.find(e.EVENT_TYPES_MAP, n.matchesProperty("typeId", t));
            return r ? String(r.groupName) + " " + String(r.typeName) : t
        }
    }]).filter("axEscapeHtml",
    function() {
        return r
    }).filter("axFormatRecurrence",
    function() {
        return function(e) {
            return t.axConversions.pyToRfc3339(e)
        }
    }).filter("axBugTrackerName", ["axConstant",
    function(e) {
        return function(t) {
            return n.get(n.find(e.BUG_TRACKERS, n.matchesProperty("value", String(t))), "text", "")
        }
    }]).filter("axJiraBugTrackerAuthType", ["axConstant",
    function(e) {
        return function(t) {
            return n.get(n.find(e.JIRA_BUG_TRACKER_AUTH, n.matchesProperty("value", String(t))), "text", "")
        }
    }]).filter("axLicenseFeatureName", ["axConstant",
    function(e) {
        return function(t) {
            return n.get(n.find(e.LICENSE_FEATURES, n.matchesProperty("value", String(t))), "text", "")
        }
    }]).filter("axProductEdition", ["axConstant",
    function(e) {
        return function(t) {
            return n.get(n.find(e.PRODUCT_EDITION, n.matchesProperty("value", String(t))), "text", "")
        }
    }]).filter("axFormatDuration",
    function() {
        return function(t) {
            if (e.isNumber(t)) {
                var n = Math.floor(t / 3600),
                r = t % 3600,
                i = Math.floor(r / 60),
                a = r % 60,
                o = Math.ceil(a),
                s = [o + "s"];
                return i > 0 && s.unshift(i + "m"),
                n > 0 && s.unshift(n + "h"),
                s.join(" ")
            }
            return ""
        }
    })
} (angular, RRule, _),
function(e) {
    "use strict";
    function t(t, n, r, i, a, o, s, c, u, l, d, p) {
        n.useLegacyPromiseExtensions(!1),
        n.useApplyAsync(!0),
        n.interceptors.push("axApiInterceptor"),
        t.aHrefSanitizationWhitelist(/^\s*(https?|ftp|mailto|tel|file|awvs):/),
        t.debugInfoEnabled(!1),
        i.debugEnabled(!1),
        l.theme = "bootstrap",
        e.extend(u, {
            preventOpenDuplicates: !0,
            timeOut: 3e3
        }),
        d.options({
            placement: "bottom auto",
            appendToBody: !0
        }),
        c.setPrefix("ax"),
        o.otherwise("/"),
        r.html5Mode(!1),
        a.state("login", {
            url: "/login/?returnUrl=",
            templateUrl: __axtr("/templates/auth/login/login.html"),
            controller: "axLoginCtrl",
            reloadOnSearch: !1
        }),
        a.state("reset_password", {
            url: "/reset-password",
            templateUrl: __axtr("/templates/auth/reset-password/reset-password.html"),
            controller: "axResetPasswordCtrl",
            reloadOnSearch: !1,
            controllerAs: "$ctrl"
        }),
        a.state("app", {
            url: "/",
            abstract: !0,
            templateUrl: __axtr("/templates/layout/shell.html"),
            controller: "axShellCtrl",
            resolve: {
                authUser: function() {
                    function e(e, t) {
                        return e.getProfile({
                            noLoadingTracker: !0,
                            noPublishError: !1
                        }).
                        catch(function(e) {
                            return t.when({
                                firstName: "N/A"
                            })
                        })
                    }
                    return e.$inject = ["AccountApi", "$q"],
                    e
                } ()
            }
        }),
        a.state("redirect", {
            url: "/redirect?res_type=&res_id=&err_reason=&ss_id=",
            redirectTo: function() {
                function e(e) {
                    var t = e.params();
                    switch (parseInt(t.res_type, 10)) {
                    case 5:
                        return {
                            state:
                            "app.scan_details",
                            params: {
                                scanId: t.res_id,
                                resultId: t.ss_id
                            }
                        };
                    case 7:
                        return {
                            state:
                            "app.list_reports",
                            params: {}
                        };
                    case 3:
                        return {
                            state:
                            "app.target_config",
                            params: {
                                targetId: t.res_id
                            }
                        };
                    case 1:
                    default:
                        return {
                            state:
                            "app.list_targets",
                            params: {}
                        }
                    }
                }
                return e
            } ()
        }),
        a.state("app.me", {
            url: "me/",
            controller: "acunetix.controllers.profile",
            templateUrl: __axtr("/templates/account/profile.html"),
            data: {
                page: {
                    icon: "fa-user",
                    title: s("配置文件")
                }
            },
            onEnter: function() {
                function e(e) {
                    e.scrollTopActionVisible = !1
                }
                return e.$inject = ["$rootScope"],
                e
            } (),
            onExit: function() {
                function e(e) {
                    e.scrollTopActionVisible = !0
                }
                return e.$inject = ["$rootScope"],
                e
            } ()
        }),
        a.state("app.dash", {
            url: "dashboard/",
            controller: "axDashCrl",
            templateUrl: __axtr("/templates/dash/dash.html"),
            data: {
                page: {
                    icon: "fa-dashboard",
                    title: s("仪表盘"),
                    section: "dashboard"
                }
            },
            onEnter: function() {
                function e(e) {
                    e.scrollTopActionVisible = !1
                }
                return e.$inject = ["$rootScope"],
                e
            } (),
            onExit: function() {
                function e(e) {
                    e.scrollTopActionVisible = !0
                }
                return e.$inject = ["$rootScope"],
                e
            } ()
        }),
        a.state("app.list_targets", {
            url: "?threat=&criticality=&scanned_before=&never_scanned=&group=&free=&ls=&gr=&returnUrl=",
            controller: "axListTargetsCtrl",
            templateUrl: __axtr("/templates/targets/list-targets/list-targets.html"),
            reloadOnSearch: !1,
            data: {
                page: {
                    icon: "fa-dot-circle-o",
                    title: s("目标"),
                    section: "targets"
                }
            },
            onEnter: function() {
                function e(e) {
                    e.globalHelpLink = p.HELP_LINKS["targets.list"]
                }
                return e.$inject = ["$rootScope"],
                e
            } (),
            onExit: function() {
                function e(e) {
                    e.globalHelpLink = ""
                }
                return e.$inject = ["$rootScope"],
                e
            } ()
        }),
        a.state("app.target_config", {
            url: "targets/:targetId/:section/?returnUrl=",
            reloadOnSearch: !1,
            data: {
                page: {
                    icon: "fa-dot-circle-o",
                    title: s("编辑目标"),
                    section: "targets"
                }
            },
            resolve: {
                targetInfo: function() {
                    function t(t, n, r, i, a, o, s, c, u, l, d) {
                        return l.getTarget(i.targetId, {
                            noPublishError: !0
                        }).then(function(e) {
                            if (null === e) {
                                var n = a("The specified target does not exist");
                                return t.reject({
                                    errorMessage: n
                                })
                            }
                            return e
                        }).then(function(e) {
                            return l.getTargetConfiguration(i.targetId).then(function(t) {
                                return {
                                    target: e,
                                    config: t
                                }
                            })
                        }).then(function(e) {
                            return "advanced" === i.section ? t.when().then(function() {
                                return o.hasFeature("bug_tracking_integration") !== !0 ? [] : c.getIssueTrackers({
                                    noPublishError: !0
                                })
                            }).then(function(t) {
                                return e.issueTrackers = t,
                                e
                            }).
                            catch(function(n) {
                                return 403 === n.status ? (e.issueTrackers = [{
                                    issueTrackerId: e.config.issueTrackerId,
                                    name: a("Name is not available")
                                }], e) : t.reject(n)
                            }) : e
                        }).then(function(e) {
                            if ("general" === i.section) {
                                if (o.hasFeature("continuous_scans") === !0) return l.getContinuousScanStatus(i.targetId, {
                                    noPublishError: !0
                                }).then(function(t) {
                                    return e.target.continuousMode = t,
                                    e
                                });
                                e.target.continuousMode = !1
                            }
                            return e
                        }).then(function(e) {
                            return "general" === i.section && "sequence" === e.config.login.kind ? l.getLoginSequence(i.targetId).then(function(t) {
                                return t && (e.loginSequence = t),
                                e
                            }) : "http" === i.section ? l.getClientCertificate(i.targetId).then(function(t) {
                                return t && (e.clientCertificate = t),
                                e
                            }) : e
                        }).then(function(t) {
                            return "crawl" === i.section ? l.getImportedFiles(i.targetId).then(function(n) {
                                return e.extend(t, {
                                    importedFiles: Array.isArray(n) ? n: []
                                })
                            }) : t
                        }).then(function(e) {
                            var t = p.TEST_WEBSITES.find(function(t) {
                                var n = t.url,
                                r = e.target.address;
                                "/" === r[r.length - 1] && (r = r.substr(0, r.length - 1));
                                var i = n.indexOf(r);
                                return 0 === i || 7 === i
                            });
                            return t && (e.testWebsite = t),
                            e
                        }).then(function(e) {
                            return e.excludedHours = {
                                profiles: [],
                                currentProfile: {}
                            },
                            s.getExcludedHoursProfiles({
                                noPublishError: !0
                            }).then(function(t) {
                                e.excludedHours.profiles = t
                            }).then(function() {
                                return u.getSystemConfig({
                                    noPublishError: !0
                                })
                            }).then(function(t) {
                                var n = t.excludedHoursId;
                                return e.excludedHours.globalExcludedHoursId = n
                            }).then(function() {
                                return e
                            })
                        }).
                        catch(function(e) {
                            return e.publishResponseError ? e.publishResponseError(e) : e.errorMessage && n.$emit("axError", {
                                errorMessage: e.errorMessage,
                                options: {
                                    centerScreen: !0
                                },
                                retryButtonCaption: a("Home"),
                                onRetry: function() {
                                    function e() {
                                        r.go("app.list_targets", {},
                                        {
                                            inherit: !1
                                        })
                                    }
                                    return e
                                } (),
                                dismissButton: !1
                            }),
                            t.reject(e)
                        })
                    }
                    return t.$inject = ["$q", "$rootScope", "$state", "$stateParams", "gettext", "CurrentUser", "ExcludedHoursApi", "IssueTrackersApi", "SystemConfigApi", "TargetsApi", "authUser"],
                    t
                } ()
            },
            params: {
                section: "general"
            },
            views: {
                "": {
                    templateUrl: __axtr("/templates/targets/target-config/target-config.html"),
                    controller: "axTargetConfigCtrl"
                },
                "general@app.target_config": {
                    templateUrl: __axtr("/templates/targets/target-config/sections/general/general.html"),
                    controller: "axTargetGeneralConfigCtrl"
                },
                "crawl@app.target_config": {
                    templateUrl: __axtr("/templates/targets/target-config/sections/crawl/crawl.html"),
                    controller: "axTargetCrawlConfigCtrl"
                },
                "http@app.target_config": {
                    templateUrl: __axtr("/templates/targets/target-config/sections/http/http.html"),
                    controller: "axTargetHttpConfigCtrl"
                },
                "advanced@app.target_config": {
                    templateUrl: __axtr("/templates/targets/target-config/sections/advanced/advanced.html"),
                    controller: "axTargetAdvancedConfigCtrl"
                }
            },
            onEnter: function() {
                function e(e, t) {
                    switch (e.scrollTopActionVisible = !1, e.globalHelpLink = "", t.section) {
                    case "crawl":
                        e.globalHelpLink = p.HELP_LINKS["target.crawl"];
                        break;
                    case "http":
                        e.globalHelpLink = p.HELP_LINKS["target.http"];
                        break;
                    case "advanced":
                        e.globalHelpLink = p.HELP_LINKS["target.advanced"];
                        break;
                    case "general":
                        e.globalHelpLink = p.HELP_LINKS["target.general"]
                    }
                }
                return e.$inject = ["$rootScope", "$stateParams"],
                e
            } (),
            onExit: function() {
                function e(e) {
                    e.globalHelpLink = "",
                    e.scrollTopActionVisible = !0
                }
                return e.$inject = ["$rootScope"],
                e
            } ()
        }),
        a.state("app.list_reports", {
            url: "reports/?status=&source=&created_start=&created_end=&template=&returnUrl=",
            controller: "axListReportsCtrl",
            templateUrl: __axtr("/templates/reports/list-reports.html"),
            reloadOnSearch: !1,
            data: {
                page: {
                    icon: "fa-file-text",
                    title: s("报告"),
                    section: "reports"
                }
            },
            onEnter: function() {
                function e(e) {
                    e.globalHelpLink = p.HELP_LINKS["reports.generate"]
                }
                return e.$inject = ["$rootScope"],
                e
            } (),
            onExit: function() {
                function e(e) {
                    e.globalHelpLink = ""
                }
                return e.$inject = ["$rootScope"],
                e
            } ()
        }),
        a.state("app.list_scans", {
            url: "scans/?threat=&criticality=&status=&profile=&target=&group=&gr=&returnUrl=",
            controller: "axListScansCtrl",
            templateUrl: __axtr("/templates/scans/list-scan/list-scans.html"),
            reloadOnSearch: !1,
            data: {
                page: {
                    icon: "fa-area-chart",
                    title: s("扫描"),
                    section: "scans"
                }
            },
            onEnter: function() {
                function e(e) {
                    e.globalHelpLink = p.HELP_LINKS["scans.list"]
                }
                return e.$inject = ["$rootScope"],
                e
            } (),
            onExit: function() {
                function e(e) {
                    e.globalHelpLink = ""
                }
                return e.$inject = ["$rootScope"],
                e
            } ()
        }),
        a.state("app.scan_details", {
            url: "scans/:scanId/:view/:resultId/?criticality=&severity=&status=&cvss=&type=&vt_id=&returnUrl=",
            reloadOnSearch: !1,
            data: {
                page: {
                    icon: "fa-area-chart",
                    title: s("扫描"),
                    section: "scans"
                }
            },
            params: {
                view: "stats",
                resultId: "default"
            },
            views: {
                "": {
                    controller: "axScanDetailsCtrl",
                    templateUrl: __axtr("/templates/scans/scan-details/scan-details.html")
                },
                "stats@app.scan_details": {
                    controller: "axScanDetailsStatsCtrl",
                    templateUrl: __axtr("/templates/scans/scan-details/scan-details-stats.html")
                },
                "vulns@app.scan_details": {
                    controller: "axScanDetailsVulnsCtrl",
                    templateUrl: __axtr("/templates/scans/scan-details/scan-details-vulns.html")
                },
                "crawl@app.scan_details": {
                    controller: "axScanDetailsCrawlCtrl",
                    templateUrl: __axtr("/templates/scans/scan-details/scan-details-crawl.html")
                },
                "events@app.scan_details": {
                    controller: "axScanDetailsEventsCtrl",
                    templateUrl: __axtr("/templates/scans/scan-details/scan-details-events.html")
                },
                "sessions@app.scan_details": {
                    controller: "axScanDetailsSessionsCtrl",
                    templateUrl: __axtr("/templates/scans/scan-details/scan-details-sessions.html")
                }
            },
            onEnter: function() {
                function e(e, t) {
                    switch (e.globalHelpLink = "", t.view) {
                    case "stats":
                        e.globalHelpLink = p.HELP_LINKS["scan.stats"];
                        break;
                    case "vulns":
                        e.globalHelpLink = p.HELP_LINKS["scan.vulns"];
                        break;
                    case "crawl":
                        e.globalHelpLink = p.HELP_LINKS["scan.crawl"];
                        break;
                    case "events":
                        e.globalHelpLink = p.HELP_LINKS["scan.events"]
                    }
                    e.scrollTopActionVisible = "vulns" === t.view || "events" === t.view || "sessions" === t.view
                }
                return e.$inject = ["$rootScope", "$stateParams"],
                e
            } (),
            onExit: function() {
                function e(e) {
                    e.globalHelpLink = "",
                    e.scrollTopActionVisible = !0
                }
                return e.$inject = ["$rootScope"],
                e
            } ()
        }),
        a.state("app.scan_details_grouped", {
            url: "scans/:scanId/by-:groupBy/:view/:resultId?severity=&status=&cvss=&target=&returnUrl=",
            reloadOnSearch: !1,
            views: {
                "": {
                    controller: "axGroupedScanDetailsCtrl",
                    templateUrl: __axtr("/templates/scans/scan-details/grouped/grouped-scan-details.html")
                },
                "stats@app.scan_details_grouped": {
                    controller: "axScanDetailsStatsCtrl",
                    templateUrl: __axtr("/templates/scans/scan-details/scan-details-stats.html")
                },
                "vulns@app.scan_details_grouped": {
                    controller: "axGroupedScanDetailsVulnsCtrl",
                    templateUrl: __axtr("/templates/scans/scan-details/grouped/grouped-scan-details-vulns.html")
                },
                "crawl@app.scan_details_grouped": {
                    controller: "axScanDetailsCrawlCtrl",
                    templateUrl: __axtr("/templates/scans/scan-details/scan-details-crawl.html")
                },
                "events@app.scan_details_grouped": {
                    controller: "axScanDetailsEventsCtrl",
                    templateUrl: __axtr("/templates/scans/scan-details/scan-details-events.html")
                },
                "sessions@app.scan_details_grouped": {
                    controller: "axScanDetailsSessionsCtrl",
                    templateUrl: __axtr("/templates/scans/scan-details/scan-details-sessions.html")
                }
            },
            params: {
                view: "stats",
                resultId: "default"
            },
            data: {
                page: {
                    icon: "fa-area-chart",
                    title: s("扫描"),
                    section: "scans"
                }
            },
            onEnter: function() {
                function e(e, t) {
                    switch (e.globalHelpLink = "", t.view) {
                    case "stats":
                        e.globalHelpLink = p.HELP_LINKS["scan.stats"];
                        break;
                    case "vulns":
                        e.globalHelpLink = p.HELP_LINKS["scan.vulns"];
                        break;
                    case "crawl":
                        e.globalHelpLink = p.HELP_LINKS["scan.crawl"];
                        break;
                    case "events":
                        e.globalHelpLink = p.HELP_LINKS["scan.events"]
                    }
                    e.scrollTopActionVisible = "vulns" === t.view || "events" === t.view || "sessions" === t.view
                }
                return e.$inject = ["$rootScope", "$stateParams"],
                e
            } (),
            onExit: function() {
                function e(e) {
                    e.globalHelpLink = "",
                    e.scrollTopActionVisible = !0
                }
                return e.$inject = ["$rootScope"],
                e
            } ()
        }),
        a.state("app.list_vulns", {
            url: "vulnerabilities/?target=&group=&severity=&criticality=&status=&cvss=&type=&scan=&returnUrl=",
            controller: "axListVulnsCtrl",
            templateUrl: __axtr("/templates/vulns/list-vulns/list-vulns.html"),
            reloadOnSearch: !1,
            data: {
                page: {
                    icon: "fa-bug",
                    title: s("漏洞"),
                    section: "vulns"
                }
            },
            onEnter: function() {
                function e(e) {
                    e.globalHelpLink = p.HELP_LINKS["vulns.list"]
                }
                return e.$inject = ["$rootScope"],
                e
            } (),
            onExit: function() {
                function e(e) {
                    e.globalHelpLink = ""
                }
                return e.$inject = ["$rootScope"],
                e
            } ()
        }),
        a.state("app.list_vulns_grouped", {
            url: "vulnerabilities/by-:groupBy/?target=&group=&severity=&criticality=&status=&cvss=&returnUrl=",
            controller: "axGroupedListsVulnsCtrl",
            templateUrl: __axtr("/templates/vulns/list-vulns/grouped/grouped-list-vulns.html"),
            reloadOnSearch: !1,
            data: {
                page: {
                    icon: "fa-bug",
                    title: s("漏洞"),
                    section: "vulns"
                }
            },
            onEnter: function() {
                function e(e) {
                    e.globalHelpLink = p.HELP_LINKS["vulns.list"]
                }
                return e.$inject = ["$rootScope"],
                e
            } (),
            onExit: function() {
                function e(e) {
                    e.globalHelpLink = ""
                }
                return e.$inject = ["$rootScope"],
                e
            } ()
        }),
        a.state("app.vuln_details", {
            url: "vulnerabilities/:vulnId/?returnUrl=",
            templateUrl: __axtr("/templates/vulns/vuln-details/vuln-details.html"),
            controller: "axVulnDetailsCtrl",
            data: {
                page: {
                    icon: "fa-bug",
                    title: s("漏洞"),
                    section: "vulns"
                }
            },
            onEnter: function() {
                function e(e) {
                    e.scrollTopActionVisible = !1
                }
                return e.$inject = ["$rootScope"],
                e
            } (),
            onExit: function() {
                function e(e) {
                    e.scrollTopActionVisible = !0
                }
                return e.$inject = ["$rootScope"],
                e
            } ()
        }),
        a.state("app.result_details", {
            url: "scans/:scanId/results/:resultId/:vulnId/?returnUrl=",
            templateUrl: __axtr("/templates/vulns/result-details/result-details.html"),
            controller: "axResultDetailsCtrl",
            data: {
                page: {
                    icon: "fa-area-chart",
                    title: s("扫描"),
                    section: "scans"
                }
            },
            onEnter: function() {
                function e(e) {
                    e.scrollTopActionVisible = !1
                }
                return e.$inject = ["$rootScope"],
                e
            } (),
            onExit: function() {
                function e(e) {
                    e.scrollTopActionVisible = !0
                }
                return e.$inject = ["$rootScope"],
                e
            } ()
        }),
        a.state("app.edit_settings", {
            url: "settings/:section/?returnUrl=",
            reloadOnSearch: !1,
            params: {
                section: "updates"
            },
            views: {
                "": {
                    controller: "axSystemConfigCtrl",
                    templateUrl: __axtr("/templates/settings/system-config/system-config.html")
                },
                "updates@app.edit_settings": {
                    controller: "axSystemConfigProductUpdatesCtrl",
                    templateUrl: __axtr("/templates/settings/system-config/sections/updates/product-updates.html")
                },
                "proxy@app.edit_settings": {
                    controller: "axSystemConfigProxyCtrl",
                    templateUrl: __axtr("/templates/settings/system-config/sections/proxy/proxy.html")
                },
                "notifications@app.edit_settings": {
                    controller: "axSystemConfigNotificationsCtrl",
                    templateUrl: __axtr("/templates/settings/system-config/sections/notifications/notifications.html")
                },
                "users@app.edit_settings": {
                    controller: "axSystemConfigUsersCtrl",
                    templateUrl: __axtr("/templates/settings/system-config/sections/users/users.html")
                },
                "target-groups@app.edit_settings": {
                    controller: "axSystemConfigTargetGroupsCtrl",
                    templateUrl: __axtr("/templates/settings/system-config/sections/target-groups/target-groups.html")
                },
                "issue-trackers@app.edit_settings": {
                    controller: "axSystemConfigIssueTrackersCtrl",
                    templateUrl: __axtr("/templates/settings/system-config/sections/issue-trackers/issue-trackers.html")
                },
                "scanning-profiles@app.edit_settings": {
                    controller: "axSystemConfigScanningProfilesCtrl",
                    templateUrl: __axtr("/templates/settings/system-config/sections/scanning-profiles/scanning-profiles.html")
                },
                "excluded-hours@app.edit_settings": {
                    controller: "axExclusionHoursCtrl",
                    templateUrl: __axtr("/templates/settings/system-config/sections/exclusion-hours/exclusion-hours.html")
                }
            },
            data: {
                page: {
                    icon: "fa-cog",
                    title: s("系统配置"),
                    section: "settings"
                }
            },
            onEnter: function() {
                function e(e, t) {
                    switch (e.scrollTopActionVisible = !1, e.globalHelpLink = "", t.section) {
                    case "updates":
                        e.globalHelpLink = p.HELP_LINKS["settings.updates"];
                        break;
                    case "proxy":
                        e.globalHelpLink = p.HELP_LINKS["settings.proxy"];
                        break;
                    case "notifications":
                        e.globalHelpLink = p.HELP_LINKS["settings.notifications"];
                        break;
                    case "users":
                        e.globalHelpLink = p.HELP_LINKS["settings.users"];
                        break;
                    case "target-groups":
                        e.globalHelpLink = p.HELP_LINKS["settings.groups"];
                        break;
                    case "issue-trackers":
                    case "scanning-profiles":
                    case "exclusion-hours":
                        e.globalHelpLink = p.HELP_LINKS.settings
                    }
                }
                return e.$inject = ["$rootScope", "$stateParams"],
                e
            } (),
            onExit: function() {
                function e(e) {
                    e.globalHelpLink = "",
                    e.scrollTopActionVisible = !0
                }
                return e.$inject = ["$rootScope"],
                e
            } ()
        }),
        a.state("app.scanning_profile", {
            url: "settings/scanning-profiles/:profileId/?returnUrl=",
            reloadOnSearch: !1,
            controller: "axEditScanningProfileCtrl",
            controllerAs: "$ctrl",
            templateUrl: __axtr("/templates/settings/scanning-profile/scanning-profile.html"),
            params: {
                profileId: "create"
            },
            data: {
                page: {
                    icon: "fa-cog",
                    title: s("设置"),
                    subtitle: s("编辑扫描选项"),
                    section: "settings"
                }
            },
            onEnter: function() {
                function e(e) {
                    e.scrollTopActionVisible = !1
                }
                return e.$inject = ["$rootScope"],
                e
            } (),
            onExit: function() {
                function e(e) {
                    e.scrollTopActionVisible = !0
                }
                return e.$inject = ["$rootScope"],
                e
            } ()
        }),
        a.state("app.edit_user", {
            url: "settings/edit-user/:userId/?returnUrl=",
            controller: "axEditUserCtrl",
            templateUrl: __axtr("/templates/settings/edit-user/edit-user.html"),
            data: {
                page: {
                    icon: "fa-cog",
                    title: s("设置"),
                    subtitle: s("编辑用户"),
                    section: "settings"
                }
            },
            onEnter: function() {
                function e(e) {
                    e.scrollTopActionVisible = !1
                }
                return e.$inject = ["$rootScope"],
                e
            } (),
            onExit: function() {
                function e(e) {
                    e.scrollTopActionVisible = !0
                }
                return e.$inject = ["$rootScope"],
                e
            } ()
        }),
        a.state("app.edit_group_targets", {
            url: "settings/group/:groupId/targets/?returnUrl=",
            controller: "axEditGroupTargetsCtrl",
            templateUrl: __axtr("/templates/settings/edit-group-targets/edit-group-targets.html"),
            data: {
                page: {
                    icon: "fa-cog",
                    title: s("设置"),
                    subtitle: s("配置组成员权限"),
                    section: "settings"
                }
            }
        }),
        a.state("app.edit_user_groups", {
            url: "settings/user/:userId/groups/?returnUrl=",
            controller: "axEditUserGroupsCtrl",
            templateUrl: __axtr("/templates/settings/edit-user-groups/edit-user-groups.html"),
            data: {
                page: {
                    icon: "fa-cog",
                    title: s("目标群体"),
                    subtitle: s("配置权限"),
                    section: "settings"
                }
            }
        }),
        a.state("app.activity_log", {
            url: "activity-log/?severity=&type=&resType=&resId=&returnUrl=",
            controller: "axActivityLogCtrl",
            templateUrl: __axtr("/templates/activity-log/activity-log.html"),
            reloadOnSearch: !1,
            data: {
                page: {
                    icon: "fa-fw fa-bar-chart",
                    title: s("活动日志"),
                    section: "activity-log"
                }
            }
        })
    }
    t.$inject = ["$compileProvider", "$httpProvider", "$locationProvider", "$logProvider", "$stateProvider", "$urlRouterProvider", "gettext", "localStorageServiceProvider", "toastrConfig", "uiSelectConfig", "$uibTooltipProvider", "axConstant"],
    e.module("WVS").config(t)
} (angular);
//# sourceMappingURL=app-bundle.js.map
